# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## Unreleased
### Fixed
- error in date format for receipt file ([4722](https://jira.worldline.com/browse/MTSTAP2USE-4722))

### Added
- Add further information panel in device information page ([4392](https://jira.worldline.com/browse/MTSTAP2USE-4392))
- Add t2u Support flag ([4365](https://jira.worldline.com/browse/MTSTAP2USE-4365))
- Add companyReference and serviceOperator role in device pages ([3267](https://jira.worldline.com/browse/MTSTAP2USE-3266))
- Add companyReference and serviceOperator role in administrator pages ([3267](https://jira.worldline.com/browse/MTSTAP2USE-3267))

### Changed
- Nexus3 migration ([4629](https://jira.worldline.com/browse/MTSTAP2USE-4629))

### Fixed
- Fixed autocomplete for localisation fields ([4345](https://jira.worldline.com/browse/MTSTAP2USE-4345))
- Add filter to settlementIds ([4529](https://jira.worldline.com/browse/MTSTAP2USE-4529))
- Fix update tarif with mention "Plafond/Ceiling" ([4686](https://jira.worldline.com/browse/MTSTAP2USE-4686))
- Fix pb with date filter ([4641](https://jira.worldline.com/browse/MTSTAP2USE-4641))
- Configure the name of the company instead of reference ([4723](https://jira.worldline.com/browse/MTSTAP2USE-4723))
- Fix pb with sips response + api change ([4643](https://jira.worldline.com/browse/MTSTAP2USE-4643))

## 1.18.0 - 2021-02-17
### Added
- Taps selection for refund in journeys tab ([3991](https://jira.worldline.com/browse/MTSTAP2USE-3991))
- Update list of settlements tab for adapting change in settlements API ([3703](https://jira.worldline.com/browse/MTSTAP2USE-3703))
- Display others access media with PAR for anonymous account ([3750](https://jira.worldline.com/browse/MTSTAP2USE-3750))
- Add page to diplay journeys ([3598](https://jira.worldline.com/browse/MTSTAP2USE-3598))
- Add modals for blocking and unblocking devices ([3725](https://jira.worldline.com/browse/MTSTAP2USE-3725))
- Add PAR in access media list ([3589](https://jira.worldline.com/browse/MTSTAP2USE-3589))
- Create device bulk configuration page ([3480](https://jira.worldline.com/browse/MTSTAP2USE-3480))
- Create device history page ([3277](https://jira.worldline.com/browse/MTSTAP2USE-3277))
- Add bulk actions in ap-table component ([3478](https://jira.worldline.com/browse/MTSTAP2USE-3478))
- Create a refund ([3888](https://jira.worldline.com/browse/MTSTAP2USE-3888))
- Display name of line & station for each device + search component with autocomplete ([4025](https://jira.worldline.com/browse/MTSTAP2USE-4025))
- Refund to an other card ([3712](https://jira.worldline.com/browse/MTSTAP2USE-3712))
- After block/unblock a device, display a loading icon until a the device info response ([3997](https://jira.worldline.com/browse/MTSTAP2USE-3997))
- add PAR and AID info on settlements tab ([3590](https://jira.worldline.com/browse/MTSTAP2USE-3590))
- Add PAR info and refactoring tables of access media list ([3527](https://jira.worldline.com/browse/MTSTAP2USE-3527))

### Changed
- Update block/unblock devices for integration with Argentina team's APIs ([4137](https://jira.worldline.com/browse/MTSTAP2USE-4137))
- Take refunds in account in the liste of settlements and their detail ([3989](https://jira.worldline.com/browse/MTSTAP2USE-3989))
- Update type label in access media list ([3589](https://jira.worldline.com/browse/MTSTAP2USE-3589))
- Migration from angular 6 to 9 ([3747](https://jira.worldline.com/browse/MTSTAP2USE-3747))
- Change library for Notification (toastr) ([3747](https://jira.worldline.com/browse/MTSTAP2USE-3747))
- Change library for ToolTips (tippy) ([3747](https://jira.worldline.com/browse/MTSTAP2USE-3747))
- Update translation library

### Fixed
- Fix taps order on user-journey ([4300](https://jira.worldline.com/browse/MTSTAP2USE-4300))
- Fix sort on deviceModel, companyReference, deviceReference and firmwareVersion columns in list of devices tab ([4344](https://jira.worldline.com/browse/MTSTAP2USE-4344))
- Fix placeReference, firmwareVersion and serviceOperator filters in list of devices tab ([4306](https://jira.worldline.com/browse/MTSTAP2USE-4306))
- Fix manage refundable role ([4198](https://jira.worldline.com/browse/MTSTAP2USE-4198))
- Fix link to home page ([4101](https://jira.worldline.com/browse/MTSTAP2USE-4101))
- Fix forbidden error in device history tab ([4033](https://jira.worldline.com/browse/MTSTAP2USE-4033))
- Fix list information section in device details ([3921](https://jira.worldline.com/browse/MTSTAP2USE-3921))
- Fix API call in travel history page ([3981](https://jira.worldline.com/browse/MTSTAP2USE-3981))
- Fix hardware status (gps, 4g, access) in list of devices ([3920](https://jira.worldline.com/browse/MTSTAP2USE-3920))
- devices > Change 'configVersion' and 'versionDate' management ([3871](https://jira.worldline.com/browse/MTSTAP2USE-3871))
- devices > Change company reference label and tooltip ([3765](https://jira.worldline.com/browse/MTSTAP2USE-3765))
- Change message creation device config ([3692](https://jira.worldline.com/browse/MTSTAP2USE-3692))
- Change label into filters ([3717](https://jira.worldline.com/browse/MTSTAP2USE-3717))
- Incorrect transportMode in device-list ([3922](https://jira.worldline.com/browse/MTSTAP2USE-3922))
- Remove Deutsch from config.json file ([3826](https://jira.worldline.com/browse/MTSTAP2USE-3826))
- Fix coordinate map in device details information tab ([3902](https://jira.worldline.com/browse/MTSTAP2USE-3902))
- date filter for payments : to-date excluded ([4093](https://jira.worldline.com/browse/MTSTAP2USE-4093))
- transport mode label should use i18n ([4157](https://jira.worldline.com/browse/MTSTAP2USE-4157))
- The filter by date does not work on the journeys page.  ([4212](https://jira.worldline.com/browse/MTSTAP2USE-4212))
- Fix pb with address removal ([4218](https://jira.worldline.com/browse/MTSTAP2USE-4218))
- Fix responsive design for devices between smartphone and Full HD ([4079](https://jira.worldline.com/browse/MTSTAP2USE-4079)) (report)
- Fix pb with responsive in accessmedia page ([4215](https://jira.worldline.com/browse/MTSTAP2USE-4215))

## 1.17.0 - 2020-11-16
### Added
- Create devices table ([3322](https://jira.worldline.com/browse/MTSTAP2USE-3322))
- Create devices page ([3321](https://jira.worldline.com/browse/MTSTAP2USE-3321))
- Add simple configuration in device-configuration ([3389](https://jira.worldline.com/browse/MTSTAP2USE-3389))
- Add filter component ([3379](https://jira.worldline.com/browse/MTSTAP2USE-3379))
- Add page to manage default configurations ([3384](https://jira.worldline.com/browse/MTSTAP2USE-3384))
- Add create-device page ([3381](https://jira.worldline.com/browse/MTSTAP2USE-3381))
- Add input help for direction type in configuration tab ([3441](https://jira.worldline.com/browse/MTSTAP2USE-3441))
- Update device service and models for getting devices by filters ([3231](https://jira.worldline.com/browse/MTSTAP2USE-3231))
- Refactoring on table component ([3320](https://jira.worldline.com/browse/MTSTAP2USE-3320))

### Fixed
- Fix Kibana bad display ([3365](https://jira.worldline.com/browse/MTSTAP2USE-3365))
- Fix pb with sort, not saved when we change url ([3450](https://jira.worldline.com/browse/MTSTAP2USE-3450))

## 1.16.2 - 2020-10-12
### Fixed
- Wrong journeys display ([3364](https://jira.worldline.com/browse/MTSTAP2USE-3364))

## 1.16.1 - 2020-10-12
### Fixed
- Problem with filters on customer account list ([3213](https://jira.worldline.com/browse/MTSTAP2USE-3213))
- Filter does not return all statuses ([3203](https://jira.worldline.com/browse/MTSTAP2USE-3203))

## 1.16.0 - 2020-10-09
### Added
- Get Line and station description for travel activities ([3187](https://jira.worldline.com/browse/MTSTAP2USE-3187))

### Fixed
- Customers accounts dashboard shows the TERMINATED accounts by default ([3213](https://jira.worldline.com/browse/MTSTAP2USE-3213))
- Fix wrong position of support's label column ([3185](https://jira.worldline.com/browse/MTSTAP2USE-3185))

## 1.15.0 - 2020-09-25
### Fixed
- When showing detail of a support, this last is not the only one selected in the settlement tab ([2627](https://jira.worldline.com/browse/MTSTAP2USE-2627))
- Access to the Dashboard Kibana button only for SuperAdmin ([1565](https://jira.worldline.com/browse/MTSTAP2USE-1565))
- When showing detail of a support, this last is not the only one selected in the settlement tab ([2982](https://jira.worldline.com/browse/MTSTAP2USE-2982))
- Change link to debt recovery call back ([3056](https://jira.worldline.com/browse/MTSTAP2USE-3056)) (support 1.13.x)
- Sort settlements ([3031](https://jira.worldline.com/browse/MTSTAP2USE-3031))
- Settlements - add service operator for  tap ([3042](https://jira.worldline.com/browse/MTSTAP2USE-3042))

## 1.14.4 - 2020-09-07
### Fixed
- Multi-operator: The operator of a TAP is not displayed ([3003](https://jira.worldline.com/browse/MTSTAP2USE-3003))

## 1.14.3 - 2020-09-04
### Changed
- Filtering list of agents - not showing user without email ([2962](https://jira.worldline.com/browse/MTSTAP2USE-2962))

## 1.14.2 - 2020-09-01
### Fixed
- Error 500 on access media list ([2957](https://jira.worldline.com/browse/MTSTAP2USE-2957))

## 1.14.1 - 2020-08-31
### Fixed
- Translate SIPS form for a bank card search ([2936](https://jira.worldline.com/browse/MTSTAP2USE-2936))
- Correct error message NOT_SAME_CARD ([2938](https://jira.worldline.com/browse/MTSTAP2USE-2938))

## 1.14.0 - 2020-08-18
### Added
- Allow PA to view accounts in TERMINATED status ([2482](https://jira.worldline.com/browse/MTSTAP2USE-2482))

### Changed
- Switch states to status (enum) for data blocks ([2536](https://jira.worldline.com/browse/MTSTAP2USE-2536))
- Merging AccessMediaState and AccessMediaStatus ([2541](https://jira.worldline.com/browse/MTSTAP2USE-2541))
- Media with BLOCKED status are not visible on the customer account ([2734](https://jira.worldline.com/browse/MTSTAP2USE-2734))

### Fixed
- Added Agent option when updating an administrator ([2788](https://jira.worldline.com/browse/MTSTAP2USE-2788))

### Security
- Upgrade NGINX version to 1.16 ([2015](https://jira.worldline.com/browse/MTSTAP2USE-2015))

## 1.13.21 - 2020-09-24
### Fixed
- Wrong schema display ([3119](https://jira.worldline.com/browse/MTSTAP2USE-3119))
- Display station reference instead of station label ([3159](https://jira.worldline.com/browse/MTSTAP2USE-3159))

## 1.13.20 - 2020-09-22
### Fixed
- Settlements - add service operator for tap ([3042](https://jira.worldline.com/browse/MTSTAP2USE-3042))

## 1.13.19 - 2020-09-17
### Changed
- Activities screen display ([3041](https://jira.worldline.com/browse/MTSTAP2USE-3041))

## 1.13.17 - 2020-09-15
### Changed
- Activities screen display ([3041](https://jira.worldline.com/browse/MTSTAP2USE-3041))

## 1.13.8 - 2020-08-12
### Fixed
- [Portail] PA - In the details of a trip, the wording in the settlement column is called "Origin" ([2816](https://jira.worldline.com/browse/MTSTAP2USE-2816))

## 1.13.7 - 2020-08-11
### Fixed
- Email doesn't send after we add a comment into customer request ([2009](https://jira.worldline.com/browse/MTSTAP2USE-2009))

## 1.13.6 - 2020-08-10
### Fixed
- Fix control device has no default model ([2668](https://jira.worldline.com/browse/MTSTAP2USE-2668))

## 1.13.5 - 2020-08-07
### Fixed
- Fix device liste page and fix sips enrolement ([2839](https://jira.worldline.com/browse/MTSTAP2USE-2839))

## 1.13.4 - 2020-08-05
### Fixed
- Chnage status of access media (BLOCKED) ([2822](https://jira.worldline.com/browse/MTSTAP2USE-2822))

## 1.13.3 - 2020-07-29
### Fixed
- Allow user with ADMIN role to create another user with ADMIN role ([2774](https://jira.worldline.com/browse/MTSTAP2USE-2774))

## 1.13.2 - 2020-07-29
### Added
- Create device's configuration page ([2796](https://jira.worldline.com/browse/MTSTAP2USE-2796))
- Add Xenturion informations section for device's informations page ([2864](https://jira.worldline.com/browse/MTSTAP2USE-2864))
- Create device's informations page ([2786](https://jira.worldline.com/browse/MTSTAP2USE-2786))
- Create device's parent component ([2801](https://jira.worldline.com/browse/MTSTAP2USE-2801))
- Remove old devices components ([2800](https://jira.worldline.com/browse/MTSTAP2USE-2800))

### Fixed
- Fixed unknown value for AGENT role ([2771](https://jira.worldline.com/browse/MTSTAP2USE-2771))

## 1.13.1 - 2020-07-28
### Fixed
- Display of information from another trip in trip details ([2636](https://jira.worldline.com/browse/MTSTAP2USE-2636))
- [admin-portal] le champs "activation" de multivalidation manquant ([2761](https://jira.worldline.com/browse/MTSTAP2USE-2761))

## 1.13.0 - 2020-07-24
### Fixed
- Invoice display instead of proof ([2686](https://jira.worldline.com/browse/MTSTAP2USE-2686))
- Translate personalized on filter ([2235](https://jira.worldline.com/browse/MTSTAP2USE-2235))
- Perfectible display when a medium has no label ([2685](https://jira.worldline.com/browse/MTSTAP2USE-2685))
- Information on the origin of a settlement by a later TAP is in English ([2689](https://jira.worldline.com/browse/MTSTAP2USE-2689))

## 1.12.0 - 2020-07-13
### Fixed
- Support tab for a customer account - Name and order of columns ([1312](https://jira.worldline.com/browse/MTSTAP2USE-1312))
- Rules - Spelling error in the wording of the button closing the detail of a trip ([2688](https://jira.worldline.com/browse/MTSTAP2USE-2688))
- Customer accounts - support label not translated ([2598](https://jira.worldline.com/browse/MTSTAP2USE-2598))
- Fix usage of URL device-configuration-manager/v1/devicesInfo/statistics/ ([2602](https://jira.worldline.com/browse/MTSTAP2USE-2602))

## 1.11.0 - 2020-06-26
### Fixed
- The date of the trip is not translated for the trip tab ([2508](https://jira.worldline.com/browse/MTSTAP2USE-2508))
- New settlements page is not translated ([2505](https://jira.worldline.com/browse/MTSTAP2USE-2505))

## 1.10.0 - 2020-06-12
### Fixed
- Identity tab - The invoicing block disappears if empty & click on delete ([1363](https://jira.worldline.com/browse/MTSTAP2USE-1363))
- Loading list of payments generates an error on some accounts ([2384](https://jira.worldline.com/browse/MTSTAP2USE-2384))

## 1.9.1-SNAPSHOT - 2020-06-03
### Fixed
- Missing action button on customer request page detail ([2285](https://jira.worldline.com/browse/MTSTAP2USE-2285))

## 1.9.0 - 2020-06-02
### Fixed
- Dates are no longer displayed ([2231](https://jira.worldline.com/browse/MTSTAP2USE-2231))

## 1.8.1 - 2020-05-26
### Fixed
- Wrong role display in agents page ([2353](https://jira.worldline.com/browse/MTSTAP2USE-2353))

## 1.8.0 - 2020-05-22
### Added
- Make pagination configurable ([2023](https://jira.worldline.com/browse/MTSTAP2USE-2023))

### Changed
- Adaptation to APIs changes in security implementation ([2191](https://jira.worldline.com/browse/MTSTAP2USE-2191))

### Fixed
- Set the language with the one selected on the login page ([2227](https://jira.worldline.com/browse/MTSTAP2USE-2227))
- The request number in the filters remains in French ([2229](https://jira.worldline.com/browse/MTSTAP2USE-2229))
- Filters and terminal status are not translated ([2239](https://jira.worldline.com/browse/MTSTAP2USE-2239))
- Add settlements ([1913](https://jira.worldline.com/browse/MTSTAP2USE-1913))

## 1.7.0 - 2020-05-05
### Added
- New type transport card management ([2219](https://jira.worldline.com/browse/MTSTAP2USE-2219))

### Fixed
- Customer account - December is poorly translated ([2242](https://jira.worldline.com/browse/MTSTAP2USE-2242))

## 1.6.0 - 2020-04-22
### Added
- Externalise application title and favicon to set them dynamically ([2134](https://jira.worldline.com/browse/MTSTAP2USE-2134))

## 1.5.0 - 2020-04-07
### Changed
- Dead code deletion and using engine instead of managers ([1937](https://jira.worldline.com/browse/MTSTAP2USE-1937))

### Fixed
- Partial deletion of the customer account ([1614](https://jira.worldline.com/browse/MTSTAP2USE-1614))
- Anomalies on controls while creating an Agent fixed ([1523](https://jira.worldline.com/browse/MTSTAP2USE-1523))
- Cannot set empty value to phone number fixed ([1495](https://jira.worldline.com/browse/MTSTAP2USE-1495))
- MOTO implementation ([1872](https://jira.worldline.com/browse/MTSTAP2USE-1872))
- Changelog update by filling in all processed tickets ([2056](https://jira.worldline.com/browse/MTSTAP2USE-2056))
- New status managed in the support list ([2014](https://jira.worldline.com/browse/MTSTAP2USE-2014))
- Terminals - problem with the total number of devices ([1517](https://jira.worldline.com/browse/MTSTAP2USE-1517))
- SAV - inconsistency display action button ([1402](https://jira.worldline.com/browse/MTSTAP2USE-1402))
- Display problem in Terminals Menu - no C-One ([1516](https://jira.worldline.com/browse/MTSTAP2USE-1516))
- Terminals - problem with filters ([1518](https://jira.worldline.com/browse/MTSTAP2USE-1518))
- Payment - Correspondence TAP are displayed ([1501](https://jira.worldline.com/browse/MTSTAP2USE-1501))
- Add Agent Profile and Manage Rights ([1594](https://jira.worldline.com/browse/MTSTAP2USE-1594))
- Sort the devices according to the fields displayed ([1567](https://jira.worldline.com/browse/MTSTAP2USE-1567))
- Sending mail with generic sender ([1480](https://jira.worldline.com/browse/MTSTAP2USE-1480))
- Integration operation not completed at the PO ([1570](https://jira.worldline.com/browse/MTSTAP2USE-1570))
- Display the label of the support ([1476](https://jira.worldline.com/browse/MTSTAP2USE-1476))
- Status of the Yonéo ([1449](https://jira.worldline.com/browse/MTSTAP2USE-1449))
- List of payments title absent when there are no payment ([1450](https://jira.worldline.com/browse/MTSTAP2USE-1450))
- Getting list of supported languages from custom config file ([1431](https://jira.worldline.com/browse/MTSTAP2USE-1431))

## 1.4.1 - 2020-03-06
### Added
- Add $http_x_forwarded_for to nginx log format ([2024]https://jira.worldline.com/browse/MTSTAP2USE-2024))

### Fixed
- Adding new account status in models & APIs ([2013](https://jira.worldline.com/browse/MTSTAP2USE-2013))
- PA - MCD - Lors d'une régularisation MOTO ou VAD, le message affiché n'est pas correct ([1994](https://jira.worldline.com/browse/MTSTAP2USE-1994))
- Deletion of a KO account via the Admin portal ([1916](https://jira.worldline.com/browse/MTSTAP2USE-1916))

## 1.3.0 - 2020-03-06
### Fixed
- Supprimer le nom des équipements de contrôle ou "banaliser" ([1883](https://jira.worldline.com/browse/MTSTAP2USE-1883))

## 1.2.0 - 2020-02-25
### Added
- Nouvelle configuration pour le Yonéo ( autorisation synchrone) ([1637](https://jira.worldline.com/browse/MTSTAP2USE-1637))

## 1.1.0 - 2020-02-04
### Added
- Nouvelle configuration pour le Yonéo ([1136](https://jira.worldline.com/browse/MTSTAP2USE-1136))
- Nouvelle configuration pour le dashboard kibana
- Surcharge css possible ([1564](https://jira.worldline.com/browse/MTSTAP2USE-1136))

### Fixed
- Nouvelle page sur le portail pour récupérer le retour de SIPS ([958](https://jira.worldline.com/browse/MTSTAP2USE-958))

## 0.3.0 - 2019-09-26
### Fixed
- [Portail] Liste des supports - ajout de la recherche par carte bancaire ([710](https://jira.worldline.com/browse/MTSTAP2USE-710))
- [Portail] PA - Compte admin - Accès a des rôles de plus haut niveau ([976](https://jira.worldline.com/browse/MTSTAP2USE-976))
- [Portail] PA-Détail d'un compte agent - le rôle de l'agent n'est pas affiché ni modifiable ([1058](https://jira.worldline.com/browse/MTSTAP2USE-1058))
- [Portail] PA - Détail d'une demande SAV - Manque l'indication RGPD et Date de cloture ([986](https://jira.worldline.com/browse/MTSTAP2USE-986))
- [Portail] PA - Liste des demandes SAV - informations affichées incohérentes avec zone de filtre ([1027](https://jira.worldline.com/browse/MTSTAP2USE-1027))
- [Portail] PA - Design - Information depuis menu mon compte ([1056](https://jira.worldline.com/browse/MTSTAP2USE-1056))
- [Portail] PA - Design - Ordre et libellé des menus ([985](https://jira.worldline.com/browse/MTSTAP2USE-985))
- [Portail] PA - Détail compte client - onglet Identité ([980](https://jira.worldline.com/browse/MTSTAP2USE-980))
- [Portail] PA - Page Mon Compte - Modification impossible et erreur d'affichage([968](https://jira.worldline.com/browse/MTSTAP2USE-968))
- [Portail] PA - Gestion des supports - Liste des supports - informations tableau erronées ([1011](https://jira.worldline.com/browse/MTSTAP2USE-1011))
- [Portail] PA - Détail d'un terminal Yoneo - Manque une section de configuration pour P+R ([1017](https://jira.worldline.com/browse/MTSTAP2USE-1017))
- [Portail] PA – Liste des demandes SAV – incohérence entre les 2 pages listes des demandes ([1065](https://jira.worldline.com/browse/MTSTAP2USE-1065))
- [Portail] PA - Liste des comptes clients - pb dans zone de filtre ([1010](https://jira.worldline.com/browse/MTSTAP2USE-1010))
- [Portail] PA - Page Mon Compte - Modification impossible et erreur d'affichage ([968](https://jira.worldline.com/browse/MTSTAP2USE-968))

## 0.2.2 - 2019-09-19
### Fixed
- [Portail] PA-Détail d'une demande - Renommer bouton Envoyer par Enregistrer ou Valider ([1004](https://jira.itsm.atosworldline.com/browse/MTSTAP2USE-1004))
- [Portail] PA- Liste mes demandes - Le bouton Libérer n'existe pas dans la colonne  Actions ([1007](https://jira.itsm.atosworldline.com/browse/MTSTAP2USE-1007))
- [Portail] PA - Détail d'un compte admin - Information modifiable à tord ([970](https://jira.itsm.atosworldline.com/browse/MTSTAP2USE-970))
- [Portail] PA - Détail d'un compte admin - Information modifiable à tord ([986](https://jira.itsm.atosworldline.com/browse/MTSTAP2USE-986))
- [Portal] PA-Liste des demandes SAV- Le champ Agent n'est pas vide alors que le statut de la demande est ouvert [991](https://jira.itsm.atosworldline.com/browse/MTSTAP2USE-991)
- [Portal] PA-Détail d'une  demande SAV- Le champ Assignée à n'est pas vide alors que le statut de la demande est ouvert ([992](https://jira.itsm.atosworldline.com/browse/MTSTAP2USE-992))
- [Portail] PA-Demande SAV - Le nombre d'alerte doit présenter seulement les demandes non assignées et non pas toutes les demandes ([1013](https://jira.itsm.atosworldline.com/browse/MTSTAP2USE-1013))
- [Portail] PA - Rôle SAV - Manque des fonctions ([994](https://jira.itsm.atosworldline.com/browse/MTSTAP2USE-994))
- [Portail] PA - Page Mon Compte - Modification impossible et erreur d'affichage ([968](https://jira.itsm.atosworldline.com/browse/MTSTAP2USE-968))
- [Portail] PA - Liste demande SAV - Manque les demandes assignées ([974](https://jira.itsm.atosworldline.com/browse/MTSTAP2USE-974))
- [Portail] PA - Page Connexion - manque lien mot de passe oublié  ([965](https://jira.itsm.atosworldline.com/browse/MTSTAP2USE-965))
- [Portail] PA - Compte admin - Accès a des rôles de plus haut niveau  ([976](https://jira.itsm.atosworldline.com/browse/MTSTAP2USE-976))
- [Portail] PA - Détail d'un compte Admin - manque le bouton "réinitialiser le mot de passe" ([972](https://jira.itsm.atosworldline.com/browse/MTSTAP2USE-972))
- [Portail] PA- Demande SAV- Le message ne s'affiche pas pour demander à l'agent s'il souhaite enregistrer son commentaire ([987](https://jira.itsm.atosworldline.com/browse/MTSTAP2USE-987))
- [Portail] PA - Rôle d'Admin - Même accès que le SuperAdmin ([995](https://jira.itsm.atosworldline.com/browse/MTSTAP2USE-995))
- [Portail] PA - Toutes les pages - Erreur lorsque pas de données ([966](https://jira.itsm.atosworldline.com/browse/MTSTAP2USE-966))
- [Portail] PA - Création d'un compte admin - Règles de création non respectées ([969](https://jira.itsm.atosworldline.com/browse/MTSTAP2USE-969))
- [Portail] PA - Détail compte client - onglet Identité ([980](https://jira.itsm.atosworldline.com/browse/MTSTAP2USE-980))
- [Portail] PA - Design - Ordre et libellé des menus ([985](https://jira.itsm.atosworldline.com/browse/MTSTAP2USE-985))
- [Portail] PA - Détail compte client - pb libellé entête et onglet "Historique" en trop ([1008](https://jira.itsm.atosworldline.com/browse/MTSTAP2USE-1008))
- [Portail] PA - Liste des comptes clients - RG de résiliation de compte à supprimer ([981](https://jira.itsm.atosworldline.com/browse/MTSTAP2USE-981))
- [Portail] PA - Détail d'un terminal - Informations des onglets Information/Configuration incorrectes (rôle ADMIN) ([1001](https://jira.itsm.atosworldline.com/browse/MTSTAP2USE-1001))
- [Portail] PA - Rôle d'Exploitant manquant ([996](https://jira.itsm.atosworldline.com/browse/MTSTAP2USE-996))
