import { Component, ViewChild, OnInit, Inject, HostListener, ElementRef, AfterViewInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { KeycloakService } from 'keycloak-angular';
import { environment } from '@env/environment';
import { MenuComponent } from './core/menu/menu.component';
import { AppService } from './app.service';
import { AbstractOnDestroyComponent } from './core/abstract-on-destroy-component/abstract-on-destroy-component';
import { takeUntil } from 'rxjs/operators';
import { UtilService } from './core/services/util/util.service';
import { Title } from '@angular/platform-browser';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent extends AbstractOnDestroyComponent implements OnInit, AfterViewInit {
  appTitle: string = environment.defaultValue.applicationTitle;
  appFavicon: string = environment.defaultValue.faviconPath;
  appVersion = environment.common.VERSION;
  lang = 'fr';
  availableLang: any[];
  urlCGU: string = environment.defaultValue.urlFooter.cgu;
  urlFaq: string = environment.defaultValue.urlFooter.faq;
  urllegalNotice: string = environment.defaultValue.urlFooter.legalNotice;
  displayFaq: boolean = environment.defaultValue.urlFooter.displayFaq;
  displayCgu: boolean = environment.defaultValue.urlFooter.displayCgu;
  displayLegalNotice: boolean = environment.defaultValue.urlFooter.displayLegalNotice;
  @ViewChild(MenuComponent, { static: true }) menuComponent: MenuComponent;
  constructor(
    private translate: TranslateService,
    private keycloakService: KeycloakService,
    private appService: AppService,
    private utilService: UtilService,
    private titleService: Title,
    @Inject(DOCUMENT) private document: HTMLDocument,
  ) {
    super();
  }

  @ViewChild('content', { static: true }) contentDiv: ElementRef;

  ngOnInit(){
    this.initLocale();
    this.initializeCompanyRef();
    this.reloadMainComponent();
    /*
      * Set application favicon dynamicaly
      * You sould add 'appFavicon' id in the index.html
    */
    this.document.getElementById('appFavicon').setAttribute('href', this.appFavicon);
    /* Set application title dynamicaly */
    this.titleService.setTitle(this.appTitle);
  }

  ngAfterViewInit(): void {
    this.adjustMainContainer();
    this.autoSizeMenu();
  }


  @HostListener('window:resize', ['$event'])
  onResize(_event: any) {
    this.adjustMainContainer();
    this.autoSizeMenu();
  }

  private adjustMainContainer() {
    const windowSize = window.innerHeight - 50;
    this.contentDiv.nativeElement.style.minHeight = windowSize + 'px';
  }

  private autoSizeMenu() {
    this.document.getElementsByTagName('body').item(0).classList.remove('nav-md', 'nav-sm');
    if(window.innerWidth < 1360) {
      this.document.getElementsByTagName('body').item(0).classList.add('nav-sm');
    } else {
      this.document.getElementsByTagName('body').item(0).classList.add('nav-md');
    }
  }

  initLocale() {
    this.availableLang = environment.langues;
    const availableCodeLanguage = this.availableLang.map(language => language.code);
    this.translate.addLangs(availableCodeLanguage);
    this.translate.setDefaultLang(availableCodeLanguage[0]);
    const userLang = this.utilService.getDefaultLanguage();
    if (availableCodeLanguage.includes(userLang)) {
      this.changeLang(userLang);
    } else {
      this.keycloakService.loadUserProfile().then((userProfile: CustomKeycloakProfile) => {
        // In case there is no dropdown to select language
        if (userProfile.attributes.locale){
          this.changeLang(userProfile.attributes.locale[0]);
        } else {
          this.changeLang(availableCodeLanguage[0]);
        }
      }).catch(err => { this.changeLang(availableCodeLanguage[0]);});
    }
  }

  private initializeCompanyRef() {
    this.keycloakService.loadUserProfile()
      .then((profile: CustomKeycloakProfile) => {
        if (profile?.attributes?.companyRef?.length > 0) {
          this.utilService.persistInBrowser('companyRef', profile.attributes.companyRef[0], 'session');
        } else {
          sessionStorage.removeItem('companyRef');
        }
      });
  }

  onActivate($event) {
    const scrollToTop = window.setInterval(() => {
      const pos = window.pageYOffset;
      if (pos > 0) {
        window.scrollTo(0, pos - 20); // how far to scroll on each step
      } else {
        window.clearInterval(scrollToTop);
      }
    }, 16);
  }



  changeLang(lang: string) {
    this.lang = lang;
    this.translate.use(lang);
    this.utilService.persistInBrowser('language', lang, 'session');
  }

  logout() {
    const baseUrl = location.origin;
    this.keycloakService.logout(baseUrl).then(() => {});
    window.sessionStorage.clear();
  }

  reloadMainComponent() {
    this.appService.updated$
      .pipe( takeUntil(this.unsubscribe) )
      .subscribe(value => {
        if (value) {
          this.menuComponent.ngOnInit();
        }
      });
  }
}
declare interface CustomKeycloakProfile extends Keycloak.KeycloakProfile {
  attributes?: { locale: string[], companyRef: string[] };
}
