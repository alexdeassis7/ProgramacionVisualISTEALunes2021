import { BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { NgProgressModule } from '@ngx-progressbar/core';
import { NgProgressHttpModule } from '@ngx-progressbar/http';
import { SimpleModalModule } from 'ngx-simple-modal';
import { SharedModule } from '@app/shared/shared.module';
import { AppComponent } from '@app/app.component';
import { MenuComponent } from '@app/core/menu/menu.component';
import { KeycloakService, KeycloakAngularModule } from 'keycloak-angular';
import { environment } from '@env/environment';
import { StatisticComponent } from './modules/statistic/statistic.component';
import { AppRoutingModule } from './app-routing.module';
import { AppService } from './app.service';
import { DatePipe } from '@angular/common';
import { ToastrModule } from 'ngx-toastr';
import { AppInternalSupportGuard } from './core/guards/app-internal-support-guard';

@NgModule({
  declarations: [AppComponent, MenuComponent, StatisticComponent],
  imports: [
    AppRoutingModule,
    SharedModule.forRoot(),
    BrowserAnimationsModule,
    HttpClientModule,
    NgProgressModule.withConfig({
      spinner: false,
      color: '#1abb9c',
      thick: true
    }),
    NgProgressHttpModule,
    ToastrModule.forRoot({ positionClass: 'toast-bottom-right' }),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    SimpleModalModule.forRoot({ container: 'modal-container' }),
    KeycloakAngularModule
  ],
  providers: [
    {
      provide: APP_INITIALIZER,
      useFactory: init,
      multi: true,
      deps: [KeycloakService],
    },
    AppService,
    DatePipe,
    AppInternalSupportGuard
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
}

export function init(keycloak: KeycloakService): () => Promise<any> {
  return (): Promise<any> => {
    return new Promise<any>((resolve, reject) => {
      var xmlhttp = new XMLHttpRequest(),
        method = 'GET',
        url = './assets/config/config.json';
        xmlhttp.open(method, url, true);
        xmlhttp.onload = function() {
          if (xmlhttp.status === 200) {
            const config = JSON.parse(xmlhttp.responseText);
            environment.production = config.production;
            environment.api = config.api;
            environment.keycloak = config.keycloak;
            environment.roles = config.roles;
            environment.defaultValue = config.defaultValue;
            environment.kibana = config.kibana;
            environment.langues = config.langues;
            resolve(environment);
          } else {
            resolve(environment);
          }
        };
      xmlhttp.send();
    }).then((environment) => {
      return new Promise(async (resolve, reject) => {
        try {
          await keycloak.init({
            config: environment.keycloak,
            initOptions: {
              onLoad: 'login-required',
              checkLoginIframe: false
            },
            bearerExcludedUrls: []
          });
          resolve();
        } catch (error) {
          reject(error);
        }
      });
    });
  }
}
