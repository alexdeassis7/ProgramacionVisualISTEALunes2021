import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable()
export class AppService {
    private updateUser = new Subject<string>();

    updated$ = this.updateUser.asObservable();

    setUpdate(val: string) {
        this.updateUser.next(val);
    }
}
