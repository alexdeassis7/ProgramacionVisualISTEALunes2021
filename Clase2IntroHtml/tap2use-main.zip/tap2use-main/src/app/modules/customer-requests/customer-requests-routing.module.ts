import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CustomerRequestsListComponent } from './customer-requests-list/customer-requests-list.component';
import { AppAuthGuard } from '@app/core/guards/authguard';
import { AccessRoles } from '@app/core/services/administrator/models/accessRoles';
import { CustomerRequestDetailComponent } from './customer-request-detail/customer-request-detail.component';
import { CustomerRequestsResolver } from './resolvers/customer-request.resolver';
import { KeycloakProfilResolver } from './resolvers/keycloak-profil.resolve';

const routes: Routes = [
  { path: '', component: CustomerRequestsListComponent, 
    canActivate: [AppAuthGuard], 
    resolve: { customerRequests: CustomerRequestsResolver, admin: KeycloakProfilResolver },
    runGuardsAndResolvers: 'paramsOrQueryParamsChange',
    data: { role: [AccessRoles.ROLE_SUPER_ADMIN,AccessRoles.ROLE_ADMIN,AccessRoles.ROLE_SAV] } 
  },
  {
    path: ':customerRequestId',
    component: CustomerRequestDetailComponent,
    canActivate: [AppAuthGuard],
    data: { role: [AccessRoles.ROLE_SUPER_ADMIN,AccessRoles.ROLE_ADMIN,AccessRoles.ROLE_SAV] }  }
];


@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
  ]
})
export class CustomerRequestRoutingModule { }
