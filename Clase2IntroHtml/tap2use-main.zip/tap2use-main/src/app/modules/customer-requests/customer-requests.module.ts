import { NgModule } from '@angular/core';
import { UiSwitchModule } from 'ngx-ui-switch';
import { CommonModule } from '@angular/common';
import { CustomerRequestsListComponent } from './customer-requests-list/customer-requests-list.component';
import { CustomerRequestDetailComponent } from './customer-request-detail/customer-request-detail.component';
import { SharedModule } from '@app/shared/shared.module';
import { CustomerRequestStatusComponent } from './customer-request-shared/customer-request-status/customer-request-status.component';
import { AutoresizeDirective } from '@app/core/directives/autoresize.directive';
import { CustomerRequestRoutingModule } from './customer-requests-routing.module';

@NgModule({
  imports: [
    CommonModule,
    UiSwitchModule,
    SharedModule,
    CustomerRequestRoutingModule
  ],
  declarations: [
    CustomerRequestsListComponent,
    CustomerRequestDetailComponent,
    CustomerRequestStatusComponent,
    AutoresizeDirective
  ]
})
export class CustomerRequestsModule { }
