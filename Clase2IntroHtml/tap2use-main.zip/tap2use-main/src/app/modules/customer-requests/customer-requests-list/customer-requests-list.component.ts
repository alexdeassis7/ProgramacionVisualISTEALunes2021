import { Component, OnInit } from '@angular/core';
import { CustomerRequestService } from '@app/core/services/customer-request/customer-request.service';
import { CustomerRequest } from '@app/core/services/customer-request/model/customerRequest';
import { KeycloakService } from 'keycloak-angular';
import { ActivatedRoute, Router } from '@angular/router';
import { KeycloakProfile } from 'keycloak-js';
import { Comment } from '@app/core/services/customer-request/model/comment';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { takeUntil } from 'rxjs/operators';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { FilterData } from '@app/shared/components/filter/filterData';
import { Pagination } from '@app/shared/components/pagination/pagination.model';
import { TextFilterTemplate } from '@app/shared/components/filter/filter-template/text-filter-template/text-filter-template.model';
import { SelectionFilterTemplate } from '@app/shared/components/filter/filter-template/selection-filter-template/selection-filter-template.model';
import { AccessRoles } from '@app/core/services/administrator/models/accessRoles';
import { Sort } from '@app/shared/components/table/sort/sort.model';
import { Page } from '@app/core/services/commons/page';

@Component({
  selector: 'app-customer-requests-list',
  templateUrl: './customer-requests-list.component.html',
  styleUrls: ['./customer-requests-list.component.css']
})
export class CustomerRequestsListComponent extends AbstractOnDestroyComponent implements OnInit {

  filterData: FilterData;
  customerRequests: CustomerRequest[];
  accessRoles = AccessRoles;
  loading: boolean = true;
  pagination: Pagination;
  sort: Sort;
  admin: KeycloakProfile;

  constructor(
    private customerRequestService: CustomerRequestService,
    private route: ActivatedRoute,
    private keycloakService: KeycloakService,
    private translate: TranslateService,
    private toastr: ToastrService,
    private router: Router
  ) {
    super();
    /* Define possible filter */
    const templates = [
      new TextFilterTemplate('customerRequestId', 'CUSTOMER_REQUEST.LABELS.NUMBER'),
      new TextFilterTemplate('fuzzyCustomerFirstName', 'CUSTOMER_REQUEST.LABELS.CUSTOMER_FIRST_NAME'),
      new TextFilterTemplate('fuzzyCustomerLastName', 'CUSTOMER_REQUEST.LABELS.CUSTOMER_LAST_NAME'),
      new TextFilterTemplate('fuzzyAdminFirstName', 'CUSTOMER_REQUEST.LABELS.AGENT_FIRST_NAME'),
      new TextFilterTemplate('fuzzyAdminLastName', 'CUSTOMER_REQUEST.LABELS.AGENT_LAST_NAME'),

      new SelectionFilterTemplate('status', 'CUSTOMER_REQUEST.LABELS.STATUS', [
        { label: 'Fermée', value: 'CLOSED' },
        { label: 'Assignée', value: 'ASSIGNED' },
        { label: 'Ouverte', value: 'OPEN' },
      ])
    ];

    this.filterData = new FilterData('customerrequests', templates);
  }

  ngOnInit() {
    /* If encoded URL filter change after reload (navigate to same page with a diffrent filter), same thing with filter */
    this.route.queryParamMap.subscribe(params => {
      this.filterData.decode(params.get('filter') || '');
      if (params.has("sortElement") && params.has("sortOrder")) {
        this.sort = new Sort(params.get('sortElement'), <'ASC' | 'DESC'> params.get('sortOrder'))
      } else {
        this.sort = null;
      }
    });

    /* If filterData change then reload the page (get data with resolver) */
    this.filterData.onChange$.subscribe(e => {
      this.router.navigate(['customerrequests'], {queryParams: {
        filter: this.filterData.encode()
      }})
    });

    /* Get data from resolver */
    this.route.data.subscribe((data: { customerRequests: Page<CustomerRequest>, admin: Keycloak.KeycloakProfile }) => {
      this.customerRequests = data.customerRequests.content;
      this.pagination = {
        elements: data.customerRequests.size,
        totalElements: data.customerRequests.totalElements,
        page: data.customerRequests.number,
        totalPages: data.customerRequests.totalPages
      };
      this.admin = data.admin;
      this.loading = false;
    });
  }

  filterByPaginationSize(size: number) {
    this.pagination.elements = size;
    this.router.navigate(['customerrequests'], {
      queryParams: {
        pageSize: this.pagination.elements,
        filter: this.filterData.encode(),
        sortElement: this.sort && this.sort.field,
        sortOrder: this.sort && this.sort.order
      }
    });
  }

  filterByPagination(page: number) {
    this.pagination.page = page;
    this.router.navigate(['customerrequests'], {
      queryParams: {
        pageNumber: this.pagination.page,
        pageSize: this.pagination.elements,
        filter: this.filterData.encode(),
        sortElement: this.sort && this.sort.field,
        sortOrder: this.sort && this.sort.order
      }
    });
  }

  filterBySort(sort: Sort) {
    this.sort = sort;
    this.router.navigate(['customerrequests'], {
      queryParams: {
        pageSize: this.pagination.elements,
        filter: this.filterData.encode(),
        sortElement: this.sort.field,
        sortOrder: this.sort.order
      }
    });
  }

  /* Call API to close ticket, display notification and reload data */
  closeTicket(curstomerRequestId: number) {
    const closingComment = <Comment> {
      notifiable: true,
      content: "Closing ticket #" + curstomerRequestId,
      writer: {
        adminReference: this.keycloakService.getKeycloakInstance().subject,
        email: this.admin.email,
        firstName: this.admin.firstName,
        lastName: this.admin.lastName
      }
    };
    // Call the API to close the customerRequest
    this.customerRequestService.close(curstomerRequestId, closingComment)
      .pipe( takeUntil(this.unsubscribe) )
      .subscribe(
        // Notify user and refresh page
        _customerRequest => {
          this.toastr.success(this.translate.instant('TOAST.SUCCESS.CLOSE'));
          this.router.navigate(['customerrequests'], {
            queryParams: {
              pageNumber: this.pagination.page,
              pageSize: this.pagination.elements,
              filter: this.filterData.encode(),
              sortElement: this.sort && this.sort.field,
              sortOrder: this.sort && this.sort.order
            }
          });
        },
        _err => this.toastr.error(this.translate.instant('TOAST.ERROR.FAILED'))
    );
  }

}
