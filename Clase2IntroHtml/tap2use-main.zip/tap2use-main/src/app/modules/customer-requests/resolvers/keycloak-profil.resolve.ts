import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { KeycloakService } from 'keycloak-angular';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class KeycloakProfilResolver implements Resolve<Keycloak.KeycloakProfile> {
  constructor(private keycloakService: KeycloakService) { }
  
  resolve(route: ActivatedRouteSnapshot): Observable<Keycloak.KeycloakProfile> | Promise<Keycloak.KeycloakProfile> {
    return this.keycloakService.loadUserProfile();
  }
}