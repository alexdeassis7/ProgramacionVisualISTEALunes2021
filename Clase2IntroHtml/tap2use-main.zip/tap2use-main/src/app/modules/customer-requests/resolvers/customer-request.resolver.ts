import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { Page } from '@app/core/services/commons/page';
import { CustomerRequestService } from '@app/core/services/customer-request/customer-request.service';
import { CustomerRequest } from '@app/core/services/customer-request/model/customerRequest';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class CustomerRequestsResolver implements Resolve<Page<CustomerRequest>> {

  constructor(private customerRequestService: CustomerRequestService) { }

  resolve(route: ActivatedRouteSnapshot): Observable<Page<CustomerRequest>> {
    const pageNumber = +route.queryParamMap.get('pageNumber') || 0;
    const pageSize = +route.queryParamMap.get('pageSize') || 10;
    const sortOrder = route.queryParamMap.get('sortOrder') || '';
    const sortElement = route.queryParamMap.get('sortElement') || '';
    const filterEncode = route.queryParamMap.get('filter') || '';

    const filter = {};
    if(filterEncode) {
      filterEncode.split('|')
        .filter(s => s.match(/.*\~[0-1]\~.*/))
        .filter(s => {
          const enabled = s.split('~')[1] == '1';
          return enabled;
        })
        .forEach(s => {
          const key = s.split('~')[0];
          const value = s.split('~')[2];

          filter[key] = value;
        });
    }

    return this.customerRequestService.findCustomerRequests(
      filter,
      sortOrder,
      sortElement,
      pageNumber,
      pageSize);
  }
}
