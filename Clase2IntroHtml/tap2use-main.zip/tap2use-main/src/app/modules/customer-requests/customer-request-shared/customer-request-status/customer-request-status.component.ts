import { Component, OnInit, Input } from '@angular/core';
import { CustomerRequest } from '@app/core/services/customer-request/model/customerRequest';

@Component({
  selector: 'app-customer-request-status',
  templateUrl: './customer-request-status.component.html',
  styleUrls: ['./customer-request-status.component.css']
})
export class CustomerRequestStatusComponent implements OnInit {

  @Input()
  status: CustomerRequest.StatusEnum;

  constructor() { }

  ngOnInit() {
  }

}
