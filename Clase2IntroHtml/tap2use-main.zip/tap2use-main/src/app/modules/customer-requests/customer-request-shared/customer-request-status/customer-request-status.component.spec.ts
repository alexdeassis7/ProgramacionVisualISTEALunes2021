import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerRequestStatusComponent } from './customer-request-status.component';

describe('CustomerRequestStatusComponent', () => {
  let component: CustomerRequestStatusComponent;
  let fixture: ComponentFixture<CustomerRequestStatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerRequestStatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerRequestStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
