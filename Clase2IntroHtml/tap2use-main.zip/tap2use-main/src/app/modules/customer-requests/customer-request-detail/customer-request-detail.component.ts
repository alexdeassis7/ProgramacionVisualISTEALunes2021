import { Component, OnInit, ViewChild } from '@angular/core';
import { CustomerRequestService } from '@app/core/services/customer-request/customer-request.service';
import { ActivatedRoute } from '@angular/router';
import { CustomerRequest } from '@app/core/services/customer-request/model/customerRequest';
import { Comment } from '@app/core/services/customer-request/model/comment';
import { KeycloakService } from 'keycloak-angular';
import { KeycloakProfile } from 'keycloak-js';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { AccessRoles } from '@app/core/services/administrator/models/accessRoles';
import { SimpleModalService } from 'ngx-simple-modal';
import { AdministratorService } from '@app/core/services/administrator/administrator.service';
import { UserAdmin } from '@app/core/services/administrator/models/userAdmin';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { takeUntil } from 'rxjs/operators';
import {environment} from '@env/environment';

@Component({
  selector: 'app-customer-request-detail',
  templateUrl: './customer-request-detail.component.html',
  styleUrls: ['./customer-request-detail.component.css']
})
export class CustomerRequestDetailComponent extends AbstractOnDestroyComponent implements OnInit {
  customerRequest: CustomerRequest;
  agent: KeycloakProfile;
  adminReference: string;

  errGettingData = false;
  loaded = false;
  empty = false;
  genericEmail = environment.defaultValue.genericEmail;
  modalTitle;
  modalMsg;
  modalConfirm;
  modalCancel;
  vibility;

  accessRoles = AccessRoles;

  @ViewChild('comments') commentsItem;

  comment: Comment;
  closingComment: Comment = {};

  adminAgent: UserAdmin;

  constructor(
    private customerRequestService: CustomerRequestService,
    private simpleModalService: SimpleModalService,
    private route: ActivatedRoute,
    private keycloakService: KeycloakService,
    private toastr: ToastrService,
    protected translate: TranslateService,
    private adminsitratorService: AdministratorService
  ) {
    super();
  }

  ngOnInit() {
    this.adminReference = this.keycloakService.getKeycloakInstance().subject;

    this.vibility = 'none';
    this.keycloakService.loadUserProfile().then(agent => {
      this.agent = agent;


      this.adminsitratorService.getAdministratorByKCId(this.adminReference)
      .pipe( takeUntil(this.unsubscribe) )
      .subscribe(
      res => {
        this.adminAgent = res;
      },
      err => {
       this.toastr.error(err);
      });


      this.comment = {
        content: '',
        writer: {
          adminReference: this.adminReference,
          email: this.agent.email,
          firstName: this.agent.firstName,
          lastName: this.agent.lastName
        }
      };

      this.closingComment = {
        content: '',
        notifiable: true,
        writer: {
          adminReference: this.adminReference,
          email: this.agent.email,
          firstName: this.agent.firstName,
          lastName: this.agent.lastName
        }
      };
    });

    this.route.params.subscribe(params => {
      this.customerRequestService.findCustomerRequest(params['customerRequestId'])
      .pipe( takeUntil(this.unsubscribe) )
      .subscribe(
        customerRequest => {
          this.loaded = true;
          this.customerRequest = customerRequest;
          this.empty = this.customerRequest == null ? true : false;
          this.customerRequest.comments
          .sort((a, b) => new Date(b.creationDate).getTime() - new Date(a.creationDate).getTime());
          setTimeout(
            () =>
              (this.commentsItem.nativeElement.scrollTop = this.commentsItem.nativeElement.scrollHeight),
            0
          );
        },
        err => {
          this.loaded = true;
          this.errGettingData = true;
        }
      );
    });
  }

  createComment() {
    if (this.genericEmail != null && this.genericEmail !== '') {
      this.comment.writer.email = this.genericEmail;
    }

    this.customerRequestService.createComment(this.customerRequest.id, this.comment)
    .pipe( takeUntil(this.unsubscribe) )
    .subscribe(
      () => {
        this.comment.content = '';
        this.customerRequestService.findCustomerRequest(this.customerRequest.id)
        .pipe( takeUntil(this.unsubscribe) )
        .subscribe(
          customerRequest => {
            this.customerRequest = customerRequest;
            this.customerRequest.comments
              .sort(
                (a, b) => new Date(b.creationDate).getTime() - new Date(a.creationDate).getTime()
              )
              .reverse();
            setTimeout(
              () =>
                (this.commentsItem.nativeElement.scrollTop = this.commentsItem.nativeElement.scrollHeight),
              0
            );
          },
          err => (this.errGettingData = true)
        );
      },
      err => true
    );
  }

  freeCustomerRequest() {
    this.customerRequestService.deleteAdmin(this.customerRequest.id)
    .pipe( takeUntil(this.unsubscribe) )
    .subscribe(customerRequest => {
      this.customerRequestService.refreshRequestCustomerCounter();
      this.customerRequest = customerRequest;
      this.customerRequest.comments
        .sort((a, b) => new Date(b.creationDate).getTime() - new Date(a.creationDate).getTime())
        .reverse();
      setTimeout(
        () =>
          (this.commentsItem.nativeElement.scrollTop = this.commentsItem.nativeElement.scrollHeight),
        0
      );
    },
    err => true);
  }

  sendEmailCommentaire() {
  }

  assignCustomerRequest() {
    this.customerRequestService
      .assignAdmin(this.customerRequest.id, this.comment.writer)
      .pipe( takeUntil(this.unsubscribe) )
      .subscribe(customerRequest => {
        this.customerRequestService.refreshRequestCustomerCounter();

        this.customerRequest = customerRequest;
        this.customerRequest.comments
          .sort((a, b) => new Date(b.creationDate).getTime() - new Date(a.creationDate).getTime())
          .reverse();
        setTimeout(
          () =>
            (this.commentsItem.nativeElement.scrollTop = this.commentsItem.nativeElement.scrollHeight),
          0
        );
      },
      err => true);
  }

  closeCustomerRequest() {
    this.translate.get('CUSTOMER_REQUEST.MESSAGE.CLOSING_TICKET').subscribe((res: string) => {
      this.closingComment.content = res + this.customerRequest.id;
    });
    if (this.genericEmail != null && this.genericEmail !== '') {
      this.closingComment.writer.email = this.genericEmail;
    }

    this.customerRequestService.close(this.customerRequest.id, this.closingComment)
    .pipe( takeUntil(this.unsubscribe) )
    .subscribe(customerRequest => {
      this.customerRequestService.refreshRequestCustomerCounter();
      this.translate.get('TOAST.SUCCESS.CLOSE').subscribe(msg => this.toastr.success(msg));
      this.customerRequest = customerRequest;
      this.customerRequest.comments
        .sort((a, b) => new Date(b.creationDate).getTime() - new Date(a.creationDate).getTime())
        .reverse();
      setTimeout(
        () =>
          (this.commentsItem.nativeElement.scrollTop = this.commentsItem.nativeElement.scrollHeight),
        0
      );
    },
    err => true);
  }

  closeRequest(action: String) {
    if (this.comment.content !== '') {
      if (action === 'yes') {
        this.createComment();
        this.closeCustomerRequest();
      } else if (action === 'no') {
        this.closeCustomerRequest();
      }
    } else {
        this.closeCustomerRequest();
    }
  }
}
