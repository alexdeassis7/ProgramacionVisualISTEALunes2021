import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { TranslateService } from '@ngx-translate/core';
import { environment } from '@env/environment';

@Component({
  selector: 'app-cgu',
  templateUrl: './cgu.component.html',
  styleUrls: ['./cgu.component.css'],
  host: {
    class: 'main-container'
  }
})
export class CguComponent implements OnInit {
  source: any;

  constructor(
    private sanitizer: DomSanitizer,
    private translate: TranslateService
  ) {
    switch (this.translate.currentLang) {
      case 'en':
          this.source = this.sanitizer.bypassSecurityTrustResourceUrl(environment.defaultValue.assetsPage.basePathCGU + '/CGU_en.html');
          break;
      case 'fr':
          this.source = this.sanitizer.bypassSecurityTrustResourceUrl(environment.defaultValue.assetsPage.basePathCGU + '/CGU_fr.html');
          break;
      case 'de':
          this.source = this.sanitizer.bypassSecurityTrustResourceUrl(environment.defaultValue.assetsPage.basePathCGU + '/CGU_de.html');
          break;
      default:
          this.source = this.sanitizer.bypassSecurityTrustResourceUrl(environment.defaultValue.assetsPage.basePathCGU + '/CGU_fr.html');
          break;
    }
  }
  ngOnInit() {  }

}
