import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '@app/shared/shared.module';

import { ErrorsComponent } from './errors.component';
import { ErrorsRoutingModule } from './errors-routing.module';

@NgModule({
  imports: [CommonModule, SharedModule, ErrorsRoutingModule],
  declarations: [ErrorsComponent],
  exports: [ErrorsComponent]
})
export class ErrorsModule {}
