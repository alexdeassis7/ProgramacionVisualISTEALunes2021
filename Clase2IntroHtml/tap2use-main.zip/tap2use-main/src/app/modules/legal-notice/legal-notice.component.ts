import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { TranslateService } from '@ngx-translate/core';
import { environment } from '@env/environment';

@Component({
  selector: 'app-legal-notice',
  templateUrl: './legal-notice.component.html',
  styleUrls: ['./legal-notice.component.css'],
  host: {
    class: 'main-container'
  }
})
export class LegalNoticeComponent implements OnInit {

  source: any;

  constructor(
    private sanitizer: DomSanitizer,
    private translate: TranslateService
  ) {
    switch (this.translate.currentLang) {
      case 'en':
          this.source = this.sanitizer.bypassSecurityTrustResourceUrl(environment.defaultValue.assetsPage.basePathMentionLegal + '/MentionLegal_en.html');
          break;
      case 'fr':
          this.source = this.sanitizer.bypassSecurityTrustResourceUrl(environment.defaultValue.assetsPage.basePathMentionLegal + '/MentionLegal_fr.html');
          break;
      case 'de':
          this.source = this.sanitizer.bypassSecurityTrustResourceUrl(environment.defaultValue.assetsPage.basePathMentionLegal + '/MentionLegal_de.html');
          break;
      default:
          this.source = this.sanitizer.bypassSecurityTrustResourceUrl(environment.defaultValue.assetsPage.basePathMentionLegal + '/MentionLegal_fr.html');
          break;
    }
  }

  ngOnInit() {  }

}
