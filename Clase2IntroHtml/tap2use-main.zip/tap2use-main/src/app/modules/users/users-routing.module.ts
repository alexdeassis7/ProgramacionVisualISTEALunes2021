import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserManagementComponent } from './user-management/user-management.component';
import { AppAuthGuard } from '@app/core/guards/authguard';
import { AccessRoles } from '@app/core/services/administrator/models/accessRoles';
import { UserIdentityComponent } from './user-management/user-identity/user-identity.component';
import { UserJourneyComponent } from './user-management/user-journey/user-journey.component';
import { UserSavComponent } from './user-management/user-sav/user-sav.component';
import { UserActionHistoryComponent } from './user-management/user-action-history/user-action-history.component';
import { UserListComponent } from './user-list/user-list.component';
import { UserResolver } from './resolvers/user.resolver';
import { UsersResolver } from './resolvers/users.resolver';
import { IdentityAccessMediasResolver } from './resolvers/identity/identity-access-medias.resolver';
import { UserAccessmediasComponent } from './user-management/user-accessmedias/user-accessmedias.component';
import { IdentityUserResolver } from './resolvers/identity/identity-user.resolver';
import { SipsDebtRecoveryComponent } from './user-management/user-settlements/sips-debt-recovery/sips-debt-recovery.component';
import { UserSettlementsComponent } from './user-management/user-settlements/user-settlements.component';
import { UserJourneyRefundComponent } from './user-management/user-journey/user-journey-refund/user-journey-refund.component';
import { UserCustomerRequestsResolver } from './resolvers/user-customer-requests.resolver';

const routes: Routes = [
  {
    path: '',
    component: UserListComponent,
    canActivate: [AppAuthGuard],
    data: { role: [AccessRoles.ROLE_SUPER_ADMIN, AccessRoles.ROLE_ADMIN, AccessRoles.ROLE_SAV, AccessRoles.ROLE_AGENT] }
  },
  {
    path: ':id/:ref',
    component: UserManagementComponent,
    resolve: {
      user: UserResolver
    },
    canActivate: [AppAuthGuard],     data: { role: [AccessRoles.ROLE_SUPER_ADMIN, AccessRoles.ROLE_ADMIN, AccessRoles.ROLE_SAV, AccessRoles.ROLE_AGENT] },
    children: [
      { path: '', redirectTo: 'identity', pathMatch: 'full' },
      { path: 'identity', component: UserIdentityComponent, resolve: { user: IdentityUserResolver }, runGuardsAndResolvers: 'always' },
      { path: 'accessmedia', component: UserAccessmediasComponent, resolve: { accessMedias: IdentityAccessMediasResolver }, runGuardsAndResolvers: 'always' },
      { path: 'settlements/:settlementOrigin/:settlementId/debt-recovery', component: SipsDebtRecoveryComponent },
      { path: 'settlements', component: UserSettlementsComponent, resolve: { accessMedias: IdentityAccessMediasResolver } },
      { path: 'journeys', component: UserJourneyComponent, resolve: { accessMedias: IdentityAccessMediasResolver }},
      { path: 'journeys/refund', component: UserJourneyRefundComponent, resolve: { accessMedias: IdentityAccessMediasResolver } },
      { path: 'actions', component: UserActionHistoryComponent },
      { path: 'sav', component: UserSavComponent, resolve: { customerRequests: UserCustomerRequestsResolver }, runGuardsAndResolvers: 'always' },
    ]
  }
];

@NgModule({
imports: [
  RouterModule.forChild(routes)
],
exports: [
  RouterModule
],
providers: [
  UserResolver,
  UsersResolver,
  IdentityUserResolver,
  IdentityAccessMediasResolver,
  UserCustomerRequestsResolver
]
})
export class UsersRoutingModule { }
