import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, MatSortable } from '@angular/material/sort';
import { UserService } from '@app/core/services/user/user.service';
import { MobilityAccount } from '@modelUser/mobilityAccount';
import { ToastrService } from 'ngx-toastr';
import { merge } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';
import { TableDataSource } from '@app/core/services/util/tableDataSource';
import { tap, takeUntil } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { environment } from '@env/environment';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent extends AbstractOnDestroyComponent implements OnInit, AfterViewInit {

  pageSize = environment.defaultValue.pageSize;
  showFilters = false;
  delete = false;
  displayedColumns = [
    'EMAIL',
    'LAST_NAME',
    'FIRST_NAME',
    'STATUS',
    'ACTIONS'
  ];
  collapse = 'collapse';
  listStatus = ['INITIALIZED', 'ACTIVE', 'CANCELLED'];


  filtersInput = {
    email: '',
    firstName: '',
    lastName: '',
    status: 'ACTIVE'
  };


  filtersApplied = Object.assign({}, this.filtersInput);

  searchInput = '';
  lastFilterCalled = this.loadData;


  errGettingData = false;
  loaded = false;
  empty = false;

  totalItems = 0;

  users: MobilityAccount[] = [];
  dataSource: TableDataSource<MobilityAccount>;

  errType;
  errMsg;

  @ViewChild(MatPaginator, { static: true })
  paginator: MatPaginator;

  @ViewChild(MatSort, { static: true })
  sort: MatSort;

  constructor(
    protected userService: UserService,
    private toastr: ToastrService,
    protected translate: TranslateService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    super();
  }

  ngOnInit() {
    this.dataSource = new TableDataSource<MobilityAccount>();
  }

  ngAfterViewInit() {
    this.collapse = 'collapse';
    this.route.queryParams.subscribe(params => {
      if (params['filter'] === 'on') {
        this.collapse = 'collapse in';
        const filter: any = JSON.parse(sessionStorage.getItem('filter_user'));
        this.filtersInput.email = filter.email ? filter.email : '';
        this.filtersInput.firstName = filter.firstName ? filter.firstName : '';
        this.filtersInput.lastName = filter.lastName ? filter.lastName : '';
        this.filtersInput.status = filter.status ? filter.status : '';
        this.showFilters = true;
        this.filtersApplied = Object.assign({}, this.filtersInput);
      } else {
        this.filtersInput = {
          email: '',
          firstName: '',
          lastName: '',
          status: 'ACTIVE'
        };
        this.filtersApplied = Object.assign({}, this.filtersInput);
      }

      this.lastFilterCalled();
      // Listnen events from sort and paginator element
      this.sort.sortChange.pipe( takeUntil(this.unsubscribe) ).subscribe(
        res => {
          this.paginator.pageIndex = 0;
        }
      );
      merge(this.sort.sortChange, this.paginator.page).pipe(tap(() => this.lastFilterCalled()))
        .subscribe();
      });
  }

  loadData() {
    this.loaded = false;
    this.dataSource
      .loadData(
        this.userService.findUsersFromMobilityEngine(
          this.filtersApplied,
          this.sort.direction,
          this.sort.active,
          this.paginator.pageIndex,
          this.paginator.pageSize
        )
      )
      .subscribe(totalCount => {
        this.totalItems = totalCount;
        if (this.totalItems === -1) {
          this.errGettingData = true;
        } else if (this.totalItems === 0) {
          this.empty = true;
        } else {
          this.empty = false;
        }
        this.loaded = true;
      });
  }

  filterUsersPage() {
    sessionStorage.setItem('filter_user', JSON.stringify(this.filtersInput) );
    this.paginator.pageIndex = 0;
    if (!this.router.url.includes('filter')) {
      this.router.navigate([this.router.url], { queryParams: { filter: 'on' } });
    } else {
      if (this.router.url.includes('filter')) {
        const filter: any = JSON.parse(sessionStorage.getItem('filter_user'));
        this.filtersInput.email = filter.email ? filter.email : '';
        this.filtersInput.firstName = filter.firstName ? filter.firstName : '';
        this.filtersInput.lastName = filter.lastName ? filter.lastName : '';
        this.filtersInput.status = filter.status ? filter.status : '';
        this.showFilters = true;
        this.filtersApplied = Object.assign({}, this.filtersInput);
        this.lastFilterCalled = this.loadData;
        this.loadData();
        this.resetSort();
      } else {
        this.filtersInput = {
          email: '',
          firstName: '',
          lastName: '',
          status: ''
        };
        this.searchInput = '';
        this.filtersApplied = Object.assign({}, this.filtersInput);
        this.lastFilterCalled = this.loadData;
        this.loadData();
        this.resetSort();
      }
    }
  }

  resetFilter() {
    this.filtersInput = {
      email: '',
      firstName: '',
      lastName: '',
      status: ''
    };
    this.searchInput = '';
    this.filtersApplied = Object.assign({}, this.filtersInput);
    this.lastFilterCalled = this.loadData;
    this.resetSort();
  }

  viewFilters() {
    this.showFilters = !this.showFilters;
  }

  resetSort() {
    if (this.sort.active !== 'EMAIL') {
      this.sort.sort(<MatSortable>{ id: 'EMAIL', start: 'asc' });
    } else {
      this.paginator.pageIndex = 0;
      this.lastFilterCalled();
    }
  }

  multipleFilterUsersPage() {
    if (this.searchInput !== '') {
      this.lastFilterCalled = this.loadUserPageWithKeyWord;
      this.resetSort();
    }
  }

  receiveAlertDelete($event) {
    this.delete = $event;
    if (this.delete) {
      this.loadData();
    }
  }


  loadUserPageWithKeyWord() {
    // TODO: to call function in datasource for search with key word
    this.loaded = false;
    this.dataSource
      .loadData(
        this.userService.findUsersFromMobilityEngine(
          this.filtersApplied,
          this.sort.direction,
          this.sort.active,
          this.paginator.pageIndex,
          this.paginator.pageSize
        )
      )
      .pipe( takeUntil(this.unsubscribe) )
      .subscribe(totalCount => {
        this.totalItems = totalCount;
        if (this.totalItems === -1) {
          this.errGettingData = true;
        } else if (this.totalItems === 0) {
          this.empty = true;
        }
        this.loaded = true;
      });
  }

}
