import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-user-btn',
  templateUrl: './add-user-btn.component.html',
  styleUrls: ['./add-user-btn.component.css']
})
export class AddUserBtnComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
