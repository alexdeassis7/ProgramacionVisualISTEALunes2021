import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { SimpleModalService } from 'ngx-simple-modal';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { MobilityAccount } from '@app/core/services/user/models/mobilityAccount';
import { UserService } from '@app/core/services/user/user.service';
import { ConfirmComponent } from '@app/shared/components/confirm/confirm.component';
import { environment } from '@env/environment';
import { KeycloakService } from 'keycloak-angular';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { takeUntil } from 'rxjs/operators';


@Component({
  selector: 'app-list-actions',
  templateUrl: './list-actions.component.html',
  styleUrls: ['./list-actions.component.css']
})
export class ListActionsComponent extends AbstractOnDestroyComponent implements OnInit {

  @Input()
  user: MobilityAccount;

  private modalTitle: string;
  private modalMsg: string;
  private modalConfirm: string;
  private modalCancel: string;
  deleted = true;
  superAdmin : boolean = false;
  @Output() messageEvent = new EventEmitter<boolean>();
  cancelledState = environment.defaultValue.user.accountState.cancelled;

  constructor(
    private userService: UserService,
    private route: ActivatedRoute,
    private router: Router,
    private simpleModalService: SimpleModalService,
    private toastr: ToastrService,
    private keycloakService: KeycloakService,
    protected translate: TranslateService) {
      super();
    }

  ngOnInit() {
    if(this.keycloakService.getUserRoles().includes("SUPER_ADMIN") ){
      this.superAdmin = true;
    }

  }

  resignAccount() {
      // Display modal
      this.simpleModalService
        .addModal(ConfirmComponent, {
          title: this.modalTitle,
          message: this.modalMsg,
          confirmButton: this.modalConfirm,
          closeButton: this.modalCancel
        })
        .pipe( takeUntil(this.unsubscribe) )
        .subscribe(isConfirmed => {
          if (isConfirmed) {
           // Then cancel account
           this.userService.cancelUserAccount(this.user.mobilityAccountId)
           .pipe( takeUntil(this.unsubscribe) )
           .subscribe(() => {
              this.messageEvent.emit(this.deleted);
              this.translate.get('TOAST.SUCCESS.MODIFICATION').subscribe(msg => this.toastr.success(msg));
            }, () => {
              this.translate.get('TOAST.ERROR.FAILED').subscribe(msg =>this.toastr.error(msg));
            });
          }
        });

  }

}
