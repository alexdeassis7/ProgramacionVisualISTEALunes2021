import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserMonthFilterComponent } from './user-month-filter.component';

describe('UserMonthFilterComponent', () => {
  let component: UserMonthFilterComponent;
  let fixture: ComponentFixture<UserMonthFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserMonthFilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserMonthFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
