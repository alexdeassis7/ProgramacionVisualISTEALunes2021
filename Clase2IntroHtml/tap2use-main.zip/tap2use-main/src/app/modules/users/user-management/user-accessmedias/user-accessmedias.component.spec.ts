import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserAccessmediasComponent } from './user-accessmedias.component';

describe('UserAccessmediasComponent', () => {
  let component: UserAccessmediasComponent;
  let fixture: ComponentFixture<UserAccessmediasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserAccessmediasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserAccessmediasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
