import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserActionHistoryComponent } from './user-action-history.component';

describe('UserActionHistoryComponent', () => {
  let component: UserActionHistoryComponent;
  let fixture: ComponentFixture<UserActionHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserActionHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserActionHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
