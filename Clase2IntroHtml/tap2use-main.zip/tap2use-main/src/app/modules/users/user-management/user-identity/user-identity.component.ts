import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { MobilityAccount } from '@app/core/services/user/models/mobilityAccount';
import { UserService } from '@app/core/services/user/user.service';
import { ToastrService } from 'ngx-toastr';
import { mergeMap, takeUntil, pluck } from 'rxjs/operators';
import { MobilityAccountContactDetailsDTO } from '@app/core/services/user/models/mobilityAccountContactDetailsDTO';
import { MobilityAccountIdentityDTO } from '@app/core/services/user/models/mobilityAccountIdentityDTO';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { FormGroup, FormControl, ValidatorFn, AbstractControl } from '@angular/forms';

@Component({
  selector: 'app-user-identity',
  templateUrl: './user-identity.component.html',
  styleUrls: ['./user-identity.component.css']
})
export class UserIdentityComponent extends AbstractOnDestroyComponent implements OnInit {

  user: MobilityAccount;
  userForm: FormGroup;
  userSaving = false;

  constructor(
    private userService: UserService,
    private route: ActivatedRoute,
    private toastr: ToastrService,
    protected translate: TranslateService,
    ) {
      super();

      this.userForm = new FormGroup({
        firstName: new FormControl(''),
        lastName: new FormControl(''),
        phone: new FormControl('')
      }, this.validIdentity());

    }

  ngOnInit() {
    // Get user
    this.route.data.pipe(pluck('user')).subscribe((user: MobilityAccount) => {
      this.user = user
      this.setUserFormValues();
    });
  }

  submitIdentity() {
    if(this.userForm.valid) {
      this.userSaving = true;
      const mobilityAccountIdentity = this.user.mobilityAccountIdentity || <MobilityAccountIdentityDTO>{ mobilityAccountId: this.user.mobilityAccountId };
      mobilityAccountIdentity.mobilityAccountFirstName = this.userForm.value.firstName || null;
      mobilityAccountIdentity.mobilityAccountLastName = this.userForm.value.lastName || null;
      mobilityAccountIdentity.mobilityAccountIdentityStatus = 'VERIFIED';

      const contact = this.user.mobilityAccountContactDetails || <MobilityAccountContactDetailsDTO>{};
      contact.mobilityAccountPhoneNumber = this.userForm.value.phone || null;

      this.userService.updateContactDetails(this.user.mobilityAccountId, contact)
        .pipe(
          takeUntil(this.unsubscribe),
          mergeMap(_d => {
            if(mobilityAccountIdentity.mobilityAccountFirstName) {
              return this.userService.updateIdentity(this.user.mobilityAccountId, mobilityAccountIdentity);
            } else {
              return this.userService.deleteIdentity(this.user.mobilityAccountId);
            }
          }),
          mergeMap(_d => {
            return this.userService.getMobilityAccount(this.user.mobilityAccountId);
          })
        ).subscribe(user => {
          this.user = user;
          this.setUserFormValues();
          this.userSaving = false;
          this.toastr.success(this.translate.instant('USER.MODALS.DELETE.CONFIRM'));
        });
  
    }
  }

  private setUserFormValues() {
    if(this.user.mobilityAccountIdentity) {
      this.userForm.setValue({
        firstName: this.user.mobilityAccountIdentity.mobilityAccountFirstName,
        lastName: this.user.mobilityAccountIdentity.mobilityAccountLastName,
        phone: this.user.mobilityAccountContactDetails.mobilityAccountPhoneNumber
      });
    }
  }

  private validIdentity(): ValidatorFn {
    return (control: AbstractControl): {[key: string]: any} | null => {
      const isValid = (control.value.lastName) || (!control.value.firstName && !control.value.phone);
      return !isValid ? { identityEmpty: {value: control.value}} : null;
    };
  }
}
