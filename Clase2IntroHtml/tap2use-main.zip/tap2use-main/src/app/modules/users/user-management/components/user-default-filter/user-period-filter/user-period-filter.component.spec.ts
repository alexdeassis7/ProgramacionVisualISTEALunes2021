import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserPeriodFilterComponent } from './user-period-filter.component';

describe('UserPeriodFilterComponent', () => {
  let component: UserPeriodFilterComponent;
  let fixture: ComponentFixture<UserPeriodFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserPeriodFilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserPeriodFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
