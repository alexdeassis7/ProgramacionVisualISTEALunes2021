import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserDefaultFilterComponent } from './user-default-filter.component';

describe('UserDefaultFilterComponent', () => {
  let component: UserDefaultFilterComponent;
  let fixture: ComponentFixture<UserDefaultFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserDefaultFilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserDefaultFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
