import { Component, Input, OnInit } from '@angular/core';
import { Location } from '@app/core/services/journey/models/location';
import { TransportMode } from '@app/core/services/journey/models/location';
import { environment } from '@env/environment';

@Component({
  selector: 'ap-line',
  template: `<span class="line-logo" [style.border-radius]="radius" [style.color]="color" [style.background-color]="background" [style.border-color]="border">{{ location.line }}</span>`,
  styles: [`
  .line-logo {
    line-height: 1.8em;
    height: 24px;
    display: inline-block;
    min-width: 24px;
    text-align: center;
    background: #fff;
    border: 1px solid #fff;
    border-radius: 19px;
  
    color: #777;
    font-weight: bold;
  
    padding-right: 5px;
    padding-left: 5px;
  }
  `]
})
export class LineComponent implements OnInit {

  @Input() location: Location;

  color: string;
  background: string;
  border: string;
  radius: string;

  constructor() { }

  ngOnInit() {
    this.colors(this.location.transportMode);
  }

  private colors(transportMode: TransportMode) {
    let colors: string[] = ['#777777', '#fff', '#fff'];

    if(environment.defaultValue.topology && environment.defaultValue.topology[transportMode]) {
      const line = environment.defaultValue.topology[transportMode].lines.find(l => l.refs.includes(this.location.line));
      if(line) {
        colors = line.colors.split('|')
      } else {
        colors = environment.defaultValue.topology[transportMode].default.split('|')
      }
    } else {
      colors = environment.defaultValue.topology.defaut.split('|');
    }
    
    this.color = colors[0];
    this.background = colors[1];
    this.border = colors[2];

    if(colors[3]) {
      this.radius = colors[3] + 'px';
    } else {
      this.radius = '19px';
    }
  }

}
