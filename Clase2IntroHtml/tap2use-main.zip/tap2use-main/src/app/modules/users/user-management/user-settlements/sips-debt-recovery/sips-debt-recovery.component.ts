import { Component, OnInit } from '@angular/core';
import { FinancialEngineService } from '@app/core/services/financial-engine/financial-engine.service';
import { SipsRequest } from '@app/core/services/financial-engine/models/sipsRequest';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { environment } from '@env/environment';
import { AccessMediaService } from '@app/core/services/access-media/access-media.service';
import { concatMap, delay, map, retryWhen, takeUntil } from 'rxjs/operators';
import { iif, of, throwError } from 'rxjs';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { SipsResponse } from '@app/shared/components/sips/sips-response.model';
import { SettlementSummary } from '@app/core/services/financial-engine/models/settlementSummary';

@Component({
  selector: 'app-sips-debt-recovery',
  templateUrl: './sips-debt-recovery.component.html',
  styleUrls: ['./sips-debt-recovery.component.css']
})
export class SipsDebtRecoveryComponent extends AbstractOnDestroyComponent implements OnInit {

  state: 'LOADING' | 'SIPS' | 'DONE' | 'ERROR_GENERATE_SIPS' | 'ERROR_MAX_TRY' | 'ERROR_NOT_SAME_CARD';

  sipsRequest: SipsRequest;

  userId: string;
  private transportOfferRef: string;
  private origin: string;
  accessMediaReference: string;
  lastNumberCard: string;

  constructor(
    private financialEngineService: FinancialEngineService,
    private accessMediaService: AccessMediaService,
    private route: ActivatedRoute,
    private translate: TranslateService,
    private router: Router
  ) {
    super();
  }

  ngOnInit() {
    this.userId = this.route.parent.snapshot.params.id;
    this.accessMediaReference = this.route.parent.snapshot.params.ref;
    this.transportOfferRef = this.route.snapshot.params.settlementId;
    this.origin = this.route.snapshot.params.settlementOrigin;

    this.init();
  }

  /**
   * Get link to display paypage sips.
   */
  init() {
    // Display message for waiting process
    this.state = 'LOADING';

    const template = environment.defaultValue.sipstemplate.tap2usePayment;
    const returnUrl = environment.api.sipsNormalReturnAuthorization;
    const channel = 'MOTO';
    const locale = this.translate.currentLang;

    this.financialEngineService.generateSipsRequest(this.origin, this.transportOfferRef, template, channel, locale, returnUrl).subscribe(sipsRequest => {
        this.sipsRequest = sipsRequest;
        this.state = 'SIPS';
      }, response => {
        if(response.error && response.error.code == 455) {
          // Display message to warn about max try attempt
          this.state = 'ERROR_MAX_TRY';
        } else {
          // Display message for generic error
          this.state = 'ERROR_GENERATE_SIPS';
        }
      });
  }

  /**
   * Callback to paypage sips after payment
   * 
   * @param sipsResponse 
   */
  receiveFromSips(sipsResponse: SipsResponse) {
    // Display message for waiting process
    this.state = 'LOADING';
    
    const accessMediaReferenceExpected = atob(this.sipsRequest.data).match(/originAccessMediaReference=([^;]+);/)[1];
    this.sipsRequest = null;
    
    // Test if response code is good
    if(sipsResponse && sipsResponse.responseCode === '00') {  
      this.accessMediaService.getAccessMediaByByTypeAndReference('BANK_CARD', accessMediaReferenceExpected).subscribe(accessMedia => {
        if(sipsResponse.paymentToken != accessMediaReferenceExpected) {
          // Retreive the 4 last numbers of the card
          this.lastNumberCard = accessMedia.accessMediaDescription.match(/############([0-9]{4})/)[1];
          this.state = 'ERROR_NOT_SAME_CARD';
        } else {
          this.financialEngineService.findSettlement(this.transportOfferRef).pipe(
              map((settlement: SettlementSummary) => {
                if(settlement.status !== 'EXECUTED') {
                  return true;
                }
                throw new Error('Settlement executed not found');
              })
            ).pipe(
              retryWhen(errors => errors.pipe(
                takeUntil(this.unsubscribe),
                concatMap((e, i) => 
                  // Executes a conditional Observable depending on the result
                  // of the first argument
                  iif(
                    () => i > 10,
                    // If the condition is true we throw the error (the last error)
                    throwError(e),
                    // Otherwise we pipe this back into our stream and delay the retry
                    of(e).pipe(delay(1000)) 
                  )
                )
              )))
              .subscribe(_data => {
                this.state = 'DONE';
              }, _e => {
                this.state = 'ERROR_GENERATE_SIPS';
              });
        }
      });
    } else if(sipsResponse && sipsResponse.responseCode === '17') {
      this.router.navigate(['settlements'], {relativeTo: this.route.parent});
    }else {
      this.state = 'ERROR_GENERATE_SIPS';
    }
  }
}
