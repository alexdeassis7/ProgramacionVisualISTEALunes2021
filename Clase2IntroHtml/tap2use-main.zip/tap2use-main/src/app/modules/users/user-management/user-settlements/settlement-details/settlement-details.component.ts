import { Component, OnInit } from '@angular/core';
import { SimpleModalComponent } from "ngx-simple-modal";
import { environment } from '@env/environment';
import { SettlementUI } from '../user-settlements.component';

export interface ConfirmModel {
  settlementUI: SettlementUI;
}
@Component({
  templateUrl: './settlement-details.component.html',
  styleUrls: ['./settlement-details.component.css']
})
export class SettlementDetailsComponent extends SimpleModalComponent<ConfirmModel, null> implements ConfirmModel, OnInit {
  settlementUI: SettlementUI;
  descriptionPattern = /^([0-9]+)( - ([0-9]+))?$/;

  transport: boolean;
  line: boolean;
  vehicule: boolean;
  station: boolean;
  operator: boolean;

  constructor() {
    super();
  }

  ngOnInit() {
    this.transport = environment.defaultValue.displayedColumns.TRANSPORT_MODE ? true : false;
    this.line = environment.defaultValue.displayedColumns.LINE ? true : false;
    this.vehicule = environment.defaultValue.displayedColumns.RAME ? true : false;
    this.station = environment.defaultValue.displayedColumns.ORIGIN ? true : false;
    this.operator = environment.defaultValue.displayedColumns.SERVICE_OPERATOR ? true : false;
  }

}
