import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import * as moment from 'moment';

@Component({
  selector: 'ap-user-month-filter',
  templateUrl: './user-month-filter.component.html',
  styleUrls: ['./user-month-filter.component.css']
})
export class UserMonthFilterComponent implements OnInit {

  @Output("filter") filterEvent = new EventEmitter<any>();  

  date: Date;

  months = [];

  constructor() { }

  ngOnInit() {
    this.date = moment().startOf('month').toDate();
    this.months = Array.from(new Array(20), (x,i) => {return moment(this.date).subtract(i, 'months').toDate()});
  }

  selectDate(e) {
    this.date = moment.unix(e / 1000).toDate();
  }

  filter() {
    const from = moment(this.date).startOf('month');
    const to = moment(this.date).endOf('month');

    this.filterEvent.emit({
      'from': from.toDate(),
      'to': to.toDate()
    });
  }

}
