import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { FinancialEngineService } from '@app/core/services/financial-engine/financial-engine.service';
import { Settlement } from '@app/core/services/financial-engine/models/settlement';
import { environment } from '@env/environment';
import { UserService } from '@app/core/services/user/user.service';
import { TranslateService } from '@ngx-translate/core';
import { saveAs } from 'file-saver';
import { ToastrService } from 'ngx-toastr';
import { SimpleModalService } from 'ngx-simple-modal';
import { SettlementDetailsComponent } from './settlement-details/settlement-details.component';
import { Sort } from '@app/shared/components/table/sort/sort.model';
import { Pagination } from '@app/shared/components/pagination/pagination.model';
import { AccessMedia } from '@app/core/services/access-media/models/accessMedia';
import { map, pluck, takeUntil } from 'rxjs/operators';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { UserFilterRange } from '../components/user-default-filter/user-filter-range';
import { PageSettlement } from '@app/core/services/financial-engine/models/pageSettlement';

export interface AccessMediaUI extends AccessMedia {
  selected: boolean;
}

export interface SettlementUI extends Settlement {
  accessMedia: AccessMedia;
}

@Component({
  selector: 'app-user-settlements',
  templateUrl: './user-settlements.component.html',
  styleUrls: ['./user-settlements.component.css']
})

export class UserSettlementsComponent extends AbstractOnDestroyComponent implements OnInit {

  private mobilityAccountId: number;
  accessMedias: AccessMediaUI[];
  settlementsUI: SettlementUI[];
  loading = true;

  pagination: Pagination = {
    totalElements: 0,
    elements: 10,
    totalPages: 0,
    page: 0
  };

  sort: Sort = {
    field: 'paymentExecutionDate',
    order: 'ASC'
  };

  from: Date = moment().subtract(3, 'months').toDate();
  to: Date = moment().add(1, 'days').toDate();

  constructor(
    private financialEngineService: FinancialEngineService,
    private userService: UserService,
    private translate: TranslateService,
    private toastr: ToastrService,
    private route: ActivatedRoute,
    private simpleModalService: SimpleModalService,
    private router: Router
  ) {
    super();
  }

  ngOnInit() {
    this.mobilityAccountId = +this.route.parent.snapshot.paramMap.get('id');
    const accessMediaSelected = this.route.parent.snapshot.paramMap.get('ref');
    this.route.data
      .pipe(
        takeUntil(this.unsubscribe),
        pluck('accessMedias'),
        // Convert accessMedia to accessMediaUI
        map((accessMedias: AccessMedia[]) => {
          const accessMediaUIs = <AccessMediaUI[]> accessMedias;
          // Define if accessMedia is selected
          accessMediaUIs.forEach(a => a.selected = [a.accessMediaReference, 'all'].includes(accessMediaSelected));
          return accessMediaUIs;
        })
      )
      .subscribe((accessMedias: AccessMediaUI[]) => {
        this.accessMedias = accessMedias;
        this.loadSettlements();
      });
  }

  filterBySort(sort: Sort) {
    this.sort = sort;
    this.pagination.page = 0;
    this.loadSettlements();
  }

  filterByPagination(page: number) {
    this.pagination.page = page;
    this.loadSettlements();
  }

  filterByPaginationSize(size: number) {
    this.pagination.elements = size;
    this.pagination.page = 0;
    this.loadSettlements();
  }

  filterByDateRange(range: UserFilterRange) {
    this.from = range.from;
    this.to = range.to;
    this.pagination.page = 0;
    this.loadSettlements();
  }

  selectAccessMedia(selected: boolean, accessMedia: AccessMediaUI) {
    accessMedia.selected = selected;
    this.pagination.page = 0;
    this.loadSettlements();
  }

  settleDebt(settlement: SettlementUI) {
    this.router.navigate([settlement.origin, settlement.reference, 'debt-recovery'], {relativeTo: this.route});
  }

  downloadPdf(settlement: Settlement) {
    const serviceEmitter = environment.defaultValue.serviceEmitter.divia;

    this.userService.getReceiptData(settlement.reference, serviceEmitter).pipe(takeUntil(this.unsubscribe)).subscribe(data => {
      if (data.content.length === 0) {
        this.translate.get('TOAST.UNAUTHORIZED').subscribe(msg =>this.toastr.error(msg));
      } else {
        const receipt = (data.content[0] != null) ? data.content[0] : null ;
        const fileName = receipt.reference + '-' + this.mobilityAccountId + '-' + moment(settlement.createdAt).format('YYYYMMDD');
        this.userService.getPaymentPdf(
                          receipt.reference, receipt.serviceEmitter).pipe(takeUntil(this.unsubscribe)).subscribe((blob: Blob) => {
          saveAs(blob, fileName + '.pdf');
          const fileURL = URL.createObjectURL(blob);
          window.open(fileURL, '_blank');
        });
      }
    });

  }

  showDetails(settlementUI: SettlementUI) {
    const disposable = this.simpleModalService.addModal(SettlementDetailsComponent, {settlementUI: settlementUI}).subscribe(() => {});
    // If modal was not closed manually close it by timeout
    setTimeout(() => { disposable.unsubscribe(); }, 1000000);
  }

  private loadSettlements() {
    const selectedAccessMedias = this.accessMedias.filter(a => a.selected).map(a => a.accessMediaReference);
    this.loading = true;

    this.financialEngineService.findSettlementsByAccessMedias(selectedAccessMedias, this.from, this.to,
                            this.sort && this.sort.order, this.sort && this.sort.field, this.pagination.page, this.pagination.elements)
      .pipe(
        takeUntil(this.unsubscribe),
        // Convert Settlement to SettlementUI
        map((pageSettlement: PageSettlement) => {
          const settlementUIs = <SettlementUI[]> pageSettlement.content;
          this.pagination = {
            elements: pageSettlement.size,
            totalElements: pageSettlement.totalElements,
            page: pageSettlement.number,
            totalPages: pageSettlement.totalPages
          };
          // Set an accessMedia
          settlementUIs.forEach(s => s.accessMedia = this.accessMedias.find(a => a.accessMediaReference === s.accessMediaReference));
          return settlementUIs;
        })
      )
      .subscribe((settlementsUI: SettlementUI[]) => {
        this.settlementsUI = settlementsUI;
        this.loading = false;
      });
  }

}


