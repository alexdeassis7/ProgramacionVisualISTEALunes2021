import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';
import { FormGroup, ValidatorFn, AbstractControl, FormControl } from '@angular/forms';
import * as moment from 'moment';

@Component({
  selector: 'ap-user-period-filter',
  templateUrl: './user-period-filter.component.html',
  styleUrls: ['./user-period-filter.component.css']
})
export class UserPeriodFilterComponent implements OnInit {

  @Input() from: Date;
  @Input() to: Date;

  @Output("filter") filterEvent = new EventEmitter<any>();

  filterForm: FormGroup;

  constructor() {
    this.filterForm = new FormGroup({
      from: new FormControl(''),
      to: new FormControl(''),
    }, this.validRangeDate());
  }

  private validRangeDate(): ValidatorFn {
    return (control: AbstractControl): {[key: string]: any} | null => {
      const isInvalid = 
          control.value.from && 
          control.value.to && 
          moment(this.filterForm.value.from, 'YYYY-MM-DD').isAfter(moment(this.filterForm.value.to, 'YYYY-MM-DD'));
      
      return isInvalid ? { range: {value: control.value}} : null;
    };
  }

  ngOnInit() {
    this.filterForm.setValue({
      from: this.from ? moment(this.from).format('YYYY-MM-DD') : '',
      to: this.to ? moment(this.to).format('YYYY-MM-DD') : ''
    })
    
  }

  filter() {
    if (this.filterForm.valid) {
      const from = this.filterForm.value.from ? moment(this.filterForm.value.from, 'YYYY-MM-DD').startOf('day').toDate() : null;
      const to = this.filterForm.value.to ? moment(this.filterForm.value.to, 'YYYY-MM-DD').endOf('day').toDate() : null;
      
      this.filterEvent.emit({from, to});
    }
  }

}
