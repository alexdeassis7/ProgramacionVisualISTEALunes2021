export interface UserFilterRange {
  from: Date;
  to: Date;
}