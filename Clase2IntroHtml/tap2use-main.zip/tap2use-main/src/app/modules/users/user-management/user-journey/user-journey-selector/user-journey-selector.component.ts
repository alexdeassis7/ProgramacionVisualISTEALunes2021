import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FinancialEngineService } from '@app/core/services/financial-engine/financial-engine.service';
import { SettlementSummary } from '@app/core/services/financial-engine/models/settlementSummary';
import { Tap } from '@app/core/services/journey/models/tap';
import { environment } from '@env/environment';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { pluck } from 'rxjs/operators';

@Component({
  selector: 'ap-user-journey-selector',
  templateUrl: './user-journey-selector.component.html'
})

export class UserJourneySelectorComponent implements OnInit {

  @Input()
  get selectedRefundableTaps(): Set<string> { return this._selectedRefundableTaps; }
  set selectedRefundableTaps(selectedRefundableTaps: Set<string>) {
    this._selectedRefundableTaps = selectedRefundableTaps;
    this.computeRefundable();
  }
  _selectedRefundableTaps: Set<string>;    // tap's references for refunding

  @Input() tap: Tap;
  @Output() refund = new EventEmitter<boolean>();

  loading: boolean;
  refundable: boolean;
  allowedTypeToRefund = [ Tap.TypeEnum.VALIDATION, Tap.TypeEnum.PR ];

  constructor(private financialEngineService: FinancialEngineService,
              private toastr: ToastrService, private translateService: TranslateService) {
  }

  ngOnInit(): void {
    this.loading = false;
    this.computeRefundable();
  }

  selectToRefund(checked: boolean) {
    if (checked) {
      this.loading = true;
      this.financialEngineService.findSettlementsSummaryByTransactionIds([this.tap.transactionId])
        .pipe(pluck('content'))
        .subscribe((settlements: SettlementSummary[]) => {
          // 1st cndt - check that the tap's data is consistent and payment is done
          const maxNumberRefundableTap = environment.defaultValue.journey.taps.maxNumberRefundableTap;
          if (!settlements || settlements.length !== 1) {
            this.toastr.error(this.translateService.instant('JOURNEY.TAPS.TOAST.ERROR.MSG_REFUNDABLE_TAPS_ERROR_DATA'));
          } else if (settlements[0].cause !== SettlementSummary.CauseEnum.PAYMENT
                  || settlements[0].status !== SettlementSummary.StatusEnum.EXECUTED ) {
            this.toastr.error(this.translateService.instant('JOURNEY.TAPS.TOAST.ERROR.MSG_REFUNDABLE_TAPS_PAYMENT_UNDONE'));
          } else { // 2st cndt - check that the max number of refundable tap selected is not reached
            if ( this.selectedRefundableTaps.size === maxNumberRefundableTap ) {
              this.toastr.warning(this.translateService.instant('JOURNEY.TAPS.TOAST.WARNING.MSG_REFUNDABLE_TAPS_EXCEEDED',
                                                                    { maxNumberRefundableTap: maxNumberRefundableTap }));
            } else {
              this.refund.emit(true);
            }
          }
          this.loading = false;
        },
        _err => {
          this.loading = false;
          this.toastr.error(this.translateService.instant('JOURNEY.TAPS.TOAST.ERROR.MSG_REFUNDABLE_TAPS_ERROR_DATA'));
        });
    } else {
      this.refund.emit(false);
    }
  }

  private computeRefundable() {
    this.refundable = this.selectedRefundableTaps &&
                      [ Tap.TypeEnum.VALIDATION, Tap.TypeEnum.PR ].includes(this.tap.type) && this.tap.fare.amountMoney > 0;
  }

}
