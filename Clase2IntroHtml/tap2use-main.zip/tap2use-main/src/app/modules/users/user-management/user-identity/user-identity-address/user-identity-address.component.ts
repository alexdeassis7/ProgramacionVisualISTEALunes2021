import { Component, OnInit, Input } from '@angular/core';
import { MobilityAccountContactDetailsDTO } from '@app/core/services/user/models/mobilityAccountContactDetailsDTO';
import { UserService } from '@app/core/services/user/user.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { mergeMap, pluck } from 'rxjs/operators';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { AddressDTO } from '@app/core/services/user/models/addressDTO';

@Component({
  selector: 'ap-user-identity-address',
  templateUrl: './user-identity-address.component.html',
  styleUrls: ['./user-identity-address.component.css']
})
export class UserIdentityAddressComponent extends AbstractOnDestroyComponent implements OnInit {

  addressForm: FormGroup;
  addressDeleting = false;
  addressSaving = false;

  @Input()
  mobilityAccountContactDetails: MobilityAccountContactDetailsDTO;

  get street() { return this.addressForm.get('street'); }
  get city() { return this.addressForm.get('city'); }
  get zip() { return this.addressForm.get('zip'); }

  constructor(private userService: UserService, private translate: TranslateService, private toastr: ToastrService) {
      super();

      this.addressForm = new FormGroup({
        number: new FormControl(''),
        complement: new FormControl(''),
        street: new FormControl('', Validators.required),
        city: new FormControl('', Validators.required),
        country: new FormControl(''),
        zip: new FormControl('', [Validators.required, Validators.pattern(/^[0-9]{5}$/)])
      });

    }

  ngOnInit() {
    if (this.mobilityAccountContactDetails && this.mobilityAccountContactDetails.defaultAddress) {
      this.addressForm.setValue({
        number: this.mobilityAccountContactDetails.defaultAddress.addressNumber,
        complement: this.mobilityAccountContactDetails.defaultAddress.addressComplement,
        street: this.mobilityAccountContactDetails.defaultAddress.addressStreet,
        city: this.mobilityAccountContactDetails.defaultAddress.addressCity,
        country: this.mobilityAccountContactDetails.defaultAddress.addressCountry,
        zip: this.mobilityAccountContactDetails.defaultAddress.addressPostalCode
      });
    }
  }


  deleteAddress() {
    if(this.mobilityAccountContactDetails.defaultAddress && this.mobilityAccountContactDetails.defaultAddress.addressId) {
      this.addressDeleting = true;

      const mobilityAccountId = this.mobilityAccountContactDetails.mobilityAccountId;
      const addressId = this.mobilityAccountContactDetails.defaultAddress.addressId;
      this.userService.removeAddress(mobilityAccountId, addressId).subscribe(_d => {
        this.addressDeleting = false;
        this.toastr.success(this.translate.instant('USER.MODALS.DELETE.CONFIRM'));
        this.mobilityAccountContactDetails.defaultAddress = null;
        this.addressForm.reset();
      });
    } else {
      this.addressForm.reset();
    }
  }


  submitAddress() {
    if(this.addressForm.valid) {
      this.addressSaving = true;
      const address = this.mobilityAccountContactDetails.defaultAddress || {};
      address.addressCity = this.addressForm.value.city;
      address.addressComplement = this.addressForm.value.complement || null;
      address.addressCountry = this.addressForm.value.country || null;
      address.addressNumber = this.addressForm.value.number || null;
      address.addressPostalCode = this.addressForm.value.zip;
      address.addressStatus = 'VERIFIED';
      address.addressStreet = this.addressForm.value.street;

      let update$;
      if(address.addressId) {
        update$ = this.userService.updateAddress(address.addressId, address);
      } else {
        this.mobilityAccountContactDetails.defaultAddress = address;
        update$ = this.userService.updateContactDetails(this.mobilityAccountContactDetails.mobilityAccountId, this.mobilityAccountContactDetails);
      }

      update$.pipe(
        mergeMap(_d => {
          return this.userService.getMobilityAccount(this.mobilityAccountContactDetails.mobilityAccountId);
        }),
        pluck('mobilityAccountContactDetails'),
        pluck('defaultAddress')
      ).subscribe((address: AddressDTO) => {
        this.addressSaving = false;
        this.toastr.success(this.translate.instant('USER.MODALS.DELETE.CONFIRM'));  
        this.mobilityAccountContactDetails.defaultAddress = address;
      });
    } else {
      Object.keys(this.addressForm.controls).forEach(field => { 
        const control = this.addressForm.get(field);
        control.markAsTouched({ onlySelf: true });
      });
    }

  }

}
