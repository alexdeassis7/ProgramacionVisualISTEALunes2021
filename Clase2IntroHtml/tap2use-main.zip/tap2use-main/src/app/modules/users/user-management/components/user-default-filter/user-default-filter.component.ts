import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { UserFilterRange } from './user-filter-range';

@Component({
  selector: 'ap-user-default-filter',
  templateUrl: './user-default-filter.component.html',
  styleUrls: ['./user-default-filter.component.css']
})
export class UserDefaultFilterComponent implements OnInit {

  @Input() toogle: false;

  filterType: string = 'period';

  display: boolean = false;

  @Input() from : Date;

  @Input() to : Date;

  @Output() filterChange = new EventEmitter<UserFilterRange>();

  constructor() { }

  ngOnInit() {
    if(!this.toogle) {
      this.display = true;
    }
  }

  filter(range) {
    this.from = range.from;
    this.to = range.to;

    this.filterChange.emit({
      from: this.from,
      to: this.to
    });
  }

}
