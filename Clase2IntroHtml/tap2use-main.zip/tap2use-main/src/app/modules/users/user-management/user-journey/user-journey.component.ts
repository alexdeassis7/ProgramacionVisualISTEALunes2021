
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { AccessMedia } from '@app/core/services/access-media/models/accessMedia';
import { AccessRoles } from '@app/core/services/administrator/models/accessRoles';
import { Page } from '@app/core/services/commons/page';
import { JourneyService } from '@app/core/services/journey/journey.service';
import { Journey } from '@app/core/services/journey/models/journey';
import { Tap } from '@app/core/services/journey/models/tap';
import { Pagination } from '@app/shared/components/pagination/pagination.model';
import * as moment from 'moment';
import { BehaviorSubject, Observable } from 'rxjs';
import { first, map, pluck, switchMap } from 'rxjs/operators';
import { Selection } from '../components/access-media-filter/access-media-filter.component';
import { UserFilterRange } from '../components/user-default-filter/user-filter-range';

@Component({
  selector: 'app-user-journey',
  templateUrl: './user-journey.component.html',
  styleUrls: ['./user-journey.component.css']
})

export class UserJourneyComponent extends AbstractOnDestroyComponent implements OnInit {

  refundable: boolean;
  tapTypes = Tap.TypeEnum;
  accessRoles = AccessRoles;
  selectedRefundableTaps: Set<string>;            // tap's references for refunding

  accessMedias: AccessMedia[];
  journeys$: Observable<Journeys>;

  parameters: JourneyParameters;                  // Possible filters journeys (page, size, date or accessMedias)
  changes$: BehaviorSubject<JourneyParameters>;   // Send an event if we need to filter journeys because params changes

  constructor(private route: ActivatedRoute, private router: Router, private journeyService: JourneyService) {
    super();
  }

  ngOnInit(): void {
    if (this.route.snapshot.queryParamMap.has('transactionIds')) {
      const transactionIds = this.route.snapshot.queryParamMap.get('transactionIds').split('|').filter(t => t);
      if (transactionIds.length > 0) {
        this.startRefund(transactionIds);
      }
    }

    this.parameters = new JourneyParameters();
    this.changes$ = new BehaviorSubject<JourneyParameters>(this.parameters);

    const accessMediaSelected = this.route.parent.snapshot.paramMap.get('ref');

    // Retrieve accessMedias from resolver
    this.route.data.pipe(first(), pluck('accessMedias')).subscribe((accessMedias: AccessMedia[]) => {
      this.accessMedias = accessMedias;
      // Load journeys from accessMedias (possible with a change on paramaters)
      this.parameters.accessMedias = new Set(
        accessMedias.filter(a => [a.accessMediaReference, 'all']
                      .includes(accessMediaSelected)).map(a => a.accessMediaIdentificationToken)
      );
      this.changes$.next(this.parameters);
    });

    // If something (page, size, date or accessMedias) changes then we update journeys
    this.journeys$ = this.changes$.pipe(
      switchMap((journeyParameters: JourneyParameters) => {
        return this.loadJourneys(journeyParameters);
      })
    );

  }

  private loadJourneys(params: JourneyParameters) {
    return this.journeyService.getJourneys(Array.from(params.accessMedias), params.page, params.elements, params.from, params.to).pipe(
      map((page: Page<Journey>) => {
        const journeyUIs = <JourneyUI[]>page.content;
        // Set an accessMedia
        journeyUIs.forEach(j =>
          j.accessMedia = this.accessMedias.find(a => a.accessMediaIdentificationToken === j.taps[0].identificationToken));
        const pagination = new Pagination(page.totalElements, page.totalPages, page.size, page.number);
        return new Journeys(journeyUIs, pagination);
      })
    );
  }

  /*****************************************************
   * FILTER EVENTS PART
   *****************************************************/

  filterByDateRange(r: UserFilterRange): void {
    this.parameters.from = r.from;
    this.parameters.to = r.to;
    this.cancelRefund();
    this.changes$.next(this.parameters);
  }

  selectAccessMedia(selection: Selection) {
    if (selection.selected) {
      this.parameters.accessMedias.add(selection.accessMedia.accessMediaIdentificationToken);
    } else {
      this.parameters.accessMedias.delete(selection.accessMedia.accessMediaIdentificationToken);
    }
    this.cancelRefund();
    this.changes$.next(this.parameters);
  }

  onChangePage(page: number) {
    this.parameters.page = page;
    this.changes$.next(this.parameters);
  }

  onChangeSize(size: number) {
    this.parameters.elements = size;
    this.changes$.next(this.parameters);
  }

  /*****************************************************
   * REFUND EVENTS PART
   *****************************************************/

  selectToRefund(tapId: string, checked: boolean) {
    if (checked) {
      this.selectedRefundableTaps.add(tapId);
    } else {
      this.selectedRefundableTaps.delete(tapId);
    }
  }

  startRefund(transactionIds: string[] = []): void {
    this.selectedRefundableTaps = new Set<string>(transactionIds);
  }

  cancelRefund(): void {
    this.selectedRefundableTaps = null;
  }

  refund(): void {
    this.router.navigate(['refund'],
        { relativeTo: this.route, queryParams: {'transactionIds': Array.from(this.selectedRefundableTaps).join('|') } });
  }

}

export interface JourneyUI extends Journey {
  accessMedia: AccessMedia;
}

export class Journeys {
  journeys: JourneyUI[];
  pagination: Pagination;

  constructor(journeys: JourneyUI[], pagination: Pagination) {
    this.journeys = journeys;
    this.pagination = pagination;
  }
}

export class JourneyParameters {
  accessMedias: Set<string>;
  page: number;
  elements: number;
  from: Date;
  to: Date;

  constructor() {
    const now = moment();
    this.from = null;
    this.to = null;
    this.accessMedias = new Set();
    this.page = 0;
    this.elements = 10;
  }
}
