import { Component, OnInit } from '@angular/core';
import { UserService } from '@app/core/services/user/user.service';
import { ActivatedRoute } from '@angular/router';
import { MobilityAccount } from '@app/core/services/user/models/mobilityAccount';
import { UserManagementComponent } from '../user-management.component';
import { UserEvent } from '@app/core/services/action/models/userEvent';
import { AdministratorService } from '@app/core/services/administrator/administrator.service';
import { UserAdmin } from '@app/core/services/administrator/models/userAdmin';
import { tap, takeUntil } from 'rxjs/operators';
import { environment } from '@env/environment';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';

@Component({
  selector: 'app-user-action-history',
  templateUrl: './user-action-history.component.html',
  styleUrls: ['./user-action-history.component.css']
})
export class UserActionHistoryComponent extends AbstractOnDestroyComponent implements OnInit {

  historicList: UserEvent[] = [];
  userId: number;
  user: MobilityAccount = <MobilityAccount>{};

  empty = false;
  errGettingData = false;
  loaded = false;

  page = 0;
  size = 5;
  totalItems = 0;

  admin: UserAdmin = {};
  adminListCache: Array<UserAdmin> = [];



  constructor(private userService: UserService,
    private administratorService: AdministratorService,
    private route: ActivatedRoute,
    private userManagementComponent: UserManagementComponent) {
      super();
      this.user = userManagementComponent.user
  }

  ngOnInit() {
    this.userId = this.route.parent.snapshot.params.id;
    this.refreshHistoricList();

  }

  refreshHistoricList() {
    this.userService.getUserEvents(this.userId, this.page, this.size).pipe(
      tap(
        x => {
          this.setActorDescription(x.content, 0);
        }
      ))
      .pipe( takeUntil(this.unsubscribe) )
      .subscribe(
        resp => {
          this.totalItems = resp.totalElements;
          this.empty = this.totalItems == 0 && this.historicList.length == 0 ? true : false;
          if (!this.historicList) {
            this.historicList = resp.content;
          } else {
            Array.prototype.push.apply(this.historicList, resp.content);
          }
        },
        err => (this.errGettingData = true)
      );
    this.loaded = true;
  }

  showMoreHistoric() {
    this.page += 1;
    this.refreshHistoricList();
  }




  setActorDescription(userEvents: Array<UserEvent>, index: number): Array<UserEvent> {
    if (index < userEvents.length) {
      let nextIndex = index + 1;
      let userEvent = userEvents[index];
      if (userEvent.actorType == environment.defaultValue.user.actortypeagent) {
        if (this.adminListCache.length > 0) {
          this.admin = this.adminListCache.filter(x => x.userCredentials.userKeycloakId == userEvent.actorReference)[0];
          if (this.admin != null) {
            userEvents[index] = this.setActor(userEvent);
            return this.setActorDescription(userEvents, nextIndex);
          } else {
            this.administratorService.getAdministratorByKCId(userEvent.actorReference)
            .pipe( takeUntil(this.unsubscribe) )
            .subscribe(
              res => {
                this.admin = res;
                userEvents[index] = this.setActor(userEvent);
                this.adminListCache.push(this.admin);
                return this.setActorDescription(userEvents, nextIndex);
              },
              err => {
                userEvents[index] = this.setActor(userEvent);
                return this.setActorDescription(userEvents, nextIndex);
              }
            )
          }
        } else {
          this.administratorService.getAdministratorByKCId(userEvent.actorReference)
          .pipe( takeUntil(this.unsubscribe) )
          .subscribe(
            res => {
              this.admin = res;
              userEvents[index] = this.setActor(userEvent);
              this.adminListCache.push(this.admin);
              return this.setActorDescription(userEvents, nextIndex);
            },
            err => {
              userEvents[index] = this.setActor(userEvent);
              return this.setActorDescription(userEvents, nextIndex);
            }
          )
        }
      } else {
        return this.setActorDescription(userEvents, nextIndex);
      }
    } else {
      return userEvents;
    }
  }



  setActor(event: UserEvent): UserEvent {
    if(this.admin != null && this.admin.userDetails != null){
      event.actor = this.admin.userDetails.userFirstName + ' ' + this.admin.userDetails.userLastName;
    }
    return event;
  }
}
