import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserDayFilterComponent } from './user-day-filter.component';

describe('UserDayFilterComponent', () => {
  let component: UserDayFilterComponent;
  let fixture: ComponentFixture<UserDayFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserDayFilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserDayFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
