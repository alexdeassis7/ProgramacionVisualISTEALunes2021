import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccessMedia } from '@app/core/services/access-media/models/accessMedia';
import { FinancialEngineService } from '@app/core/services/financial-engine/financial-engine.service';
import { Observable, throwError, iif, of } from 'rxjs';
import { first, map, pluck, retryWhen, delay, concatMap, takeUntil } from 'rxjs/operators';
import { environment } from '@env/environment';
import { TranslateService } from '@ngx-translate/core';
import { SipsRequest } from '@app/core/services/financial-engine/models/sipsRequest';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { SipsResponse } from '@app/shared/components/sips/sips-response.model';

@Component({
  selector: 'app-user-journey-refund',
  templateUrl: './user-journey-refund.component.html',
  styleUrls: ['./user-journey-refund.component.css']
})
export class UserJourneyRefundComponent extends AbstractOnDestroyComponent implements OnInit {

  accessMedias$: Observable<AccessMedia[]>;
  totalRefund$: Observable<number>;
  transactionIds: string[];

  sipsRequest: SipsRequest;
  accessMediaSelected: AccessMedia;
  state: 'LOADING' | 'SELECTION' | 'DONE' | 'ERROR' | 'OTHER_CARD';

  constructor(private route: ActivatedRoute, private financialEngineService: FinancialEngineService, private router: Router, private translate: TranslateService) { 
    super();
  }

  ngOnInit(): void {
    this.transactionIds = this.route.snapshot.queryParamMap.get('transactionIds').split('|');

    const sum = (acc: number, curr: number) => acc + curr;

    this.accessMedias$ = this.route.data.pipe(first(), pluck('accessMedias'));
    this.totalRefund$ = this.financialEngineService.findSettlementItems(this.transactionIds).pipe(
      map(s => { return s.map(i => i.amount).reduce(sum) })
    );

    this.state = 'SELECTION';
  }

  onAccessMediaSelect(accessMedia: AccessMedia) {
    this.accessMediaSelected = accessMedia;
  }

  /**
   * Launch pay page SIPS to refund to another card
   */
  choiceOtherCard() {
    let mobilityAccountId = Number(this.route.parent.snapshot.params.id);
    if(isNaN(mobilityAccountId)) {
      mobilityAccountId = null;
    }
    
    this.state = 'LOADING';
    this.financialEngineService.generateSipsRequestToRefund(this.transactionIds, mobilityAccountId, environment.defaultValue.templatename, this.translate.currentLang, environment.api.sipsNormalReturnSearch).pipe(
        takeUntil(this.unsubscribe)
      ).subscribe((data: SipsRequest) => {
        this.sipsRequest = data;
        this.state = 'OTHER_CARD';
      }, _err => {
        this.state = 'ERROR';
      });
  }

  /**
   * Check if refund has been executed (asynchronous process, pulling strategy for checking result)
   * @param _data 
   */
  receiveFromSips(_data: SipsResponse) {
    this.state = 'LOADING';

    this.financialEngineService.findSettlementStatus(this.transactionIds).pipe(
      takeUntil(this.unsubscribe),
      map((causes: string[]) => {
        if(causes.includes('REFUND')) {
          return true;
        }
        throw new Error('');
      }),
    ).pipe(
      takeUntil(this.unsubscribe),
      retryWhen(errors => errors.pipe(
        takeUntil(this.unsubscribe),
        concatMap((e, i) => 
          // Executes a conditional Observable depending on the result
          // of the first argument
          iif(
            () => i > 10,
            // If the condition is true we throw the error (the last error)
            throwError(e),
            // Otherwise we pipe this back into our stream and delay the retry
            of(e).pipe(delay(1000)) 
          )
        ) 
      )),
    ).subscribe(_data => {
      this.state = 'DONE';
    }, _err => {
      this.state = 'ERROR';
    })
  }

  /**
   * Call API to refund journeys to selected accessMedia
   */
  refund() {
    if(this.accessMediaSelected) {
      this.state = 'LOADING';
      const ref = this.accessMediaSelected.accessMediaReference;
      const type = this.accessMediaSelected.accessMediaType;
  
      let mobilityAccountId = null;
      if(this.accessMediaSelected.accessMediaHolder) {
        mobilityAccountId = this.accessMediaSelected.accessMediaHolder.accessMediaHolderAccountId;
      }
  
      this.financialEngineService.refund(ref, type, this.transactionIds, mobilityAccountId).pipe(
          takeUntil(this.unsubscribe)
        ).subscribe(_d => {
          this.state = 'DONE';
        }, _e => {
          this.state = 'ERROR';
        });
    }
  }

  /**
   * Return to journeys page
   */
  backToJourneys(transactionIds = []) {
    const params = {
      'transactionIds': transactionIds.join('|')
    };
    
    this.router.navigate(['..'], { relativeTo: this.route, queryParams:  params});
  }

}
