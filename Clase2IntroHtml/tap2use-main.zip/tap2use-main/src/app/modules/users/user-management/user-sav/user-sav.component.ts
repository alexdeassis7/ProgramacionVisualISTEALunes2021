import { Component, OnInit } from '@angular/core';
import { CustomerRequest } from '@app/core/services/customer-request/model/customerRequest';
import { AccessRoles } from '@app/core/services/administrator/models/accessRoles';
import { CustomerRequestService } from '@app/core/services/customer-request/customer-request.service';
import { ActivatedRoute, Router } from '@angular/router';
import { KeycloakService } from 'keycloak-angular';
import { Observable, from } from 'rxjs';
import { Comment } from '@app/core/services/customer-request/model/comment';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { takeUntil, pluck, tap, mergeMap } from 'rxjs/operators';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { Sort } from '@app/shared/components/table/sort/sort.model';
import { Page } from '@app/core/services/commons/page';

@Component({
  selector: 'app-user-sav',
  templateUrl: './user-sav.component.html',
  styleUrls: ['./user-sav.component.css']
})
export class UserSavComponent extends AbstractOnDestroyComponent implements OnInit {
  
  loading: boolean = false;
  closing = new Set<number>();

  sort: Sort = { field: 'id', order: 'DESC' };
  page: number = 0;
  elements: number = 10;

  customerRequests$: Observable<Page<CustomerRequest>>;

  accessRoles = AccessRoles;
  
  constructor(
    private customerRequestService: CustomerRequestService,
    private route: ActivatedRoute,
    private router: Router,
    private keycloakService: KeycloakService,
    private translate: TranslateService,
    private toastr: ToastrService
  ) {
    super();
  }

  ngOnInit() {
    this.loading = true;
    this.customerRequests$ = this.route.data.pipe(
      pluck('customerRequests'),
      tap(_d => {
        this.loading = false;
        this.closing.clear();
      })
    );
  }

  filterBySort(sort: Sort) {
    this.sort = sort;
    this.reloadPage();
  }

  filterByPaginationSize(size: number) {
    this.elements = size;
  } 
  
  filterByPagination(page: number) {
    this.page = page;
  }

  /**
   * Close a ticket
   * 
   * @param curstomerRequestId 
   */
  closeTicket(curstomerRequestId: number) {
    this.closing.add(curstomerRequestId);
    const adminReference = this.keycloakService.getKeycloakInstance().subject;

    from(this.keycloakService.loadUserProfile()).pipe(
      mergeMap(admin => {
        const closingComment :Comment = {
          content: "Closing ticket #" + curstomerRequestId,
          notifiable: true,
          writer: {
            adminReference: adminReference,
            email: admin.email,
            firstName: admin.firstName,
            lastName: admin.lastName
          }
        };
        return this.customerRequestService.close(curstomerRequestId, closingComment);
      }),
      takeUntil(this.unsubscribe)
    ).subscribe(_customerRequest => {
        this.customerRequestService.refreshRequestCustomerCounter();
        this.toastr.success(this.translate.instant('TOAST.SUCCESS.CLOSE'));
        this.reloadPage();
      }, _err => {
        this.toastr.success(this.translate.instant('TOAST.ERROR.FAILED'));
      }
    );
  }

  /**
   * Call customer-request-resolver when pagination and filters change for retriving device data
   */
  private reloadPage(): void {
    this.router.navigate(['users', this.route.parent.snapshot.params.id, this.route.parent.snapshot.params.ref, 'sav'], {
    queryParams: {
        pageNumber: this.page,
        pageSize: this.elements,
        sortElement: this.sort && this.sort.field,
        sortOrder: this.sort && this.sort.order,
        refresh: (new Date()).getTime()
      }
    });
  }
}
