import { Component, OnInit, Input } from '@angular/core';
import { UserEvent } from '@app/core/services/action/models/userEvent';
import { ParsedEvent } from '@angular/compiler';
import { UserAdmin } from '@app/core/services/administrator/models/userAdmin';
import { LocalDatePipe } from '@app/shared/local-date/local-date.pipe';
import { TranslateService } from '@ngx-translate/core';
import { AdministratorService } from '@app/core/services/administrator/administrator.service';
import { environment } from '@env/environment';

@Component({
  selector: 'app-user-action-show',
  templateUrl: './user-action-show.component.html',
  styleUrls: ['./user-action-show.component.css']
})
export class UserActionShowComponent implements OnInit {


  @Input()
  historic: UserEvent;

  actionTmp: string[];
  action: string;

  admin: UserAdmin;

  crud = environment.defaultValue.user.crud;

  tmpUserAdmin: Array<UserAdmin> = [];


  constructor(
    private translate: TranslateService,
    private administratorService: AdministratorService) { }

  ngOnInit() {
    this.parseEvent();

  }

  parseEvent() {
    this.historic.localDate = new LocalDatePipe(this.translate).transform(this.historic.creationDate);
    this.actionTmp = this.historic.eventType.split('_');
    if (this.actionTmp.length > 1 && this.isCrud(this.actionTmp[0])) {
      this.action = this.actionTmp[0];
    } else {
      this.action = null;
    }



  }

  isCrud(value: string) {
    for (let action of this.crud) {
      if (action == value)
        return true;
    }
    return false;
  }

 }


