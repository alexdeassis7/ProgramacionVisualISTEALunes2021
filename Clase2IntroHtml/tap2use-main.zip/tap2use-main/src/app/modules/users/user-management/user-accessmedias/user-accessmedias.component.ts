import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { AccessMediaService } from '@app/core/services/access-media/access-media.service';
import { AccessMedia } from '@app/core/services/access-media/models/accessMedia';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { Observable } from 'rxjs';
import { map, pluck, takeUntil, tap } from 'rxjs/operators';


@Component({
  selector: 'app-user-accessmedias',
  templateUrl: './user-accessmedias.component.html',
  styleUrls: ['./user-accessmedias.component.css']
})
export class UserAccessmediasComponent extends AbstractOnDestroyComponent implements OnInit {

  $accessMedias: Observable<AccessMedia[]>;
  hasHolder = false;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private accessMediaService: AccessMediaService,
    private toastr: ToastrService,
    private translate: TranslateService
  ) {
    super();
  }

  ngOnInit() {
    this.$accessMedias = this.route.data
      .pipe(
        pluck('accessMedias'),
        tap( accessMedias => this.hasHolder = accessMedias.some(m => m.accessMediaHolder) )
      );
  }

  // Method to revoke an acces media
  revoke(accessMediaToRevoke: AccessMedia) {
    this.accessMediaService.disEnrollAccessMedia(accessMediaToRevoke.accessMediaId)
    .pipe( takeUntil(this.unsubscribe) )
    .subscribe(() => {
      this.toastr.info(this.translate.instant('ACCESS_MEDIA.REVOKED'));
      this.router.navigate(['users', this.route.parent.snapshot.params.id, this.route.parent.snapshot.params.ref, 'accessmedia',
          {refresh: (new Date()).getTime()}]);
    });
  }

}
