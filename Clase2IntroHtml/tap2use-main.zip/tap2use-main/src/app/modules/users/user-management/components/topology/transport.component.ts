import { Component, Input, OnInit } from '@angular/core';
import { Location, TransportMode } from '@app/core/services/journey/models/location';

@Component({
  selector: 'ap-transport',
  template:   `
    <span class="vehicle-logo" [ngClass]="{'three-letter': size == 3}" ap-tooltip="{{ 'JOURNEY.TRANSPORT.' + location.transportMode | translate }}">
      {{ 'JOURNEY.TRANSPORT.' + location.transportMode | translate | slice:0:size }}
    </span>`,
  styles: [`
    .vehicle-logo {
      line-height: 1.8em;
      height: 24px;
      display: inline-block;
      width: 24px;
      text-align: center;
      cursor: pointer;

      background: #fff;
      text-transform: uppercase;
      border: 1px solid #404a54;
      border-radius: 19px;color: #404a54;
    }
    .three-letter {
      font-size: 9px;
      padding-top: 4px;
      font-weight: bold;
    }
  `]
})
export class TransportComponent implements OnInit {

  @Input() location: Location;

  size: number = 1;

  constructor() { }

  ngOnInit() {
    if (this.location.transportMode === TransportMode.BUS) {
      this.size = 3;
    }
  }

}
