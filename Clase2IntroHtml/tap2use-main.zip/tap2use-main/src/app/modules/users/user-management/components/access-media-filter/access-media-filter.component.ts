import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AccessMedia } from '@app/core/services/access-media/models/accessMedia';

@Component({
  selector: 'ap-access-media-filter',
  templateUrl: './access-media-filter.component.html',
  styleUrls: ['./access-media-filter.component.css']
})
export class AccessMediaFilterComponent implements OnInit {

  @Input() selections: Set<string>;

  @Input() accessMedias: AccessMedia;

  @Output() changeSelection = new EventEmitter<Selection>();

  constructor() {}

  ngOnInit() {}

  selectAccessMedia(selected: boolean, accessMedia: AccessMedia) {
    this.changeSelection.emit({
      selected: selected,
      accessMedia: accessMedia
    });
  }

}

export interface Selection {
  selected: boolean;
  accessMedia: AccessMedia;
}
