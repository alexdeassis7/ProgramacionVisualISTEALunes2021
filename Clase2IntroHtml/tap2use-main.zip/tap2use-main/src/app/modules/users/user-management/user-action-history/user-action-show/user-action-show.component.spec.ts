import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserActionShowComponent } from './user-action-show.component';

describe('UserActionShowComponent', () => {
  let component: UserActionShowComponent;
  let fixture: ComponentFixture<UserActionShowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserActionShowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserActionShowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
