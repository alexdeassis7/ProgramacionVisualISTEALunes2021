import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import * as moment from 'moment';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'ap-user-day-filter',
  templateUrl: './user-day-filter.component.html',
  styleUrls: ['./user-day-filter.component.css']
})
export class UserDayFilterComponent implements OnInit {
  
  @Input('from') from: Date;
  
  @Output("filter") filterEvent = new EventEmitter<any>();

  filterForm: FormGroup;

  constructor() { 
    this.filterForm = new FormGroup({
      date: new FormControl(moment(this.from).format('YYYY-MM-DD'))
    });
  }

  ngOnInit() {
    this.filterForm.setValue({
      date: this.from ? moment(this.from).format('YYYY-MM-DD') : ''
    });
  }
  
  filter() {
    if (this.filterForm.valid) {
      const date = this.filterForm.value.date ? moment(this.filterForm.value.date, 'YYYY-MM-DD') : null;
      
      this.filterEvent.emit({
        'from': date ? date.startOf('day').toDate() : null,
        'to': date ? date.endOf('day').toDate() : null
      });
    }
  }
}
