import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserSettlementsComponent } from './user-settlements.component';

describe('UserSettlementsComponent', () => {
  let component: UserSettlementsComponent;
  let fixture: ComponentFixture<UserSettlementsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserSettlementsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserSettlementsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
