import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MobilityAccount } from '@app/core/services/user/models/mobilityAccount';
import { UserService } from '@app/core/services/user/user.service';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { takeUntil } from 'rxjs/operators';
import { environment } from '@env/environment';

@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.css']
})

export class UserManagementComponent extends AbstractOnDestroyComponent implements OnInit {
  userId: number;
  user: MobilityAccount;
  ref: string;
  supportEnrole: boolean;
  t2uSupport: boolean;

  constructor(private route: ActivatedRoute, private userService: UserService) {
    super();
  }

  ngOnInit() {
      this.route.data.subscribe((data: { user: MobilityAccount }) => this.user = data.user);
      this.userId = this.route.snapshot.params.id;
      this.ref = this.route.snapshot.params.ref;
      if (!isNaN(Number(this.userId))) {
        this.supportEnrole = true;
      } else {
        this.supportEnrole = false;
      }
      // Observable if user is changed in the child (identity)
      this.userService.user$.pipe(takeUntil(this.unsubscribe)).subscribe(user => this.user = user);
      this.t2uSupport = environment.defaultValue.customerRequest.t2uSupport;
  }
}
