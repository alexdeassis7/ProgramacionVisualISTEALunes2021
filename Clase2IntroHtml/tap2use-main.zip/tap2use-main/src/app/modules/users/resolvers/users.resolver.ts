import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { MobilityAccount } from '@app/core/services/user/models/mobilityAccount';
import { Observable } from 'rxjs';
import { UserService } from '@app/core/services/user/user.service';

@Injectable()
export class UsersResolver implements Resolve<MobilityAccount[]> {

    constructor(private userService: UserService) {}

    resolve(route: ActivatedRouteSnapshot): Observable<MobilityAccount[]> {

        return this.userService.findUsersFromMobilityEngine({});
    }
}
