import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { MobilityAccount } from '@app/core/services/user/models/mobilityAccount';
import { Observable } from 'rxjs';
import { UserService } from '@app/core/services/user/user.service';

@Injectable()
export class UserResolver implements Resolve<MobilityAccount> {

    constructor(private userService: UserService) {}

    resolve(route: ActivatedRouteSnapshot): Observable<MobilityAccount> {
            const userId = route.paramMap.get('id');
            if (!isNaN(Number(userId))) {
                return this.userService.getMobilityAccount(+userId);
            }
    }
}
