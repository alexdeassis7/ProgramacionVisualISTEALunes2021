import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { CustomerRequestService } from '@app/core/services/customer-request/customer-request.service';
import { CustomerRequest } from '@app/core/services/customer-request/model/customerRequest';
import { Page } from '@app/core/services/commons/page';

@Injectable()
export class UserCustomerRequestsResolver implements Resolve<Page<CustomerRequest>> {

    constructor(private customerRequestService: CustomerRequestService) {}

    resolve(route: ActivatedRouteSnapshot): Observable<Page<CustomerRequest>> {
        const userId = route.parent.paramMap.get('id');

        const pageNumber = +route.queryParamMap.get('pageNumber') || 0;
        const pageSize = +route.queryParamMap.get('pageSize') || 10;
        const sortOrder = route.queryParamMap.get('sortOrder') || 'DESC';
        const sortElement = route.queryParamMap.get('sortElement') || 'id';

        return this.customerRequestService.findCustomerRequestsByCustomerReference(userId, sortOrder, sortElement, pageNumber, pageSize);
    }
}
