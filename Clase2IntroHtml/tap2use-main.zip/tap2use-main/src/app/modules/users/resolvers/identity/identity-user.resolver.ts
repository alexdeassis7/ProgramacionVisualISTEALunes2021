import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { MobilityAccount } from '@app/core/services/user/models/mobilityAccount';
import { UserService } from '@app/core/services/user/user.service';

@Injectable()
export class IdentityUserResolver implements Resolve<MobilityAccount> {

    constructor(private userService: UserService) {}

    resolve(route: ActivatedRouteSnapshot): Observable<MobilityAccount> {
        const userId = route.parent.paramMap.get('id');
        return this.userService.getMobilityAccount(+userId);
    }
}
