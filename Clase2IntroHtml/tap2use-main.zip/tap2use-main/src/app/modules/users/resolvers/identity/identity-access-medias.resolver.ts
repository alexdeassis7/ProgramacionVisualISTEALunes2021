import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve } from '@angular/router';
import { AccessMediaService } from '@app/core/services/access-media/access-media.service';
import { AccessMedia } from '@app/core/services/access-media/models/accessMedia';
import { Observable } from 'rxjs';
import { of } from 'rxjs/internal/observable/of';
import { mergeMap, pluck } from 'rxjs/operators';

@Injectable()
export class IdentityAccessMediasResolver implements Resolve<AccessMedia[]> {
  private allowedStatuses = ['ACTIVE', 'BLOCKED', 'REVOKED'];

  constructor(private accessMediaService: AccessMediaService) { }

  resolve(route: ActivatedRouteSnapshot): Observable<AccessMedia[]> {
    let accessMedias$: Observable<AccessMedia[]>;
    const userId = route.parent.paramMap.get('id');

    if (!isNaN(Number(userId))) {
      const userFilter = { accessMediaHolderAccountId: userId, accessMediaStatuses: this.allowedStatuses };
      accessMedias$ = this.accessMediaService.findAccessMedias(userFilter, 'DESC', 'accessMediaCreationDate', 0, 100, ).pipe(pluck('content'));
    } else {
      // Get access medias with PAR for anonymous account
      const accessMediaType = userId;
      const accessMediaRef = route.parent.paramMap.get('ref');

      accessMedias$ = this.accessMediaService.getAccessMediaByByTypeAndReference(accessMediaType, accessMediaRef).pipe(
        mergeMap(data => {
          if (data.paymentAccountReference) {
            const parFilter = { paymentAccountReference: data.paymentAccountReference, accessMediaStatuses: this.allowedStatuses };
            return this.accessMediaService.findAccessMedias(parFilter, 'DESC', 'accessMediaCreationDate', 0, 100).pipe(pluck('content'));
          } else {
            return of([data]);
          }
        })
      );
    }
    return accessMedias$;
  }

}
