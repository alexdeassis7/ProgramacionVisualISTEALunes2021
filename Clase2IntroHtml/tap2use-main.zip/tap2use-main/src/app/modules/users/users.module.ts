import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { SharedModule } from '@app/shared/shared.module';
import { SipsDebtRecoveryComponent } from './user-management/user-settlements/sips-debt-recovery/sips-debt-recovery.component';
import { AddUserBtnComponent } from './user-list/add-user-btn/add-user-btn.component';
import { ListActionsComponent } from './user-list/list-actions/list-actions.component';
import { UserListComponent } from './user-list/user-list.component';
import { AccessMediaFilterComponent } from './user-management/components/access-media-filter/access-media-filter.component';
import { LineComponent } from './user-management/components/topology/line.component';
import { TransportComponent } from './user-management/components/topology/transport.component';
import { UserDayFilterComponent } from './user-management/components/user-default-filter/user-day-filter/user-day-filter.component';
import { UserDefaultFilterComponent } from './user-management/components/user-default-filter/user-default-filter.component';
import { UserMonthFilterComponent } from './user-management/components/user-default-filter/user-month-filter/user-month-filter.component';
import { UserPeriodFilterComponent } from './user-management/components/user-default-filter/user-period-filter/user-period-filter.component';
import { UserAccessmediasComponent } from './user-management/user-accessmedias/user-accessmedias.component';
import { UserActionHistoryComponent } from './user-management/user-action-history/user-action-history.component';
import { UserActionShowComponent } from './user-management/user-action-history/user-action-show/user-action-show.component';
import { UserIdentityAddressComponent } from './user-management/user-identity/user-identity-address/user-identity-address.component';
import { UserIdentityComponent } from './user-management/user-identity/user-identity.component';
import { UserJourneyRefundComponent } from './user-management/user-journey/user-journey-refund/user-journey-refund.component';
import { UserJourneySelectorComponent } from './user-management/user-journey/user-journey-selector/user-journey-selector.component';
import { UserJourneyComponent } from './user-management/user-journey/user-journey.component';
import { UserManagementComponent } from './user-management/user-management.component';
import { UserSavComponent } from './user-management/user-sav/user-sav.component';
import { SettlementDetailsComponent } from './user-management/user-settlements/settlement-details/settlement-details.component';
import { UserSettlementsComponent } from './user-management/user-settlements/user-settlements.component';
import { UsersRoutingModule } from './users-routing.module';



@NgModule({
  imports: [
    CommonModule,
    MatButtonModule,
    MatCheckboxModule,
    MatSelectModule,
    MatRadioModule,
    MatTableModule,
    MatDatepickerModule,
    MatNativeDateModule,
    SharedModule,
    UsersRoutingModule
  ],
  declarations: [
    UserListComponent,
    AddUserBtnComponent,
    ListActionsComponent,
    UserManagementComponent,
    UserIdentityComponent,
    UserJourneyComponent,
    UserActionHistoryComponent,
    UserSavComponent,
    UserActionShowComponent,
    UserIdentityAddressComponent,
    UserAccessmediasComponent,
    SipsDebtRecoveryComponent,
    UserSettlementsComponent,
    UserDefaultFilterComponent,
    UserDayFilterComponent,
    UserPeriodFilterComponent,
    UserMonthFilterComponent,
    SettlementDetailsComponent,
    LineComponent,
    TransportComponent,
    AccessMediaFilterComponent,
    UserJourneyRefundComponent,
    UserJourneySelectorComponent
  ],
  entryComponents: [
    SettlementDetailsComponent
  ],
  providers: []
})
export class UsersModule { }
