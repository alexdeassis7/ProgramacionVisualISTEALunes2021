import { Component, OnInit } from '@angular/core';
import { environment } from '@env/environment';
import * as moment from 'moment';
import { TranslateService } from '@ngx-translate/core';
import { AccessRoles } from '@app/core/services/administrator/models/accessRoles';


@Component({
  selector: 'app-statistic',
  templateUrl: './statistic.component.html',
  styleUrls: ['./statistic.component.css']
})
export class StatisticComponent implements OnInit {

  kibanaUrl: string = environment.api.kibanaUrl;

  kibanaDaskboard: string = environment.kibana.dashboard;

  kibanaUrlPattern: string = this.kibanaUrl + "/app/kibana#/dashboard/"+ this.kibanaDaskboard + "?embed=true&_g=(refreshInterval:(pause:!t,value:0),time:(from:'{{startingDateTime}}',mode:absolute,to:'{{endingDateTime}}'))";
  kibanaSrc: string;

  accessRoles = AccessRoles;

  ranges = [];
  currentRange;

  since = 'Since';

  durations = [
    'PT15M',
    'PT30M',
    'PT1H',
    'PT6H',
    'PT24H',
    'P2D',
    'P4D',
    'P1W',
    'P2W',
    'P1M',
    'P2M',
    'P3M',
    'P1Y',
    'P2Y'
  ];

  constructor(private translate: TranslateService) {
  }

  ngOnInit() {
    this.translate.get('STATISTIC.SINCE').subscribe(trad => {
      this.since = trad;
      this.generate();
      this.currentRange = this.ranges[0];
      this.onChangeDate();
    });
    this.translate.onLangChange.subscribe((e) => {
      this.translate.get('STATISTIC.SINCE').subscribe(trad => {
        this.since = trad;
        this.generate();
        this.currentRange = this.ranges[0];
        this.onChangeDate();
      });
    });

  }

  generate() {
    this.ranges = [];
    this.ranges.push({
      'label': this.displayDay(moment()),
      'from': moment().startOf('day'),
      'to': moment()
    });
    this.ranges.push({
      'label': this.displayDay(moment().subtract(1, 'days').endOf('day')),
      'from': moment().subtract(1, 'days').startOf('day'),
      'to': moment().subtract(1, 'days').endOf('day')
    });
    this.durations.forEach(duration => {
      this.ranges.push({
        'label': this.displayDuration(duration),
        'from': moment().subtract(moment.duration(duration)).startOf('day'),
        'to': moment()
      });
    });
  }

  onChangeDate() {
    this.kibanaSrc = this.kibanaUrlPattern.replace('{{startingDateTime}}', this.currentRange.from.toISOString()).replace('{{endingDateTime}}', this.currentRange.to.toISOString());
  }

  displayDay(day) {
    return day.locale(this.translate.currentLang).calendar(null).split(" ")[0];
  }

  displayDuration(duration) {
    // @ts-ignore
    var data = moment.localeData(this.translate.currentLang)._relativeTime;
    data.future = this.since + ' %s';

    moment.defineLocale('fr-foo', {
      parentLocale: this.translate.currentLang,
      relativeTime : data
    });
    return moment.duration(duration).locale('fr-foo').humanize(true);
  }

  onChange(e) {
    this.currentRange = e;
  }

  onChangeFrom(e) {
    var customRange = {
        label: 'PERSONALIZED',
        from: moment(e),
        to: this.currentRange.to
    };
    this.generate();
    this.ranges.push(customRange);
    this.currentRange = customRange;
  }

  onResetDate() {
    this.generate();
    this.currentRange = this.ranges[0];
  }

  onChangeTo(e) {
    var customRange = {
      label: 'PERSONALIZED',
      from: this.currentRange.from,
      to: moment(e)
    };
    this.generate();
    this.ranges.push(customRange);
    this.currentRange = customRange;
  }
}
