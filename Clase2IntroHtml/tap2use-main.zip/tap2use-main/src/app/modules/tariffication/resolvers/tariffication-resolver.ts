import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve } from '@angular/router';
import { catchError, map, mergeMap, switchMap } from 'rxjs/operators';
import { forkJoin, Observable, of } from 'rxjs';
import { Page } from '@app/core/services/commons/page';
import { ProductWithValidityInfo } from '@app/core/services/fare-collection-engine/models/ProductWithValidityInfo';
import { FareCollectionEngineService } from '@app/core/services/fare-collection-engine/fareCollectionEngine.service';


@Injectable()
export class TarifficationResolver implements Resolve<Page<ProductWithValidityInfo>> {

  constructor(private fareCollectionEngineService: FareCollectionEngineService) { }

  resolve(route: ActivatedRouteSnapshot): Observable<Page<ProductWithValidityInfo>> {

    const filterEncode = route.queryParamMap.get('filter') || '';

    const filter = {};

    if (filterEncode) {
      filterEncode.split('|')
        .filter(s => s.match(/.*\~[0-1]\~.*/))
        .filter(s => {
          const enabled = s.split('~')[1] === '1';
          return enabled;
        })
        .forEach(s => {
          const key = s.split('~')[0];
          const value = s.split('~')[2];
          filter[key] = value;
        });
    }

    let pageNumber = +route.queryParamMap.get('pageNumber') || 0;
    let pageSize = +route.queryParamMap.get('pageSize') || 10;
    let sortOrder = <'ASC' | 'DESC'>(route.queryParamMap.get('sortOrder') || 'DESC');
    let sortElement = route.queryParamMap.get('sortElement') || 'productNumber';

    return this.fareCollectionEngineService.searchProducts(filter, sortOrder, sortElement, pageNumber, pageSize).pipe(catchError(_err => of(null)));
  }

  private getTime(date?: Date) {
    return date != null ? date.getTime() : 0;
  }
}
