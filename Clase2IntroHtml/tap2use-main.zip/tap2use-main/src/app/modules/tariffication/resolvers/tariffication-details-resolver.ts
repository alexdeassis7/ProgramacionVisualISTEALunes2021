import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve } from '@angular/router';
import { catchError} from 'rxjs/operators';
import {  Observable, of } from 'rxjs';
import { Product } from '@app/core/services/fare-collection-engine/models/productCatalog';
import { FareCollectionEngineService } from '@app/core/services/fare-collection-engine/fareCollectionEngine.service';


@Injectable()
export class TarifficationDetailsResolver implements Resolve<Product> {

  constructor(private fareCollectionEngineService: FareCollectionEngineService) { }

  resolve(route: ActivatedRouteSnapshot): Observable<Product> {
   return this.fareCollectionEngineService.getProducts( route.params['serviceOperator'], route.params['productNumber']).pipe(catchError(_err => of(null)));


  }


}
