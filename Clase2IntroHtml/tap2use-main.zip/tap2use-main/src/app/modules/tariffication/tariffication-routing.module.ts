import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppAuthGuard } from '@app/core/guards/authguard';
import { AccessRoles } from '@app/core/services/administrator/models/accessRoles';
import { TarifficationDetailsResolver } from './resolvers/tariffication-details-resolver';
import { TarifficationResolver } from './resolvers/tariffication-resolver';
import { TarifficationDetailsComponent } from './tariffication-details/tariffication-details.component';
import { TarifficationListComponent } from './tariffication-list/tariffication-list.component';


const routes: Routes = [
  {
    path: '',
    component: TarifficationListComponent,
    canActivate: [AppAuthGuard],
    data: { role: [AccessRoles.ROLE_SUPER_ADMIN, AccessRoles.ROLE_ADMIN] },
    resolve: { pageProduct: TarifficationResolver },
    runGuardsAndResolvers: 'paramsOrQueryParamsChange'
  },
  {
    path: 'manage/:serviceOperator/:productNumber', 
    component: TarifficationDetailsComponent,
    canActivate: [AppAuthGuard],
    data: { role: [AccessRoles.ROLE_SUPER_ADMIN, AccessRoles.ROLE_ADMIN] },
    resolve: { Product: TarifficationDetailsResolver },
    runGuardsAndResolvers: 'paramsOrQueryParamsChange'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TarifficationRoutingModule { }
