import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FareCollectionEngineService } from '@app/core/services/fare-collection-engine/fareCollectionEngine.service';
import { Product, SpecialDays } from '@app/core/services/fare-collection-engine/models/productCatalog';

import { Observable } from 'rxjs';

@Component({
  selector: 'app-tariffication-details',
  templateUrl: './tariffication-details.component.html',
  styleUrls: ['./tariffication-details.component.css']
})
export class TarifficationDetailsComponent implements OnInit {
  data: Observable<Product>;
  serviceOperator: string;
  newSpecialDays: any;
  idDeleteSpecialDay: string;
  constructor(private route: ActivatedRoute, private fareCollectionEngineService: FareCollectionEngineService) {

  }

  ngOnInit(): void {
    this.getDataServiceOperator();

    this.newSpecialDays = {
      "isHoliday": 1,
      "name": "Insert Special Day Name",
      "serviceOperator": this.serviceOperator,
      "specialDayDate": this.formatDate(),//para mostrar la fecha actual en el input uso una fuction
      "specialDayNumber": this.data[0].specialDaysRestrictionsList.length + 1,
      "validityDateFrom": "2021-12-30T16:12:12.000Z",
      "validityDateTo": "2021-12-30T16:12:12.000Z"

    };


    //test insert partial capping
    //console.log(this.fareCollectionEngineService.insertEventPartialCapping().subscribe());

    //test delete partial capping
    //console.log(this.fareCollectionEngineService.deleteEventPartialCapping("c7c4adb5-d781-4301-8bf7-8ded617d9217").subscribe());

    //test insert Special days 
    //console.log(this.fareCollectionEngineService.insertSpecialday().subscribe());
    //test delete Special days 
    //console.log(this.fareCollectionEngineService.deleteSpecialday("6fdc8731-7dc0-4b9a-a4e2-93831bd445f9").subscribe());

  }
  addSpecialDays() {
    this.fareCollectionEngineService.insertSpecialday(this.newSpecialDays).subscribe()
    this.getDataServiceOperator();
  }

  deleteSpecialDays(specialDayRestrictionId: string) {
    this.fareCollectionEngineService.deleteSpecialday(specialDayRestrictionId).subscribe()
    //this.getDataServiceOperator();
  }

  getDataServiceOperator() {
    this.route.data.subscribe(data => {
      this.data = data.Product
    });
    console.dir(this.data);
    console.log(this.data[0].timeFrameMatrixList.length);
    this.serviceOperator = this.data[0].serviceOperator.serviceOperatorName;
  }

  formatDate() {
    var d = new Date(),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();

    if (month.length < 2)
      month = '0' + month;
    if (day.length < 2)
      day = '0' + day;

    return [year, month, day].join('-');
  }
}


