import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TarifficationDetailsComponent } from './tariffication-details.component';

describe('TarifficationDetailsComponent', () => {
  let component: TarifficationDetailsComponent;
  let fixture: ComponentFixture<TarifficationDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TarifficationDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TarifficationDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
