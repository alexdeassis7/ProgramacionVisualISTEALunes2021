import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TarifficationListComponent } from './tariffication-list.component';

describe('TarifficationListComponent', () => {
  let component: TarifficationListComponent;
  let fixture: ComponentFixture<TarifficationListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TarifficationListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TarifficationListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
