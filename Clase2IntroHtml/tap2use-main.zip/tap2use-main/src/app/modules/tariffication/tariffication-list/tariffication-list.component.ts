import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationCancel, NavigationEnd, NavigationError, RouteConfigLoadEnd, Router, RouterEvent } from '@angular/router';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { FareCollectionEngineService } from '@app/core/services/fare-collection-engine/fareCollectionEngine.service';
import { ProductWithValidityInfo } from '@app/core/services/fare-collection-engine/models/ProductWithValidityInfo';
import { tap, pluck, catchError } from 'rxjs/operators';
import { FilterData } from '@app/shared/components/filter/filterData';
import { Pagination } from '@app/shared/components/pagination/pagination.model';
import { Sort } from '@app/shared/components/table/sort/sort.model';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { Observable, of } from 'rxjs';
import { TextFilterTemplate } from '@app/shared/components/filter/filter-template/text-filter-template/text-filter-template.model';
import { environment } from '@env/environment';
import { SelectionFilterTemplate } from '@app/shared/components/filter/filter-template/selection-filter-template/selection-filter-template.model';


@Component({
  selector: 'app-tariffication-list',
  templateUrl: './tariffication-list.component.html',
  styleUrls: ['./tariffication-list.component.css']
})
export class TarifficationListComponent extends AbstractOnDestroyComponent implements OnInit {

  loading = false;
  error = false;
  $products: Observable<ProductWithValidityInfo[]>;
  pagination: Pagination;
  filterData: FilterData;
  sort: Sort;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private readonly toastr: ToastrService,
    private translate: TranslateService,
    private fareCollectionEngineService: FareCollectionEngineService
  ) {
    super();

    /* Define possible filter */
    const templates = [
      new TextFilterTemplate('productNumber', 'TARIFFICATION.LABELS.FILTER.IDENTIFIER', 'DEFAULT', 'EQUALS'),
      new TextFilterTemplate('productName', 'TARIFFICATION.LABELS.FILTER.NAME', 'DEFAULT', 'CONTAINS'),      
      new SelectionFilterTemplate('contractStatus', 'TARIFFICATION.LABELS.FILTER.CONTRACT_STATUS', environment.defaultValue.tariffication.contractStatus.map(status => ({label: status.displayValue, value: status.value})))
    ]
    
    this.filterData = new FilterData('products', templates);

  }

  ngOnInit() {

    // If encoded URL filter change after reload (navigate to same page with a diffrent filter), same thing with filter
    this.route.queryParamMap.subscribe(params => {
      // filter decode
      this.filterData.decode(params.get('filter') || '');
      // sort decode
      if (params.has('sortElement') && params.has('sortOrder')) {
        this.sort = new Sort(params.get('sortElement'), <'ASC' | 'DESC'> params.get('sortOrder'));
      } else {
        this.sort = new Sort('productNumber', 'DESC');
      }
    });

    this.$products = this.route.data.pipe(
      pluck('pageProduct'),
      tap((pageProduct) => {
        this.loading = false;
        if (!pageProduct) {
          throw new Error('Error while calling page access media API');
        }
        const { size, totalElements, number, totalPages } = pageProduct;
        this.pagination = { elements: size, totalElements, page: number, totalPages };
      }),
      pluck('content'),
      catchError(_err => {
        this.error = true;
        return of([]);
      })
    );

    // If filterData change then reload the page (get data with resolver)    
    this.filterData.onChange$.subscribe(_e => {
      this.pagination.page = 0;
      this.reloadTariffication();
    });

  }

  filterBySort(sort: Sort) {
    this.sort = sort;
    this.reloadTariffication();
  }

  filterByPagination(page: number) {
    this.pagination.page = page;
    this.reloadTariffication();
  }

  filterByPaginationSize(size: number) {
    this.pagination.elements = size;
    this.pagination.page = 0;
    this.reloadTariffication();
  }
  
  /**
   * Call tariffication-resolver when pagination and filters change for retriving products data
   */
  private reloadTariffication(): void {
    this.router.navigate(['tariffication'], {
      queryParams: {
        filter: this.filterData.encode(),
        pageNumber: this.pagination.page,
        pageSize: this.pagination.elements,
        sortElement: this.sort && this.sort.field,
        sortOrder: this.sort && this.sort.order,
        refresh: (new Date()).getTime()
      }
    });
  }  
}
