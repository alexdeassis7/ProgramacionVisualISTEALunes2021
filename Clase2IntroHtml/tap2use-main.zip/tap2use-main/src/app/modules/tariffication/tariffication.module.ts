import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TarifficationRoutingModule } from './tariffication-routing.module';
import { TarifficationListComponent } from './tariffication-list/tariffication-list.component';
import { TarifficationResolver } from './resolvers/tariffication-resolver';
import { SharedModule } from '@app/shared/shared.module';
import { TarifficationDetailsComponent } from './tariffication-details/tariffication-details.component';
import { TarifficationDetailsResolver } from './resolvers/tariffication-details-resolver';


@NgModule({
  declarations: [TarifficationListComponent, TarifficationDetailsComponent],
  imports: [
    CommonModule,
    SharedModule,
    TarifficationRoutingModule
  ],
  providers: [
    TarifficationResolver,
    TarifficationDetailsResolver
  ],
  exports: [
    TarifficationListComponent
  ]
})
export class TarifficationModule { }
