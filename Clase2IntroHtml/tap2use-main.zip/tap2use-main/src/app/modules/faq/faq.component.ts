import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { TranslateService } from '@ngx-translate/core';
import { environment } from '@env/environment';

@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.css'],
  host: {
    class: 'main-container'
  }
})
export class FaqComponent implements OnInit {

  source: any;

  constructor(
    private sanitizer: DomSanitizer,
    private translate: TranslateService
  ) {
    switch (this.translate.currentLang) {
      case 'en':
          this.source = this.sanitizer.bypassSecurityTrustResourceUrl(environment.defaultValue.assetsPage.basePathFAQ + '/FAQ_en.html');
          break;
      case 'fr':
          this.source = this.sanitizer.bypassSecurityTrustResourceUrl(environment.defaultValue.assetsPage.basePathFAQ + '/FAQ_fr.html');
          break;
      case 'de':
          this.source = this.sanitizer.bypassSecurityTrustResourceUrl(environment.defaultValue.assetsPage.basePathFAQ + '/FAQ_de.html');
          break;
      default:
          this.source = this.sanitizer.bypassSecurityTrustResourceUrl(environment.defaultValue.assetsPage.basePathFAQ + '/FAQ_fr.html');
          break;
    }
  }

  ngOnInit() {  }

}
