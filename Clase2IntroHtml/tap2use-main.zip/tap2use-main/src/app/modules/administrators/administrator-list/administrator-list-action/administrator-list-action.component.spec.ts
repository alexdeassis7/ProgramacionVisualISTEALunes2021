import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdministratorListActionComponent } from './administrator-list-action.component';

describe('AdministratorListActionComponent', () => {
  let component: AdministratorListActionComponent;
  let fixture: ComponentFixture<AdministratorListActionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministratorListActionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdministratorListActionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
