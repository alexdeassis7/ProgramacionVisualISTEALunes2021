import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { UserAdmin } from '@app/core/services/administrator/models/userAdmin';
import { AdministratorService } from '@app/core/services/administrator/administrator.service';
import { TranslateService } from '@ngx-translate/core';
import { AccessRoles } from '@app/core/services/administrator/models/accessRoles';
import { KeycloakService } from 'keycloak-angular';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { takeUntil } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-administrator-list-action',
  templateUrl: './administrator-list-action.component.html',
  styleUrls: ['./administrator-list-action.component.css']
})
export class AdministratorListActionComponent extends AbstractOnDestroyComponent implements OnInit {


  @Input()
  administrator:UserAdmin;

  accessRoles = AccessRoles;

  @Output()
  deleted: EventEmitter<boolean> = new EventEmitter<boolean>();


  msg;
  adminReference: any;
  isMe: boolean = false;

  constructor(
    private administratorService:AdministratorService,
    private keycloakService: KeycloakService,
    private translate: TranslateService,
    private toastr: ToastrService) { super(); }

  ngOnInit() {
    this.administrator.userCredentials.userKeycloakId ===
    this.keycloakService.getKeycloakInstance().subject ? this.isMe = true : this.isMe = false;
  }

  deleteAdmin(){
    this.administratorService.deleteAdministrator(this.administrator.userId).subscribe(
      res => {
        this.deleted.emit(true);
        this.translate.get('TOAST.SUCCESS.DELETE')
        .pipe( takeUntil(this.unsubscribe) )
        .subscribe(
          res => this.msg = res
        );
        this.toastr.success(this.msg);
      },
      err => {
        this.translate.get('TOAST.ERROR.FAILED')
        .pipe( takeUntil(this.unsubscribe) )
        .subscribe(
          res => this.msg = res
        );
        this.toastr.error(this.msg);
      }
    )
  }

}
