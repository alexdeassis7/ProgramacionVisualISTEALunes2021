import { Component, OnInit, Input } from '@angular/core';
import { Administrator } from '@app/core/services/administrator/models/administrator';

@Component({
  selector: 'app-administrator-role-label',
  templateUrl: './administrator-role-label.component.html',
  styleUrls: ['./administrator-role-label.component.css']
})
export class AdministratorRoleLabelComponent implements OnInit {

  @Input()
  administrator:Administrator;

  constructor() { }

  ngOnInit() {
  }

}
