import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { AdministratorService } from '@app/core/services/administrator/administrator.service';
import { UserAdmin } from '@app/core/services/administrator/models/userAdmin';
import { TableDataSource } from '@app/core/services/util/tableDataSource';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, MatSortable } from '@angular/material/sort';
import { merge } from 'rxjs';
import { tap, takeUntil } from 'rxjs/operators';
import { Router, ActivatedRoute } from '@angular/router';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { environment } from '@env/environment';

@Component({
  selector: 'app-administrator-list',
  templateUrl: './administrator-list.component.html',
  styleUrls: ['./administrator-list.component.css']
})
export class AdministratorListComponent extends AbstractOnDestroyComponent implements OnInit, AfterViewInit {

  pageSize = environment?.defaultValue?.pageSize;
  companyReference = environment?.defaultValue?.device?.companyReference ?? [];
  administrators: Array<UserAdmin> = [];
  admins: Array<UserAdmin> = [];

  dataSource: TableDataSource<UserAdmin>;

  showFilters = false;

  listRole = Object.keys(UserAdmin.Role).map(function (idx) {
    return UserAdmin.Role[idx];
  });
  filteredRoles = this.listRole.filter(role => role !== UserAdmin.Role.CONTROL);

  filtersInput = { email: '', firstName: '', lastName: '', companyReference: '', role: '' };
  searchInput = '';
  collapse = 'collapse';
  filtersApplied = Object.assign({}, this.filtersInput);

  @ViewChild(MatPaginator, { static: true })
  paginator: MatPaginator;

  @ViewChild(MatSort, { static: true })
  sort: MatSort;

  displayedColumns = [
    'EMAIL',
    'FIRST_NAME',
    'LAST_NAME',
    'COMPANY_REFERENCE',
    'ROLE',
    'ACTIONS'
  ];

  errGettingData = false;
  loaded = false;
  empty = false;

  totalItems = 0;

  constructor(private administratorService: AdministratorService, private route: ActivatedRoute, private router: Router) {
    super();
  }

  ngOnInit() {
    this.dataSource = new TableDataSource<UserAdmin>();
    this.loaded = false;
    this.collapse = 'collapse';
    this.route.queryParams.subscribe(params => {
      if (params['filter'] === 'on') {
        this.collapse = 'collapse in';
        this.updateFilters();
        this.showFilters = true;
      } else {
        this.showFilters = false;
        this.initializeFilters();
      }
    });
  }


  ngAfterViewInit() {
    this.collapse = 'collapse';
    this.route.queryParams.subscribe(params => {
      if (params['filter'] === 'on') {
        this.collapse = 'collapse in';
        this.updateFilters();
        this.showFilters = true;
      } else {
        this.showFilters = false;
        this.initializeFilters();
      }

      this.loadAdministrator();
      // Listen events from sort and paginator element
      this.sort.sortChange
        .pipe( takeUntil(this.unsubscribe))
        .subscribe(_res => this.paginator.pageIndex = 0);

      merge(this.sort.sortChange, this.paginator.page)
        .pipe(takeUntil(this.unsubscribe), tap(() => this.loadAdministrator()))
        .subscribe();
    });
  }

  loadAdministrator() {
    this.loaded = false;
    this.administratorService.getAdministrators(this.filtersApplied, this.sort.direction, this.sort.active, this.paginator.pageIndex, 1)
    .pipe(takeUntil(this.unsubscribe))
    .subscribe(response => {
      this.totalItems = response.totalElements;
      this.administratorService.getAdministrators(this.filtersApplied, this.sort.direction, this.sort.active, 0, response.totalElements)
        .pipe(takeUntil(this.unsubscribe))
        .subscribe(res => {
          this.administrators = [];
          this.admins = [];
          for (let i = 0; i < res.content.length; i++) {
            if (this.filtersApplied.role !== '') {
              if (this.administratorService.getAdminWithMainRole(res.content[i]).mainRole === this.filtersApplied.role) {
                res.content[i].mainRole = this.filtersApplied.role;
                this.admins.push(res.content[i]);
              }
            } else {
              res.content[i] = this.administratorService.getAdminWithMainRole(res.content[i]);
              this.admins.push(res.content[i]);
            }
            this.totalItems = this.admins.length;
          }
          for (let i = this.paginator.pageIndex * this.paginator.pageSize; (i < this.paginator.pageIndex * this.paginator.pageSize + this.paginator.pageSize); i++) {
            if (i < this.admins.length) {
              this.administrators.push(this.admins[i]);
            }
          }
          if (this.totalItems === 0) {
            this.empty = true;
            this.errGettingData = false;
          } else if (this.totalItems > 0) {
            this.empty = false;
            this.errGettingData = false;
          } else {
            this.errGettingData = true;
          }
          this.loaded = true;
        });
    },
    _err => {
      this.errGettingData = true;
      this.loaded = true;
    });
  }

  filterUsersPage() {
    sessionStorage.setItem('filter_administrator', JSON.stringify(this.filtersInput));
    if (!this.router.url.includes('filter')) {
      this.router.navigate([this.router.url], { queryParams: { filter: 'on' } });
    } else {
      if (this.router.url.includes('filter')) {
        this.updateFilters();
        this.showFilters = true;
      } else {
        this.initializeFilters();
      }
      this.resetSort();
    }
  }

  resetFilter() {
    this.initializeFilters();
    this.resetSort();
  }

  private updateFilters(): void {
    const filter: any = JSON.parse(sessionStorage.getItem('filter_administrator'));
    this.filtersInput.email = filter.email || '';
    this.filtersInput.firstName = filter.firstName || '';
    this.filtersInput.lastName = filter.lastName || '';
    this.filtersInput.companyReference = filter.companyReference || '';
    this.filtersInput.role = filter.role || '';
    this.filtersApplied = Object.assign({}, this.filtersInput);
  }

  private initializeFilters(): void {
    this.filtersInput = {
      email: '',
      firstName: '',
      lastName: '',
      companyReference: '',
      role: ''
    };
    this.searchInput = '';
    this.filtersApplied = Object.assign({}, this.filtersInput);
  }

  viewFilters() {
    this.showFilters = !this.showFilters;
  }

  resetSort() {
    if (this.sort.active !== 'EMAIL') {
      this.sort.sort(<MatSortable>{ id: 'EMAIL', start: 'asc' });
    } else {
      this.paginator.pageIndex = 0;
      this.loadAdministrator();
    }
  }

  refresh(event: boolean) {
    if (event) {
      this.loadAdministrator();
    }
  }

}
