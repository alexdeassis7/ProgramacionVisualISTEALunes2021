import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdministratorRoleLabelComponent } from './administrator-role-label.component';

describe('AdministratorRoleLabelComponent', () => {
  let component: AdministratorRoleLabelComponent;
  let fixture: ComponentFixture<AdministratorRoleLabelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministratorRoleLabelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdministratorRoleLabelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
