import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AdministratorService } from '@app/core/services/administrator/administrator.service';
import { TranslateService } from '@ngx-translate/core';
import { AccessRoles } from '@app/core/services/administrator/models/accessRoles';
import { UserAdmin } from '@app/core/services/administrator/models/userAdmin';
import { UserAdminDetails } from '@app/core/services/administrator/models/userAdminDetails';
import { UserAdminCredentials } from '@app/core/services/administrator/models/userAdminCredentials';
import { takeUntil } from 'rxjs/operators';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { ToastrService } from 'ngx-toastr';
import { environment } from '@env/environment';

@Component({
  selector: 'app-create-administrator',
  templateUrl: './create-administrator.component.html',
  styleUrls: ['./create-administrator.component.css']
})
export class CreateAdministratorComponent extends AbstractOnDestroyComponent implements OnInit {

  newAdmin: UserAdmin = <UserAdmin>{};
  companyReferenceDefaultValues: string[];

  role = {
    superAdmin: false,
    admin: false,
    sav: false,
    statistic: false,
    operator: false,
    serviceOperator: false,
    control: false,
    agent: false
  };

  missingRole = false;

  loading = false;

  accessRoles = AccessRoles;

  constructor(private administratorService: AdministratorService, private toastr: ToastrService, protected translate: TranslateService) {
    super();
  }

  ngOnInit() {
    this.newAdmin.userDetails = <UserAdminDetails>{};
    this.newAdmin.userCredentials = <UserAdminCredentials>{};
    this.companyReferenceDefaultValues = environment?.defaultValue?.device?.companyReference ?? [];
  }

  submitCreationForm(userCreationForm: NgForm) {
    this.loading = true;
    if (userCreationForm.valid) {
      this.newAdmin.userCredentials.username = this.newAdmin.userDetails.userEmailAddress;
      this.missingRole = false;
      if (this.role.superAdmin) {
        this.newAdmin.roles = ['SUPER_ADMIN'];
      } else if (this.role.admin) {
        this.newAdmin.roles = ['ADMIN'];
      } else if (this.role.sav) {
        this.newAdmin.roles = ['SAV'];
      } else if (this.role.statistic) {
        this.newAdmin.roles = ['STATS'];
      } else if (this.role.agent) {
        this.newAdmin.roles = ['AGENT'];
      } else if (this.role.operator) {
        this.newAdmin.roles = ['OPERATOR'];
      } else if (this.role.serviceOperator) {
        this.newAdmin.roles = ['SERVICE_OPERATOR'];
      } else {
        this.missingRole = true;
      }

      if (!this.missingRole) {
        this.administratorService.createUserBack(this.newAdmin)
          .pipe(takeUntil(this.unsubscribe))
          .subscribe(_result => {
            this.loading = false;
            this.toastr.success(this.translate.instant('TOAST.SUCCESS.CREATIONADMINUSER'));
            userCreationForm.resetForm();
            this.resetRoles();
          },
          err => {
            this.loading = false;
            const messageKey = err.status === 409 ? 'ERROR_PAGE.INTERNAL_DUPLICATED_MSG' : 'ERROR_PAGE.INTERNAL_ERROR_MSG';
            this.toastr.error(this.translate.instant(messageKey));
          });
      } else {
        this.loading = false;
        this.toastr.warning(this.translate.instant('ERROR.PATTERN.ROLES'));
      }
    }
  }

  updateRole(key: string) {
    for (const field of Object.keys(this.role)) {
      this.role[field] = field === key ? !this.role[field] : false;
    }
  }

  private resetRoles() {
    this.role = {
      superAdmin: false,
      admin: false,
      sav: false,
      statistic: false,
      operator: false,
      serviceOperator: false,
      control: false,
      agent: false
    };

    this.missingRole = false;
  }
}
