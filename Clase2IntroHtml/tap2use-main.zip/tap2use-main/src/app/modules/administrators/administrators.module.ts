import { NgModule } from '@angular/core';
import { UiSwitchModule } from 'ngx-ui-switch';
import { CommonModule } from '@angular/common';
import { SharedModule } from '@app/shared/shared.module';
import { CreateAdministratorComponent } from './create-administrator/create-administrator.component';
import { AdministratorListComponent } from './administrator-list/administrator-list.component';
import { AdministratorListActionComponent } from './administrator-list/administrator-list-action/administrator-list-action.component';
import { TranslateModule } from '@ngx-translate/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { ManageAdministratorComponent } from './manage-administrator/manage-administrator.component';
import { AdministratorRoleLabelComponent } from './administrator-list/administrator-role-label/administrator-role-label.component';
import { AdministratorsRoutingModule } from './administrators-routing.module';

@NgModule({
  imports: [
    CommonModule,
    UiSwitchModule,
    TranslateModule,
    MatButtonModule,
    MatCheckboxModule,
    MatSelectModule,
    MatRadioModule,
    MatTableModule,
    SharedModule,
    AdministratorsRoutingModule
  ],
  declarations: [CreateAdministratorComponent, AdministratorListComponent, AdministratorListActionComponent, ManageAdministratorComponent, AdministratorRoleLabelComponent]
})
export class AdministratorsModule { }
