import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { AdministratorService } from '@app/core/services/administrator/administrator.service';
import { Router, ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import { AccessRoles } from '@app/core/services/administrator/models/accessRoles';
import { UserAdmin } from '@app/core/services/administrator/models/userAdmin';
import { KeycloakService } from 'keycloak-angular';
import { takeUntil } from 'rxjs/operators';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { environment } from '@env/environment';


@Component({
  selector: 'app-manage-administrator',
  templateUrl: './manage-administrator.component.html',
  styleUrls: ['./manage-administrator.component.css']
})
export class ManageAdministratorComponent extends AbstractOnDestroyComponent implements OnInit {
  constructor(
    private administratorService: AdministratorService,
    private keycloakService: KeycloakService,
    private toastr: ToastrService,
    private translate: TranslateService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    super();
  }

  administrator: UserAdmin;
  companyReferenceDefaultValues: string[];

  adminId: number;
  isMe = false;
  errGettingData = false;
  loaded = false;
  empty = false;

  role = {
    superAdmin: false,
    admin: false,
    sav: false,
    statistic: false,
    operator: false,
    serviceOperator: false,
    control: false,
    agent: false
  };
  missingRole = false;

  accessRoles = AccessRoles;

  currentRole: UserAdmin.Role;

  roles: string[];
  disableAction = false;

  mainRole;

  ngOnInit() {
    this.adminId = this.route.snapshot.params.id;
    this.loadAdministrator();
    this.companyReferenceDefaultValues = environment?.defaultValue?.device?.companyReference ?? [];
    this.roles = this.keycloakService.getUserRoles();

    if (this.roles.indexOf(UserAdmin.Role.SUPER_ADMIN) > -1) {
      this.currentRole = UserAdmin.Role.SUPER_ADMIN;
    } else if (this.roles.indexOf(UserAdmin.Role.ADMIN) > -1) {
      this.currentRole = UserAdmin.Role.ADMIN;
    } else if (this.roles.indexOf(UserAdmin.Role.SAV) > -1) {
      this.currentRole = UserAdmin.Role.SAV;
    } else if (this.roles.indexOf(UserAdmin.Role.AGENT) > -1) {
      this.currentRole = UserAdmin.Role.AGENT;
    } else if (this.roles.indexOf(UserAdmin.Role.STATS) > -1) {
      this.currentRole = UserAdmin.Role.STATS;
    } else if (this.roles.indexOf(UserAdmin.Role.OPERATOR) > -1) {
      this.currentRole = UserAdmin.Role.OPERATOR;
    } else if (this.roles.indexOf(UserAdmin.Role.SERVICE_OPERATOR) > -1) {
      this.currentRole = UserAdmin.Role.SERVICE_OPERATOR;
    }

  }

  setDisableAction() {
    this.disableAction =
      (this.currentRole === this.accessRoles.ROLE_SAV &&
        (this.administrator.mainRole === this.accessRoles.ROLE_SUPER_ADMIN ||
          this.administrator.mainRole === this.accessRoles.ROLE_ADMIN)) ||
      (this.currentRole === this.accessRoles.ROLE_ADMIN &&
        this.administrator.mainRole === this.accessRoles.ROLE_SUPER_ADMIN);
  }

  loadAdministrator() {
    this.administratorService.getAdministrator(this.adminId)
    .pipe( takeUntil(this.unsubscribe) )
    .subscribe(_res => {
      this.administrator = _res;
      this.loaded = true;
      this.administrator = this.administratorService.getAdminWithMainRole(this.administrator);
      this.setRole();
      this.setDisableAction();
      this.mainRole = this.administrator.mainRole;

      this.keycloakService.loadUserProfile().then(agent => {
        this.isMe = agent.email === this?.administrator?.userDetails?.userEmailAddress;
      });
    },
    _err => {
      this.loaded = true;
      this.errGettingData = true;
    });
  }

  setRole() {

    switch (this.administrator.mainRole) {
      case UserAdmin.Role.SUPER_ADMIN:
        this.role.superAdmin = true;
        break;

      case UserAdmin.Role.ADMIN:
        this.role.admin = true;
        break;

      case UserAdmin.Role.SAV:
        this.role.sav = true;
        break;

      case UserAdmin.Role.AGENT:
        this.role.agent = true;
        break;

      case UserAdmin.Role.STATS:
        this.role.statistic = true;
        break;

      case UserAdmin.Role.OPERATOR:
        this.role.operator = true;
        break;

      case UserAdmin.Role.SERVICE_OPERATOR:
        this.role.serviceOperator = true;
        break;
    }
  }

  submitCreationForm(userUpdateForm: NgForm) {
    if (userUpdateForm.valid) {

      if (this.role.superAdmin) {
        this.administrator.roles = [ UserAdmin.Role.SUPER_ADMIN ];
      } else if (this.role.admin) {
        this.administrator.roles = [ UserAdmin.Role.ADMIN ];
      } else if (this.role.sav) {
        this.administrator.roles = [ UserAdmin.Role.SAV ];
      } else if (this.role.agent) {
        this.administrator.roles = [ UserAdmin.Role.AGENT ];
      } else if (this.role.statistic) {
        this.administrator.roles = [ UserAdmin.Role.STATS ];
      } else if (this.role.operator) {
        this.administrator.roles = [ UserAdmin.Role.OPERATOR ];
      } else if (this.role.serviceOperator) {
        this.administrator.roles = [ UserAdmin.Role.SERVICE_OPERATOR ];
      } else {
        this.missingRole = true;
      }

      delete(this.administrator.mainRole);
      delete(this.administrator.userCreationDate);
      delete(this.administrator.userDetails.userId);
      delete(this.administrator.userCredentials.userId);
      delete(this.administrator.userCredentials.userKeycloakId);
      delete(this.administrator.userCredentials.userRealm);

      this.administratorService
        .updateUserBack(this.administrator, this.adminId)
        .pipe(takeUntil(this.unsubscribe))
        .subscribe(_result => {
          this.toastr.success(this.translate.instant('TOAST.SUCCESS.MODIFICATION'));
          this.administrator.mainRole = this.mainRole;
        },
        _err => {
          this.toastr.error(this.translate.instant('TOAST.ERROR.FAILED'));
        });
    }
  }

  deleteAccount() {
    this.administratorService
      .deleteAdministrator(this.administrator.userId)
      .pipe(takeUntil(this.unsubscribe))
      .subscribe(_result => {
        this.router.navigate(['/administrators']);
        this.toastr.success(this.translate.instant('TOAST.SUCCESS.DELETE'));
      },
      _err => {
         this.toastr.error(this.translate.instant('TOAST.ERROR.FAILED'));
      });
  }

  reinitAccount() {
    this.router.navigate(['/administrators/externalRedirect'], {
      skipLocationChange: true
    });
  }

  updateRole(key: string) {
    for (const field of Object.keys(this.role)) {
      if (field === key) {
        this.role[field] = !this.role[field];
        this.mainRole = this.getRoleFromKey(field);
      } else {
        this.role[field] = false;
      }
    }
  }

  private getRoleFromKey = str => str.replace(/[A-Z]/g, letter => `_${letter}`).toUpperCase();

}
