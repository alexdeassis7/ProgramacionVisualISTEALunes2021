import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppAuthGuard } from '@app/core/guards/authguard';
import { AccessRoles } from '@app/core/services/administrator/models/accessRoles';
import { CreateAdministratorComponent } from './create-administrator/create-administrator.component';
import { AdministratorListComponent } from './administrator-list/administrator-list.component';
import { ManageAdministratorComponent } from './manage-administrator/manage-administrator.component';
import { RedirectingViewComponent } from '@app/shared/redirecting-view/redirecting-view.component';

const routes: Routes = [
  {
    path: 'registration',
    component: CreateAdministratorComponent,
    canActivate: [AppAuthGuard],
    data: { role: [AccessRoles.ROLE_SUPER_ADMIN, AccessRoles.ROLE_ADMIN, AccessRoles.ROLE_SAV] }
  },
  {
    path: 'externalRedirect',
    component: RedirectingViewComponent,
    canActivate: [AppAuthGuard],
    data: { role: [AccessRoles.ROLE_SUPER_ADMIN, AccessRoles.ROLE_ADMIN] }
  },
  {
    path: '',
    component: AdministratorListComponent,
    canActivate: [AppAuthGuard],
    data: { role: [AccessRoles.ROLE_SUPER_ADMIN, AccessRoles.ROLE_ADMIN, AccessRoles.ROLE_SAV] }
  },
  {
    path: ':id',
    component: ManageAdministratorComponent,
    canActivate: [AppAuthGuard],
    data: { role: [AccessRoles.ROLE_SUPER_ADMIN, AccessRoles.ROLE_ADMIN, AccessRoles.ROLE_SAV] }
  }

];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
  ],
  providers: []
})
export class AdministratorsRoutingModule { }
