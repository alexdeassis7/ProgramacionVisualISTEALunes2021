import { SimpleModalService } from 'ngx-simple-modal';
import { Component, OnInit } from '@angular/core';
import { NavigationCancel, NavigationEnd, NavigationError, RouteConfigLoadEnd, Router, RouterEvent } from '@angular/router';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { DeviceService } from '@app/core/services/device/device.service';
import { FieldContainer } from '@app/core/services/device/models/fieldContainer';
import { AccessRoles } from '@app/core/services/administrator/models/accessRoles';
import { tap, takeUntil } from 'rxjs/operators';
import { ConfirmComponent } from '@app/shared/components/confirm/confirm.component';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { environment } from '@env/environment';
import { FareCollectionEngineService } from '@app/core/services/fare-collection-engine/fareCollectionEngine.service';


@Component({
  selector: 'app-bulk-configuration',
  templateUrl: './bulk-configuration.component.html',
  styleUrls: ['./bulk-configuration.component.css']
})
export class BulkConfigurationComponent extends AbstractOnDestroyComponent implements OnInit {

  pois: string[] = [];
  fieldContainers: FieldContainer[] = [];
  updatedFieldContainer: FieldContainer = { value: '', field: { description: '' }};
  error = false;
  loading = true;
  config = environment.defaultValue.device;
  permissions: string[] = [
    AccessRoles.ROLE_SUPER_ADMIN, AccessRoles.ROLE_ADMIN, AccessRoles.ROLE_OPERATOR, AccessRoles.ROLE_SERVICE_OPERATOR
  ];
  suggestions: any[] = [];
  options: string[] = [];
  showOptions = false;

  constructor(private router: Router,
    private deviceService: DeviceService,
    private simpleModalService: SimpleModalService,
    private translateService: TranslateService,
    private readonly toastr: ToastrService,
    private fceService: FareCollectionEngineService) {
    super();
  }

  ngOnInit() {
    this.loading = true;
    if (!history || !history.state || !history.state.devicesId || history.state.devicesId.length < 1 ) {
      return this.error = true;
    }

    this.pois = history.state.devicesId;
    this.loadDeviceConfigFlat();
  }

  private loadDeviceConfigFlat () {
    this.deviceService.getDeviceConfigFlatV2(this.pois[0])
    .pipe(tap(() => { this.loading = true; }))
    .pipe(takeUntil(this.unsubscribe))
    .subscribe(data => {
      if (data) {
        this.fieldContainers = data.fields;
        return this.loading = false;
      }
      this.error = true;
    });
  }

  selectField() {
    this.initSelect();
    this.permissions = this.getPermissions();
    this.getSuggestions();
  }

  confirmSave() {
    const options = {
      title: 'DEVICE.LABELS.CONFIGURATION.BULK.TITLE',
      message: this.translateService.instant('DEVICE.LABELS.CONFIGURATION.BULK.SAVE_MESSAGE', { numberOfDevices: this.pois.length }),
      confirmButton: 'ACTIONS.SEND',
      closeButton: 'ACTIONS.CANCEL'
    };

    const modal = this.simpleModalService.addModal(ConfirmComponent, options).subscribe( isConfirmed => {
      if (isConfirmed) {
        this.deviceService.patchDeviceConfigBulkV2({ pois: this.pois, fieldValue: this.updatedFieldContainer })
          .pipe(tap(() => { this.loading = true; }))
          .pipe(takeUntil(this.unsubscribe))
          .subscribe((data) => {
            if (data) {
              this.loadDeviceConfigFlat();
              this.toastr.success(this.translateService.instant('TOAST.SUCCESS.MODIFICATION'));
              return this.loading = false;
            }
            this.toastr.error(this.translateService.instant('TOAST.ERROR.FAILED'));
         });
      }
    });

    // Automatically close modal after 30 seconds
    setTimeout( () => modal.unsubscribe(), 30 * 1000);
  }

  backToList() {
    this.router.navigate(['/devices']);
  }

  private initSelect(): void {
    this.showOptions = false;

    if (this.updatedFieldContainer.field.description === 'listParameter[deviceModel].paramValue') {
      this.showOptions = true;
      this.options = this.config.deviceModel;
    }

    if (this.updatedFieldContainer.field.description === 'listParameter[transportMode].paramValue') {
      this.showOptions = true;
      this.options = this.config.transportMode;
    }

    if (this.updatedFieldContainer.field.description === 'listParameter[installationType].paramValue') {
      this.showOptions = true;
      this.options = this.config.installationType;
    }
  }

  private getPermissions(): string[] {

    const superAdminPermission = [
      'connectivity.mode3g', 'connectivity.language', 'validator.validatorFirmwareVersion', 'validator.operatorId',
      'validator.corridorId', 'validator.zoneId', 'validator.stageId', 'validator.directionType', 'validator.ticketId',
      'validator.coordinateLatitude', 'validator.coordinateLongitude', 'log.level'
    ];

    if (superAdminPermission.includes(this.updatedFieldContainer.field.description)) {
      return [ AccessRoles.ROLE_SUPER_ADMIN ];
    }

    if (this.updatedFieldContainer.field.description.split('[')[0] === 'applications') {
      return [ AccessRoles.ROLE_SUPER_ADMIN ];
    }

    return [ AccessRoles.ROLE_SUPER_ADMIN, AccessRoles.ROLE_ADMIN, AccessRoles.ROLE_OPERATOR, AccessRoles.ROLE_SERVICE_OPERATOR ];
  }

  private getSuggestions(): void {

    if (this.updatedFieldContainer.field.description.split('[')[0] === 'listParameter') {
      return this.suggestions = this.config.autocomplete.parameter[this.updatedFieldContainer.field.pathValues[0]]
        .map(value => ({ value: value, description: value}));
    }

    if (this.updatedFieldContainer.field.description.split('[')[0] === 'applications') {
      const pathValuesSize = this.updatedFieldContainer.field.pathValues.length - 1;
      return this.suggestions = this.config.autocomplete.application.parameter[this.updatedFieldContainer.field.pathValues[pathValuesSize]]
        .map(value => ({ value: value, description: value}));
    }

    if (this.updatedFieldContainer.field.description === 'validator.lineId') {
      return this.fetchLines();
    }

    if (this.updatedFieldContainer.field.description === 'validator.stationId') {
      return this.fetchStations();
    }

    if (this.updatedFieldContainer.field.description === 'validator.directionType') {
      return this.fetchDirectionType();
    }

    this.suggestions = [];
  }

  private fetchLines(): void {
    this.fceService.getLines()
      .pipe(tap(() => { this.loading = true; }))
      .pipe(takeUntil(this.unsubscribe))
      .subscribe((res) => {
        this.suggestions = res.data.map((line) => ({
          value: line.lineReference,
          description: `${line.lineReference} : ${line.lineName}`
        }));
        this.loading = false;
      });
  }

  private fetchStations(): void {
    const lineId = this.fieldContainers.find((fieldContainer) => {
      return fieldContainer.field.description === 'validator.lineId';
    }).value;

    if (lineId) {
      this.fceService.getStopsByLineReference(lineId)
        .pipe(tap(() => { this.loading = true; }))
        .pipe(takeUntil(this.unsubscribe))
        .subscribe((res) => {
          this.suggestions = res.data.map((stop) => ({
            value: stop.stopReference,
            description: `${stop.stopReference} : ${stop.stopDescription}`
          }));
          this.loading = false;
        });
    }
  }

  private fetchDirectionType(): void {
    this.fceService.getDirectionTypes()
      .pipe(tap(() => { this.loading = true; }))
      .pipe(takeUntil(this.unsubscribe))
      .subscribe((res) => {
        this.suggestions = res.data.map((directionType) => ({
          value: directionType.id,
          description: `${directionType.id} : ${directionType.name}`
        }));
        this.loading = false;
      });
  }
}
