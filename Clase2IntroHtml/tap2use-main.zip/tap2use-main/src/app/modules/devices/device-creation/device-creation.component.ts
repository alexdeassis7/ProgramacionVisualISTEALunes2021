import { UtilService } from './../../../core/services/util/util.service';
import { ConfigurationFileV2 } from './../../../core/services/device/models/configurationFileV2';
import { Parameter } from './../../../core/services/device/models/parameter';
import { DeviceConfigurationV2 } from './../../../core/services/device/models/deviceConfigurationV2';
import { DeviceConfigV2Template } from './../../../core/services/device/models/deviceConfigV2Template';
import { Component, OnInit } from '@angular/core';
import { AccessRoles } from '@app/core/services/administrator/models/accessRoles';
import { Router, ActivatedRoute, RouterEvent, RouteConfigLoadEnd, NavigationEnd, NavigationCancel, NavigationError } from '@angular/router';
import { DeviceService } from '@app/core/services/device/device.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { environment } from '@env/environment';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { KeycloakService } from 'keycloak-angular';

@Component({
  selector: 'app-device-creation',
  templateUrl: './device-creation.component.html',
  styleUrls: ['./device-creation.component.css']
})
export class DeviceCreationComponent implements OnInit {

  accessRoles = AccessRoles;

  loaded = false;
  errorSavingData = false;
  error = false;
  configTemplates: DeviceConfigV2Template[];
  companyReferenceValues: string[];
  defaultCompanyReference: string;
  config = environment.defaultValue.device;

  mainRole: string;

  deviceCreationForm: FormGroup;

  constructor(
    public router: Router,
    private route: ActivatedRoute,
    private deviceService: DeviceService,
    private utilService: UtilService,
    private formBuilder: FormBuilder,
    private keycloakService: KeycloakService,
    private toastr: ToastrService,
    private translateService: TranslateService) {

    router.events.subscribe((event: RouterEvent): void => {
      switch (true) {
        case event instanceof RouteConfigLoadEnd:
        case event instanceof NavigationEnd:
          this.loaded = true;
          break;
        case event instanceof NavigationCancel:
        case event instanceof NavigationError: {
          this.loaded = true;
          break;
        }
        default: {
          this.loaded = false;
          break;
        }
      }
    });
  }

  ngOnInit() {
    this.configTemplates = this.route.snapshot.data.deviceConfigV2Templates;
    this.error = !this.configTemplates || this.configTemplates.length === 0;
    this.mainRole = this.getMainRole();
    this.companyReferenceValues = this.getCompanyReferenceValues();

    this.deviceCreationForm = this.formBuilder.group({
      identifier: ['', [Validators.required, Validators.pattern('^(?!\s*$).+')] ],
      function: ['', Validators.required ],
      deviceModel: ['', Validators.required ],
      companyReference: [{
        value: this.defaultCompanyReference,
        disabled: ![this.accessRoles.ROLE_SUPER_ADMIN, this.accessRoles.ROLE_ADMIN].includes(this.mainRole)
      }]
    });
  }

  private getMainRole(): string {
    const roles = this.keycloakService.getUserRoles();

    if (roles.includes(AccessRoles.ROLE_SUPER_ADMIN)) {
      return AccessRoles.ROLE_SUPER_ADMIN;
    }

    if (roles.includes(AccessRoles.ROLE_ADMIN)) {
      return AccessRoles.ROLE_ADMIN;
    }

    if (roles.includes(AccessRoles.ROLE_OPERATOR)) {
      return AccessRoles.ROLE_OPERATOR;
    }

    return AccessRoles.ROLE_SERVICE_OPERATOR;
  }

  private getCompanyReferenceValues(): string[] {
    const companyReferenceValues = environment?.defaultValue?.device?.companyReference ?? [];
    this.defaultCompanyReference = '';

    if (this.mainRole === AccessRoles.ROLE_SERVICE_OPERATOR) {
      const companyRef = this.utilService.getVariable('companyRef', 'session');
      this.defaultCompanyReference = companyRef;
      return [companyRef];
    }

    if (companyReferenceValues.length === 1) {
      this.defaultCompanyReference = companyReferenceValues[0];
    }

    return companyReferenceValues;
  }

  submitDeviceCreationForm() {
    if (this.deviceCreationForm.valid) {
      const functionParameter: Parameter = { paramName: 'function', paramValue: this.deviceCreationForm.controls.function.value };
      const deviceModelParameter: Parameter = { paramName: 'deviceModel', paramValue: this.deviceCreationForm.controls.deviceModel.value };
      const selectedTemplate = this.configTemplates.find(template => template.name === functionParameter.paramValue);
      const deviceConfig: DeviceConfigurationV2 = {
        id: this.deviceCreationForm.controls.identifier.value.trim().padStart(8, '0'),
        configurationFile: this.initConfigurationFile(selectedTemplate.configurationFile)
      };

      const companyId = this.deviceCreationForm.controls.companyReference.value;
      Object.assign(deviceConfig.configurationFile.validator, {  companyId });

      this.addOrUpdateParameter(functionParameter, deviceConfig);
      this.addOrUpdateParameter(deviceModelParameter, deviceConfig);

      // Call API to create device configuration
      this.deviceService.createOrUpdateDeviceConfigV2(deviceConfig).subscribe((deviceConfigResponse: DeviceConfigurationV2) => {
        this.deviceCreationForm.reset();
        this.toastr.success(this.translateService.instant('DEVICE.CREATE.TOAST.CREATED', { poi: deviceConfigResponse.id }));
      },
      _err => {
        this.errorSavingData = true;
      });

    }
  }

  private initConfigurationFile(configurationFile): ConfigurationFileV2 {
    const configurationFileV2 = Object.assign({}, configurationFile);
    if (!configurationFileV2.listParameter) {
      configurationFileV2.listParameter = [];
    }

    return configurationFileV2;
  }

  private addOrUpdateParameter(parameter: Parameter, deviceConfig: DeviceConfigurationV2): void {
    const index = deviceConfig.configurationFile.listParameter.findIndex(({paramName}) =>  parameter.paramName === paramName);
    if (index > -1) {
      deviceConfig.configurationFile.listParameter[index] = parameter;
      return;
    }
    deviceConfig.configurationFile.listParameter.push(parameter);
  }
}
