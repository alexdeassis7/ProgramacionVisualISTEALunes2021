import { ConfirmComponent } from '@app/shared/components/confirm/confirm.component';
import { TranslateService } from '@ngx-translate/core';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, RouterEvent, RouteConfigLoadEnd, NavigationEnd, NavigationCancel, NavigationError } from '@angular/router';
import { DeviceService } from '@app/core/services/device/device.service';
import { DeviceConfigV2Template } from '@app/core/services/device/models/deviceConfigV2Template';
import { ToastrService } from 'ngx-toastr';
import { SimpleModalService } from 'ngx-simple-modal';
import cloneDeep from 'lodash.clonedeep';

@Component({
  selector: 'ap-device-default-configuration',
  templateUrl: './device-default-configuration.component.html',
  styleUrls: ['./device-default-configuration.component.css']
})
export class DeviceDefaultConfigurationComponent implements OnInit {

  loaded = false;
  error = false;
  errorSavingData = false;
  configTemplates: DeviceConfigV2Template[];
  editedMap: Map<string, boolean>;
  _template: DeviceConfigV2Template;

  get template(): DeviceConfigV2Template {
    return this._template;
  }

  set template(deviceConfigV2Template: DeviceConfigV2Template) {
    this._template = deviceConfigV2Template;
    window.history.replaceState({}, '', `devices/default-configuration/${deviceConfigV2Template.id}`);
  }

  constructor(public router: Router, private route: ActivatedRoute, private deviceService: DeviceService,
    private toastr: ToastrService, private translateService: TranslateService, private simpleModalService: SimpleModalService) {
    router.events.subscribe((event: RouterEvent): void => {
      switch (true) {
        case event instanceof RouteConfigLoadEnd:
        case event instanceof NavigationEnd:
          this.loaded = true;
          break;
        case event instanceof NavigationCancel:
        case event instanceof NavigationError: {
          this.loaded = true;
          break;
        }
        default: {
          this.loaded = false;
          break;
        }
      }
    });
  }

  ngOnInit() {
    this.editedMap = new Map();
    this.configTemplates = cloneDeep(this.route.snapshot.data.deviceConfigV2Templates);

    if (!this.configTemplates || this.configTemplates.length === 0) {
      this.error = true;
      return;
    }

    this.template = this.configTemplates.find(({ id }) => id === this.route.snapshot.params.id) || this.configTemplates[0];
  }

  rollback() {
    this.configTemplates = cloneDeep(this.route.snapshot.data.deviceConfigV2Templates);
    this.template = this.configTemplates.find(({ id }) => id === this.route.snapshot.params.id) || this.configTemplates[0];
    this.editedMap = new Map();
  }

  update(elementId) {
    this.editedMap.set(elementId, true);
  }

  modifyParameters(event) {
    switch (event.name) {
      case 'add-parameter':
        this.template.configurationFile.listParameter = this.template.configurationFile.listParameter.concat([event.message]);
        break;
      case 'remove-parameter':
        const indexToRemove = this.template.configurationFile.listParameter.findIndex(({ paramName }) => {
          return paramName === event.message.paramName;
        });
        this.template.configurationFile.listParameter.splice(indexToRemove, 1);
        this.template.configurationFile.listParameter = [...this.template.configurationFile.listParameter];
        break;
    }
  }

  changeTemplate(configTempate: DeviceConfigV2Template) {
    if (this.editedMap.size === 0) {
      this.template = configTempate;
      return;
    }
    const modal = this.simpleModalService.addModal(ConfirmComponent, this.getModalOptions()).subscribe( isConfirmed => {
      if (isConfirmed) {
        this.saveDefaultConfiguration();
      } else {
        this.configTemplates = cloneDeep(this.route.snapshot.data.deviceConfigV2Templates);
        this.editedMap = new Map();
      }
      this.template = configTempate;
    });

    // Automatically close modal after 30 seconds
    setTimeout( () => modal.unsubscribe(), 30 * 1000);
  }

  confirmSave() {
    const modal = this.simpleModalService.addModal(ConfirmComponent, this.getModalOptions()).subscribe( isConfirmed => {
      if (isConfirmed) {
        this.saveDefaultConfiguration();
      }
    });

    // Automatically close modal after 30 seconds
    setTimeout( () => modal.unsubscribe(), 30 * 1000);
  }

  private getModalOptions(): any {
    return {
      title: 'DEVICE.LABELS.CONFIGURATION.DEFAULT.TITLE',
      message:
        this.translateService.instant('DEVICE.LABELS.CONFIGURATION.DEFAULT.SUBTITLE') +
        ' ' + this.template.name + ' - ' +
        this.translateService.instant('DEVICE.LABELS.CONFIGURATION.SAVE_MESSAGE'),
      confirmButton: 'ACTIONS.SEND',
      closeButton: 'ACTIONS.CANCEL'
    };
  }

  private saveDefaultConfiguration(): void {
    this.deviceService.updateDeviceConfigV2Template(this.template).subscribe((data) => {
      const index = this.configTemplates.findIndex(({ id }) => id === data.id);
      this.configTemplates[index] = this.template = data;
      this.editedMap = new Map();
      this.toastr.success(this.translateService.instant('TOAST.SUCCESS.MODIFICATION'));
    },
    err => {
      this.errorSavingData = true;
    });
  }
}
