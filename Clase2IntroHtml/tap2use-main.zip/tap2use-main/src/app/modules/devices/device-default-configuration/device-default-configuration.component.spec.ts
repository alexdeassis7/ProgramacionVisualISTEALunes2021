import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeviceDefaultConfigurationComponent } from './device-default-configuration.component';

describe('DeviceDefaultConfigurationComponent', () => {
  let component: DeviceDefaultConfigurationComponent;
  let fixture: ComponentFixture<DeviceDefaultConfigurationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeviceDefaultConfigurationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeviceDefaultConfigurationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
