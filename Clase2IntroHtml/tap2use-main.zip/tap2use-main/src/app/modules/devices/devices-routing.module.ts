import { LinesResolver } from './resolvers/lines-resolver';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppAuthGuard } from '@app/core/guards/authguard';
import { AccessRoles } from '@app/core/services/administrator/models/accessRoles';
import { DeviceDetailsComponent } from './device-details/device-details.component';
import { DeviceConfigurationsComponent } from './device-details/device-configurations/device-configurations.component';
import { DeviceHistoryComponent } from './device-details/device-history/device-history.component';
import { DeviceInformationsComponent } from './device-details/device-informations/device-informations.component';
import { DeviceInfoV3Resolver } from './resolvers/device-info-v3-resolver';
import { XenturionInfoV3Resolver } from './resolvers/xenturion-info-v3-resolver';
import { DeviceConfigV2Resolver } from './resolvers/device-config-v2-resolver';
import { DirectionTypesResolver } from './resolvers/direction-types-resolver';
import { DeviceCreationComponent } from './device-creation/device-creation.component';
import { DeviceConfigV2TemplateResolver } from './resolvers/device-config-v2-template-resolver';
import { DeviceDefaultConfigurationComponent } from './device-default-configuration/device-default-configuration.component';
import { DeviceListComponent } from './device-list/device-list.component';
import { DevicesResolver } from './resolvers/devices-resolver';
import { DeviceResolver } from './resolvers/device-resolver';
import { BulkConfigurationComponent } from './bulk-configuration/bulk-configuration.component';

const routes: Routes = [
  {
    path: '',
    component: DeviceListComponent,
    canActivate: [AppAuthGuard],
    data: { role: [AccessRoles.ROLE_SUPER_ADMIN, AccessRoles.ROLE_ADMIN, AccessRoles.ROLE_OPERATOR, AccessRoles.ROLE_SERVICE_OPERATOR] },
    resolve: { pageDevice: DevicesResolver },
    runGuardsAndResolvers: 'paramsOrQueryParamsChange',
  },
  {
    path: 'add',
    component: DeviceCreationComponent,
    canActivate: [AppAuthGuard],
    data: { role: [ AccessRoles.ROLE_SUPER_ADMIN, AccessRoles.ROLE_ADMIN, AccessRoles.ROLE_OPERATOR, AccessRoles.ROLE_SERVICE_OPERATOR ] },
    resolve: { deviceConfigV2Templates: DeviceConfigV2TemplateResolver}
  },
  {
    path: 'default-configuration',
    component: DeviceDefaultConfigurationComponent,
    canActivate: [AppAuthGuard],
    data: { role: [ AccessRoles.ROLE_SUPER_ADMIN ] },
    resolve: { deviceConfigV2Templates: DeviceConfigV2TemplateResolver, lines: LinesResolver }
  },
  {
    path: 'default-configuration/:id',
    component: DeviceDefaultConfigurationComponent,
    canActivate: [AppAuthGuard],
    data: { role: [ AccessRoles.ROLE_SUPER_ADMIN ] },
    resolve: { deviceConfigV2Templates: DeviceConfigV2TemplateResolver, lines: LinesResolver }
  },
  {
    path: 'bulk-configuration',
    component: BulkConfigurationComponent,
    canActivate: [AppAuthGuard],
    data: { role: [ AccessRoles.ROLE_SUPER_ADMIN, AccessRoles.ROLE_ADMIN, AccessRoles.ROLE_OPERATOR, AccessRoles.ROLE_SERVICE_OPERATOR ] }
  },
  {
    path: ':poi',
    component: DeviceDetailsComponent,
    canActivate: [AppAuthGuard],
    data: { role: [ AccessRoles.ROLE_SUPER_ADMIN, AccessRoles.ROLE_ADMIN, AccessRoles.ROLE_OPERATOR, AccessRoles.ROLE_SERVICE_OPERATOR ] },
    children: [
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'informations'
      },
      {
        path: 'informations',
        component: DeviceInformationsComponent,
        canActivate: [AppAuthGuard],
        data: {
          role: [ AccessRoles.ROLE_SUPER_ADMIN, AccessRoles.ROLE_ADMIN, AccessRoles.ROLE_OPERATOR, AccessRoles.ROLE_SERVICE_OPERATOR ]
        },
        resolve: {
          deviceV3: DeviceResolver,
          deviceInfoV3: DeviceInfoV3Resolver,
          deviceConfigV2: DeviceConfigV2Resolver,
          xenturionInfoV3: XenturionInfoV3Resolver }
      },
      {
        path: 'configurations',
        component: DeviceConfigurationsComponent,
        canActivate: [AppAuthGuard],
        data: {
          role: [ AccessRoles.ROLE_SUPER_ADMIN, AccessRoles.ROLE_ADMIN, AccessRoles.ROLE_OPERATOR, AccessRoles.ROLE_SERVICE_OPERATOR ]
        },
        resolve: { deviceConfigV2: DeviceConfigV2Resolver, lines: LinesResolver, directionTypes: DirectionTypesResolver }
      },
      {
        path: 'history',
        component: DeviceHistoryComponent,
        canActivate: [AppAuthGuard],
        data: {
          role: [ AccessRoles.ROLE_SUPER_ADMIN, AccessRoles.ROLE_ADMIN, AccessRoles.ROLE_OPERATOR, AccessRoles.ROLE_SERVICE_OPERATOR ]
        },
        resolve: { deviceConfigV2: DeviceConfigV2Resolver }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class DevicesRoutingModule {}
