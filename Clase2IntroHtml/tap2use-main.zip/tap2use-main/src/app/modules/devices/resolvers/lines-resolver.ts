import { Lines } from './../../../core/services/fare-collection-engine/models/lines';
import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { map } from 'rxjs/internal/operators';
import { FareCollectionEngineService } from '@app/core/services/fare-collection-engine/fareCollectionEngine.service';

@Injectable({
  providedIn: 'root'
})
export class LinesResolver implements Resolve<Lines> {

  constructor(private fareCollectionEngineService: FareCollectionEngineService) {}

  resolve(): any {
    return this.fareCollectionEngineService.getLines().pipe(map(data => data));
  }
}
