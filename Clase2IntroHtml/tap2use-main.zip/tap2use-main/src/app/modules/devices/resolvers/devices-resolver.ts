import { Injectable, OnInit } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve } from '@angular/router';
import { Page } from '@app/core/services/commons/page';
import { DeviceService } from '@app/core/services/device/device.service';
import { Device } from '@app/core/services/device/models/list/device';
import { FareCollectionEngineService } from '@app/core/services/fare-collection-engine/fareCollectionEngine.service';
import { map, switchMap } from 'rxjs/operators';

@Injectable()
export class DevicesResolver implements Resolve<Page<Device>>, OnInit {

    constructor(private deviceService: DeviceService, private fareCollectionEngineService: FareCollectionEngineService) {}

    ngOnInit() {}

    resolve(route: ActivatedRouteSnapshot): any {
        const filterEncode = route.queryParamMap.get('filter') || '';

        const filter = {};
        if (filterEncode) {
            filterEncode.split('|')
                .filter(s => s.match(/.*\~[0-1]\~.*/))
                .filter(s => {
                    const enabled = s.split('~')[1] === '1';
                    return enabled;
                })
            .forEach(s => {
                const key = s.split('~')[0];
                const value = s.split('~')[2];
                filter[key] = value;
            });
        }

        const pageNumber = +route.queryParamMap.get('pageNumber') || 0;
        const pageSize = +route.queryParamMap.get('pageSize') || 10;
        const sortOrder = route.queryParamMap.get('sortOrder') || 'DESC';
        const sortElement = route.queryParamMap.get('sortElement') || 'poi';

        return this.deviceService.getDevices(filter, sortOrder, sortElement, pageNumber, pageSize).pipe(
          // Add station name from references
          switchMap((devices: Page<Device>) => {
            const references = devices.content
              .filter(d => d.state && d.state.location && d.state.location.stationReference)
              .map(d => d.state.location.stationReference.toString());

            return this.fareCollectionEngineService.getStopsFromIds([...new Set(references)]).pipe(
              map(stations => {
                devices.content.forEach(device => {
                  if (device.state && device.state.location && device.state.location.stationReference) {
                    const station = stations.find(s => s.stopReference === device.state.location.stationReference);
                    if (station) {
                      device.state.location.stationReference = station.name;
                    }
                  }
                });
                return devices;
              })
            );
          }),
          // Add line name from references
          switchMap((devices: Page<Device>) => {
            const references = devices.content
              .filter(d => d.state && d.state.location && d.state.location.lineReference)
              .map(d => d.state.location.lineReference.toString());

            return this.fareCollectionEngineService.getLinesFromIds([...new Set(references)]).pipe(
              map(lines => {
                devices.content.forEach(device => {
                  if (device.state && device.state.location && device.state.location.lineReference) {
                    const line = lines.find(s => s.lineReference === device.state.location.lineReference);
                    if (line) {
                      device.state.location.lineReference = line.lineName;
                    }
                  }
                });
                return devices;
              })
            );
          })
        );
    }
}
