import { Lines } from '../../../core/services/fare-collection-engine/models/lines';
import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { map } from 'rxjs/internal/operators';
import { FareCollectionEngineService } from '@app/core/services/fare-collection-engine/fareCollectionEngine.service';
import { DirectionTypes } from '@app/core/services/fare-collection-engine/models/directionTypes';

@Injectable({
  providedIn: 'root'
})
export class DirectionTypesResolver implements Resolve<DirectionTypes> {

  constructor(private fareCollectionEngineService: FareCollectionEngineService) {}

  resolve(): any {
    return this.fareCollectionEngineService.getDirectionTypes().pipe(map(data => data));
  }
}
