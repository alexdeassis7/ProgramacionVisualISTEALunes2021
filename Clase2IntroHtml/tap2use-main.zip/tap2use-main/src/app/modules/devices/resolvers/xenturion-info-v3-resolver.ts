import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, Router } from '@angular/router';
import { DeviceService } from '@app/core/services/device/device.service';
import { XenturionInfoV3 } from '@app/core/services/device/models/xenturionInfoV3';
import { map } from 'rxjs/internal/operators';
import { environment } from '@env/environment';

@Injectable()
export class XenturionInfoV3Resolver implements Resolve<XenturionInfoV3> {
    activateXenturionInfos: boolean;

    constructor(private deviceService: DeviceService) {
      this.activateXenturionInfos = environment?.defaultValue?.device?.activateXenturionInfos;
    }

    resolve(route: ActivatedRouteSnapshot): any {
        if (this.activateXenturionInfos === true) {
            const poi = route.paramMap.get('poi') || route.parent.paramMap.get('poi');
            return this.deviceService.getXenturionInfoV3(poi).pipe(map( data => {
                if (data) {
                    return data;
                } else {
                    return '{error}';
                }
            }));
        } else {
            return null;
        }
    }
}
