import { Injectable, OnInit } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve } from '@angular/router';
import { DeviceService } from '@app/core/services/device/device.service';
import { Device } from '@app/core/services/device/models/list/device';
import { map } from 'rxjs/operators';

@Injectable()
export class DeviceResolver implements Resolve<Device>, OnInit {

  constructor(private deviceService: DeviceService) {}

  ngOnInit() {}

  resolve(route: ActivatedRouteSnapshot): any {
    const poi = route.paramMap.get('poi') || route.parent.paramMap.get('poi');
    return this.deviceService.getDevice(poi).pipe(map(data => data));
  }
}
