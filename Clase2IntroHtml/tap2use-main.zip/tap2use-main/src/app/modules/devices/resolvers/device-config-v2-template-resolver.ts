import { DeviceService } from '@app/core/services/device/device.service';
import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { map } from 'rxjs/internal/operators';

@Injectable({
  providedIn: 'root'
})
export class DeviceConfigV2TemplateResolver implements Resolve<any> {

  constructor(private deviceService: DeviceService) {}

  resolve(): any {
    return this.deviceService.getAllDeviceConfigV2Templates().pipe(map(data => data));
  }
}
