import { DeviceService } from '@app/core/services/device/device.service';
import { DeviceConfigurationV2 } from './../../../core/services/device/models/deviceConfigurationV2';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, Router } from '@angular/router';
import { map } from 'rxjs/internal/operators';

@Injectable({
  providedIn: 'root'
})
export class DeviceConfigV2Resolver implements Resolve<DeviceConfigurationV2> {

  constructor(private router: Router, private deviceService: DeviceService) {}

  resolve(route: ActivatedRouteSnapshot): any {
    const poi = route.paramMap.get('poi') || route.parent.paramMap.get('poi');
    return this.deviceService.getDeviceConfigV2(poi).pipe(map(data => data));
  }
}
