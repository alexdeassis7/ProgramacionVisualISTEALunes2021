import { DeviceService } from '@app/core/services/device/device.service';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, Router } from '@angular/router';
import { DeviceInfoV3 } from '@app/core/services/device/models/deviceInfoV3';
import { map } from 'rxjs/internal/operators';

@Injectable({
  providedIn: 'root'
})
export class DeviceInfoV3Resolver implements Resolve<DeviceInfoV3> {

  constructor(private router: Router, private deviceService: DeviceService) {}

  resolve(route: ActivatedRouteSnapshot): any {
    const poi = route.paramMap.get('poi') || route.parent.paramMap.get('poi');
    return this.deviceService.getDeviceInfoV3(poi).pipe(map(data => data));
  }
}
