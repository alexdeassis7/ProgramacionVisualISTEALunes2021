import { Component } from '@angular/core';
import { BlockUnblockTerminalInfo } from '@app/core/services/device/models/blocking/blockUnblockTerminalInfo';
import { SimpleModalComponent } from 'ngx-simple-modal';

export interface BlockingModel {
  numberOfDevices: number;
}

@Component({
  selector: 'ap-blocking-modal',
  templateUrl: './blocking-modal.component.html',
  styleUrls: ['./blocking-modal.component.css']
})

export class BlockingModalComponent extends SimpleModalComponent<BlockingModel,
                                            BlockUnblockTerminalInfo.TypeEnum> implements BlockingModel {
  numberOfDevices: number;

  accessModeSelected = BlockUnblockTerminalInfo.TypeEnum.BLOCKCLOSE;
  accessMode = {
    blockedOpen: BlockUnblockTerminalInfo.TypeEnum.BLOCKOPEN,
    blockedClosed: BlockUnblockTerminalInfo.TypeEnum.BLOCKCLOSE   // by default
  };

  constructor() { super(); }

  confirm() {
    // we set modal result as access mode selected on clicking on confirm button, then we can get modal result from caller code
    this.result = this.accessModeSelected;
    this.close();
  }

  cancel() {
    this.result = null;
    this.close();
  }
}
