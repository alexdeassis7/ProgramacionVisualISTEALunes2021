import { Pipe, PipeTransform } from '@angular/core';
import { BlockUnblockTerminalInfo } from '@app/core/services/device/models/blocking/blockUnblockTerminalInfo';
import { Origin } from '@app/core/services/device/models/blocking/origin';
import { Device } from '@app/core/services/device/models/list/device';
import { LocalDatePipe } from '@app/shared/local-date/local-date.pipe';
import { TranslateService } from '@ngx-translate/core';

@Pipe({name: 'lockingTooltip'})

export class LockingTooltipPipe implements PipeTransform {
  blockingTooltip = {
    fromAdmin: this.translateService.instant('DEVICE.LABELS.LIST.BLOCKED_ORIGIN_ADMIN_CELL_TOOLTIP'),
    fromControl: this.translateService.instant('DEVICE.LABELS.LIST.BLOCKED_ORIGIN_CONTROL_CELL_TOOLTIP'),
    fromSaeOnboard: this.translateService.instant('DEVICE.LABELS.LIST.BLOCKED_ORIGIN_SAE_ONBOARD_CELL_TOOLTIP')
  };
  blockingType = {
    open: this.translateService.instant('DEVICE.LABELS.LIST.BLOCKED_OPEN_CELL_TOOLTIP'),
    close: this.translateService.instant('DEVICE.LABELS.LIST.BLOCKED_CLOSE_CELL_TOOLTIP')
  };

  constructor(private translateService: TranslateService) { }

  transform(device: Device): string {
    if (device && device.state && device.state.block && device.state.block.blocked ) {
      const generateMsg = (msg: string[], origin: Origin) => {
            const blockingType = origin.type === BlockUnblockTerminalInfo.TypeEnum.BLOCKOPEN ?
                                                      this.blockingType.open : this.blockingType.close;
            const blockingDate = new LocalDatePipe(this.translateService).transform(origin.date);
            switch (origin.origin) {
              case BlockUnblockTerminalInfo.OriginEnum.ADMIN:
                msg.push(this.blockingTooltip.fromAdmin + ' [' + blockingDate + '] ' + blockingType);
                break;
              case BlockUnblockTerminalInfo.OriginEnum.CONTROL:
                msg.push(this.blockingTooltip.fromControl + ' [' + blockingDate + '] ' + blockingType);
                break;
              case BlockUnblockTerminalInfo.OriginEnum.CENTRALSAE:
                msg.push(this.blockingTooltip.fromSaeOnboard + ' [' + blockingDate + '] ' + blockingType);
                break;
              default:
                break;
              }
            return msg;
          };

      return device.state.block.origins
        .filter(o => o.type !== BlockUnblockTerminalInfo.TypeEnum.UNBLOCK)
        .reduce(generateMsg, [])
        .join('<br/>');

    } else {
      return null;
    }
  }
}
