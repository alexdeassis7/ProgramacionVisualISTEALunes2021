import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnblockingModalComponent } from './unblocking-modal.component';

describe('UnblockingModalComponent', () => {
  let component: UnblockingModalComponent;
  let fixture: ComponentFixture<UnblockingModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnblockingModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnblockingModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
