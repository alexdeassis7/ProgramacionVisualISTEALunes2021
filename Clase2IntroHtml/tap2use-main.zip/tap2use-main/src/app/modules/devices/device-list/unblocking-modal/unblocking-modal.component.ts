import { Component } from '@angular/core';
import { SimpleModalComponent } from 'ngx-simple-modal';

export interface UnblockingModel {
  numberOfDevices: number;
}

@Component({
  selector: 'ap-unblocking-modal',
  templateUrl: './unblocking-modal.component.html',
  styleUrls: ['./unblocking-modal.component.css']
})

export class UnblockingModalComponent extends SimpleModalComponent<UnblockingModel, boolean> implements UnblockingModel {
    numberOfDevices: number;

    constructor() { super(); }

    confirm() {
      // we set modal result as true on clicking on confirm button, then we can get modal result from caller code
      this.result = true;
      this.close();
    }

    cancel() {
      this.result = false;
      this.close();
    }
}
