
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { AccessRoles } from '@app/core/services/administrator/models/accessRoles';
import { Page } from '@app/core/services/commons/page';
import { DeviceService } from '@app/core/services/device/device.service';
import { BlockUnblockTerminalInfo } from '@app/core/services/device/models/blocking/blockUnblockTerminalInfo';
import { Device } from '@app/core/services/device/models/list/device';
import { HealthIndicator } from '@app/core/services/device/models/list/healthIndicator';
import { FareCollectionEngineService } from '@app/core/services/fare-collection-engine/fareCollectionEngine.service';
import { ConfirmComponent } from '@app/shared/components/confirm/confirm.component';
import { AutocompleteFilterTemplate } from '@app/shared/components/filter/filter-template/autocomplete-filter-template/autocomplete-filter-template.model';
import { DateFilterTemplate } from '@app/shared/components/filter/filter-template/date-filter-template/date-filter-template.model';
import { SelectionFilterTemplate } from '@app/shared/components/filter/filter-template/selection-filter-template/selection-filter-template.model';
import { TextFilterTemplate } from '@app/shared/components/filter/filter-template/text-filter-template/text-filter-template.model';
import { FilterData } from '@app/shared/components/filter/filterData';
import { Sort } from '@app/shared/components/table/sort/sort.model';
import { environment } from '@env/environment';
import { TranslateService } from '@ngx-translate/core';
import { SimpleModalService } from 'ngx-simple-modal';
import { ToastrService } from 'ngx-toastr';
import { Observable } from 'rxjs';
import { map, pluck, takeUntil, tap } from 'rxjs/operators';
import { BlockingModalComponent } from './blocking-modal/blocking-modal.component';
import { UnblockingModalComponent } from './unblocking-modal/unblocking-modal.component';

@Component({
  selector: 'ap-device-list',
  templateUrl: './device-list.component.html',
  styleUrls: ['./device-list.component.css']
})

export class DeviceListComponent extends AbstractOnDestroyComponent implements OnInit {
  error = false;
  loading = false;
  blockingActivated = false;
  accessRoles = AccessRoles;
  blockingInProgress = false;
  unlocked = BlockUnblockTerminalInfo.TypeEnum.UNBLOCK;

  devices$: Observable<Page<Device>>;
  filterData: FilterData;

  page: number = 0;
  elements: number = 0;

  sort: Sort;
  selected: Set<string>;

  displayedColumns: string[];

  constructor(private translateService: TranslateService,
                private router: Router, private route: ActivatedRoute,
                private deviceService: DeviceService,
                private simpleModalService: SimpleModalService,
                private toastr: ToastrService,
                private fareCollectionEngineService: FareCollectionEngineService) {
    super();

    this.displayedColumns = environment.defaultValue.device.informations;

    // Function to search some stations from str (user search)
    const searchStations = (search: string) => this.fareCollectionEngineService.searchStops(search).pipe(
      map(stops => stops.reduce((map, stop) => map.set(stop.stopReference, stop.name), new Map<string, string>()))
    );

    // Function to search some lines from str (user search)
    const searchLines = (search: string) => this.fareCollectionEngineService.searchLines(search).pipe(
      map(lines => lines.reduce((map, line) => map.set(line.lineReference, line.lineName), new Map<string, string>()))
    );

    /* Define possible filter */
    const templates = [
      new TextFilterTemplate('poi', 'DEVICE.LIST.FILTER.POI', 'DEFAULT', 'CONTAINS'),
      new TextFilterTemplate('companyReference', 'DEVICE.LIST.FILTER.CONFIGURATION.VALIDATOR.COMPANY_REFERENCE', 'DEFAULT', 'CONTAINS'),
      new TextFilterTemplate('serialNumber', 'DEVICE.LIST.FILTER.SERIAL_NUMBER', 'DEFAULT', 'CONTAINS'),
      new TextFilterTemplate('deviceReference', 'DEVICE.LIST.FILTER.DEVICE_REFERENCE', 'DEFAULT', 'CONTAINS'),

      new SelectionFilterTemplate('fonction', 'DEVICE.LIST.FILTER.FUNCTION', [
        { label: 'Validation', value: 'Validation' },
        { label: 'Contrôle', value: 'Contrôle' },
      ]),
      new SelectionFilterTemplate('deviceModel', 'DEVICE.LIST.FILTER.MODEL', environment.defaultValue.device.deviceModel.map(model => { return { label: model, value: model }})),
      new SelectionFilterTemplate('installationType', 'DEVICE.LIST.FILTER.TYPE', environment.defaultValue.device.installationType.map(type => { return { label: type, value: type }})),
      new TextFilterTemplate('simReference', 'DEVICE.LIST.FILTER.SIM', 'DEFAULT', 'CONTAINS'),
      new SelectionFilterTemplate('transportMode', 'DEVICE.LIST.FILTER.TRANSPORT', environment.defaultValue.device.transportMode.map(mode => { return { label: mode, value: mode }})),

      new SelectionFilterTemplate('activity', 'DEVICE.LIST.FILTER.ACTIVITY.STATUS', [
        { label: 'OK', value: 'OK' },
        { label: 'KO', value: 'KO' },
        { label: 'NA', value: 'NA' },
      ], 'DEVICE.LIST.FILTER.ACTIVITY.GROUP'),
      new SelectionFilterTemplate('configuration', 'DEVICE.LIST.FILTER.CONFIGURATION.STATUS', [
        { label: 'OK', value: 'OK' },
        { label: 'KO', value: 'KO' },
        { label: 'NA', value: 'NA' },
      ], 'DEVICE.LIST.FILTER.CONFIGURATION.GROUP'),
      new SelectionFilterTemplate('system', 'DEVICE.LIST.FILTER.SYSTEM', [
        { label: 'OK', value: 'OK' },
        { label: 'KO', value: 'KO' },
        { label: 'NA', value: 'NA' },
      ]),

      new SelectionFilterTemplate('hardware', 'DEVICE.LIST.FILTER.HARDWARE', [
        { label: 'OK', value: 'OK' },
        { label: 'KO', value: 'KO' },
        { label: 'NA', value: 'NA' },
      ]),

      new DateFilterTemplate('dateLastConnexion', 'DEVICE.LIST.FILTER.ACTIVITY.LAST_CONNECTION', 'DEVICE.LIST.FILTER.ACTIVITY.GROUP'),
      new DateFilterTemplate('sinceLastConnexion', 'DEVICE.LIST.FILTER.ACTIVITY.SINCE_LAST_CONNECTION', 'DEVICE.LIST.FILTER.ACTIVITY.GROUP'),
      new DateFilterTemplate('untilLastConnexion', 'DEVICE.LIST.FILTER.ACTIVITY.UNTIL_LAST_CONNECTION', 'DEVICE.LIST.FILTER.ACTIVITY.GROUP'),

      new DateFilterTemplate('dateLastTap', 'DEVICE.LIST.FILTER.ACTIVITY.LAST_TAP', 'DEVICE.LIST.FILTER.ACTIVITY.GROUP'),
      new DateFilterTemplate('sinceLastTap', 'DEVICE.LIST.FILTER.ACTIVITY.SINCE_LAST_TAP', 'DEVICE.LIST.FILTER.ACTIVITY.GROUP'),
      new DateFilterTemplate('untilLastTap', 'DEVICE.LIST.FILTER.ACTIVITY.UNTIL_LAST_TAP', 'DEVICE.LIST.FILTER.ACTIVITY.GROUP'),

      new DateFilterTemplate('dateConfigurationVersion', 'DEVICE.LIST.FILTER.CONFIGURATION.VERSION', 'DEVICE.LIST.FILTER.CONFIGURATION.GROUP'),
      new DateFilterTemplate('sinceConfigurationVersion', 'DEVICE.LIST.FILTER.CONFIGURATION.SINCE_VERSION', 'DEVICE.LIST.FILTER.CONFIGURATION.GROUP'),
      new DateFilterTemplate('untilConfigurationVersion', 'DEVICE.LIST.FILTER.CONFIGURATION.UNTIL_VERSION', 'DEVICE.LIST.FILTER.CONFIGURATION.GROUP'),

      new SelectionFilterTemplate('blockingStatus', 'DEVICE.LIST.FILTER.BLOCKING.TYPE',
        environment.defaultValue.device.blockingStatus.map(status => ({label: status.displayValue, value: status.value})),
          'DEVICE.LIST.FILTER.BLOCKING.GROUP'),

      new SelectionFilterTemplate('blockingOrigin', 'DEVICE.LIST.FILTER.BLOCKING.ORIGIN',
        environment.defaultValue.device.blockingOrigin.map(origin => ({label: origin.displayValue, value: origin.value})),
          'DEVICE.LIST.FILTER.BLOCKING.GROUP'),

      new TextFilterTemplate('version', 'DEVICE.LIST.FILTER.VERSION', 'DEFAULT', 'CONTAINS'),
      new AutocompleteFilterTemplate('stationReference', 'DEVICE.LIST.FILTER.LOCALISATION.STATION', searchStations, 'DEVICE.LIST.FILTER.LOCALISATION.GROUP', 3),
      new AutocompleteFilterTemplate('lineReference', 'DEVICE.LIST.FILTER.LOCALISATION.LINE', searchLines, 'DEVICE.LIST.FILTER.LOCALISATION.GROUP', 0),
      new TextFilterTemplate('placeReference', 'DEVICE.LIST.FILTER.LOCALISATION.PLACE', 'DEVICE.LIST.FILTER.LOCALISATION.GROUP', 'CONTAINS')
    ];

    this.filterData = new FilterData('devices', templates);
  }

  ngOnInit() {
    this.blockingActivated = environment.defaultValue.device.blockingActivated;

    // If encoded URL filter change after reload (navigate to same page with a diffrent filter), same thing with filter
    this.route.queryParamMap.subscribe(params => {
      // filter decode
      this.filterData.decode(params.get('filter') || '');
      // sort decode
      if (params.has('sortElement') && params.has('sortOrder')) {
        this.sort = new Sort(params.get('sortElement'), <'ASC' | 'DESC'> params.get('sortOrder'));
      } else {
        this.sort = new Sort('poi', 'DESC');
      }
    });

    this.selected = new Set();

    /* Get data from resolver */
    this.devices$ = this.route.data.pipe(
        pluck('pageDevice'),
        tap((_page: Page<Device>) => {
          this.loading = false;
          this.selected = new Set();
        })
      );

    /* If filterData change then reload the page (get data with resolver) */
    this.filterData.onChange$.subscribe(_e => {
      this.page = 0;
      this.reloadPageDevice();
    });
  }

  selectAllRows(checkAll: boolean) {
    if (checkAll) {
      this.deviceService.getDevices(null, null, null, null, null)
        .pipe(tap(() => { this.loading = false; }))
        .pipe(takeUntil(this.unsubscribe))
        .subscribe(data => {
          if (data) {
            data.content.forEach(device => {
              this.selected.add(device.poi);
            });
          } else {
            this.toastr.error(this.translateService.instant('TOAST.ERROR.FAILED'));
          }
        });
    } else {
      this.selected.clear();
    }

  }

  getHealthIndicatorClass(healthIndicators: Array<HealthIndicator>, name: string): string[] {
    const classes = ['fa'];
    if (!healthIndicators) { return ['']; }
    const healthIndicatorValue = (healthIndicators.find(h => h.name === name) || {}).value;
    switch (healthIndicatorValue) {
      case HealthIndicator.ValueEnum.OK:
        classes.push('fa-check', 'text-success');
        break;
      case HealthIndicator.ValueEnum.NA:
        classes.push('fa-exclamation', 'text-warning');
        break;
      case HealthIndicator.ValueEnum.KO:
        classes.push('fa-remove', 'text-danger');
        break;
      default:
        break;
    }
    return classes;
  }

  /**
   * Navigate to the page that create a new device
   */
  addDevice() {
    this.router.navigate(['devices', 'add']);
  }

  /**
   * Navigate to the page that configure a device by default
   */
  configureDefaultDevice() {
    this.router.navigate(['devices', 'default-configuration']);
  }

  /**
   * Popup modal for confirming the blocking of devices
   */
  confirmBlockingDevices() {
    const checkedDevicesId = Array.from(this.selected.values());
    const options = { numberOfDevices: checkedDevicesId.length };
    const modal = this.simpleModalService.addModal(BlockingModalComponent, options).subscribe(selectedStatus => {
      if (selectedStatus) {
        this.blockingInProgress = true;
        this.blockUnblockDevices(selectedStatus, BlockUnblockTerminalInfo.OriginEnum.ADMIN, checkedDevicesId);
      }
      // Automatically close modal after 30 seconds
      setTimeout(() => modal.unsubscribe(), 30 * 1000);
    });
  }

  /**
   * Popup modal for confirming the unblocking of devices
   */
  confirmUnblockingDevices() {
    const checkedDeviceIds = Array.from(this.selected.values());
    const options = { numberOfDevices: checkedDeviceIds.length };
    const modal = this.simpleModalService.addModal(UnblockingModalComponent, options).subscribe(isConfirmed => {
      if (isConfirmed) {
        this.blockUnblockDevices(BlockUnblockTerminalInfo.TypeEnum.UNBLOCK, BlockUnblockTerminalInfo.OriginEnum.ADMIN, checkedDeviceIds);
      }
      // Automatically close modal after 30 seconds
      setTimeout( () => modal.unsubscribe(), 30 * 1000);
    });
  }

  /**
   * Navigate to the page that manage the device
   * @param poi : device's poi
   */
  manageDevice(poi: string) {
    this.router.navigate(['devices', poi], { state: { redirectParams: {
      filter: this.filterData.encode(),
      pageNumber: this.page,
      pageSize: this.elements,
      sortElement: this.sort && this.sort.field,
      sortOrder: this.sort && this.sort.order,
      refresh: (new Date()).getTime()
    } } });
  }

  /**
   * Popup modal for confirming the deletion of the device
   * @param poi : device's poi
   */
  confirmDeleteDevice(poi: string) {
    const labelOptions = {
      message: this.translateService.instant('DEVICE.LABELS.LIST.DELETE_MESSAGE'),
      confirmButton: 'ACTIONS.DELETE',
      closeButton: 'ACTIONS.CANCEL'
    };

    const modal = this.simpleModalService.addModal(ConfirmComponent, labelOptions).subscribe(isConfirmed => {
      if (isConfirmed) {
        this.deleteDevice(poi);
      }
    });

    // Automatically close modal after 30 seconds
    setTimeout( () => modal.unsubscribe(), 30 * 1000);
  }

  filterBySort(sort: Sort) {
    this.sort = sort;
    this.page = 0;
    this.reloadPageDevice();
  }

  filterByPagination(page: number) {
    this.page = page;
    this.reloadPageDevice();
  }

  filterByPaginationSize(size: number) {
    this.elements = size;
    this.page = 0;
    this.reloadPageDevice();
  }

  goToBulkConfiguration() {
    const devicesId = Array.from(this.selected.values());
    this.router.navigateByUrl('/devices/bulk-configuration', { state: { devicesId } });
  }

  /**
   * Delete the device
   * @param poi : device's poi
  */
  private deleteDevice(poi: string) {
    this.deviceService.deleteDevice(poi).pipe( takeUntil(this.unsubscribe) ).subscribe(
      // refresh page
      _res => {
        this.reloadPageDevice();
        this.toastr.success(this.translateService.instant('TOAST.SUCCESS.DELETE'));
      },
    );
  }

  /**
   * Block or unblock one or more devices
   */
  private blockUnblockDevices(status: BlockUnblockTerminalInfo.TypeEnum, origin: BlockUnblockTerminalInfo.OriginEnum, pois: Array<string>) {
    const blockUnblockTerminalInfo = {
          date: new Date(),
          pois: pois,
          origin: origin, type: status,
          lineReference: null, stationReference: null, vehicleReference: null
        };

    this.deviceService.blockUnblockDevices(blockUnblockTerminalInfo).pipe( takeUntil(this.unsubscribe) ).subscribe(
      // refresh page
      _res => {
        this.blockingInProgress = false;
        this.reloadPageDevice();
        this.toastr.success(this.translateService.instant('TOAST.SUCCESS.MODIFICATION'));
      },
    );
  }

  /**
   * Call devices-resolver when pagination and filters change for retriving device data
   */
  private reloadPageDevice(): void {
    this.router.navigate(['devices'], {
      queryParams: {
        filter: this.filterData.encode(),
        pageNumber: this.page,
        pageSize: this.elements,
        sortElement: this.sort && this.sort.field,
        sortOrder: this.sort && this.sort.order,
        refresh: (new Date()).getTime()
      }
    });
  }

}
