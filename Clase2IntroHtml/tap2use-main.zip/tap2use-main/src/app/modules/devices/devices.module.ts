import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '@app/shared/shared.module';

import { DevicesRoutingModule } from './devices-routing.module';
import { DeviceDetailsComponent } from './device-details/device-details.component';
import { DeviceInformationsComponent } from './device-details/device-informations/device-informations.component';
import { ConfigurationComponent } from './device-details/device-informations/configuration/configuration.component';
import { ListsInformationsComponent } from './device-details/device-informations/lists-informations/lists-informations.component';
import { SystemInfoComponent } from './device-details/device-informations/system-info/system-info.component';
import { LocationInfoComponent } from './device-details/device-informations/location-info/location-info.component';
import { DeviceConfigurationsComponent } from './device-details/device-configurations/device-configurations.component';
import { DeviceHistoryComponent } from './device-details/device-history/device-history.component';
import { HardwareInfoComponent } from './device-details/device-informations/hardware-info/hardware-info.component';
import { FurtherInfoComponent } from './device-details/device-informations/further-info/further-info.component';
import { DeviceInfoV3Resolver } from './resolvers/device-info-v3-resolver';
import { XenturionComponent } from './device-details/device-informations/xenturion/xenturion.component';
import { XenturionInfoV3Resolver } from './resolvers/xenturion-info-v3-resolver';
import { BaseConfigurationPanelComponent } from './base-configuration-panel/base-configuration-panel.component';
import { ConnectivityConfigurationPanelComponent } from './base-configuration-panel/connectivity-configuration-panel/connectivity-configuration-panel.component';
import { ApplicationsConfigurationPanelComponent } from './base-configuration-panel/applications-configuration-panel/applications-configuration-panel.component';
import { DevicesResolver } from './resolvers/devices-resolver';
import { DeviceResolver } from './resolvers/device-resolver';
import { DeviceListComponent } from './device-list/device-list.component';
import { DeviceDefaultConfigurationComponent } from './device-default-configuration/device-default-configuration.component';
import { LocalisationConfigurationPanelComponent } from './base-configuration-panel/localisation-configuration-panel/localisation-configuration-panel.component';
import { LogConfigurationPanelComponent } from './base-configuration-panel/log-configuration-panel/log-configuration-panel.component';
import { ParametersConfigurationPanelComponent } from './base-configuration-panel/parameters-configuration-panel/parameters-configuration-panel.component';
import { TerminalConfigurationPanelComponent } from './base-configuration-panel/terminal-configuration-panel/terminal-configuration-panel.component';
import { DeviceCreationComponent } from './device-creation/device-creation.component';
import { BlockingModalComponent } from './device-list/blocking-modal/blocking-modal.component';
import { UnblockingModalComponent } from './device-list/unblocking-modal/unblocking-modal.component';
import { BulkConfigurationComponent } from './bulk-configuration/bulk-configuration.component';
import { LockingTooltipPipe } from './device-list/pipes/lockingTooltip.pipe';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    DevicesRoutingModule
  ],
  declarations: [
    DeviceDetailsComponent,
    DeviceInformationsComponent,
    ConfigurationComponent,
    ListsInformationsComponent,
    SystemInfoComponent,
    LocationInfoComponent,
    HardwareInfoComponent,
    FurtherInfoComponent,
    DeviceConfigurationsComponent,
    DeviceHistoryComponent,
    XenturionComponent,
    LogConfigurationPanelComponent,
    TerminalConfigurationPanelComponent,
    BaseConfigurationPanelComponent,
    ConnectivityConfigurationPanelComponent,
    LocalisationConfigurationPanelComponent,
    ParametersConfigurationPanelComponent,
    ApplicationsConfigurationPanelComponent,
    DeviceListComponent,
    DeviceCreationComponent,
    DeviceDefaultConfigurationComponent,
    BulkConfigurationComponent,
    DeviceDefaultConfigurationComponent,
    BlockingModalComponent,
    UnblockingModalComponent,
    LockingTooltipPipe
  ],
  providers: [
    DeviceInfoV3Resolver,
    XenturionInfoV3Resolver,
    DevicesResolver,
    DeviceResolver
  ],
  exports : [
  ]
})
export class DevicesModule {}
