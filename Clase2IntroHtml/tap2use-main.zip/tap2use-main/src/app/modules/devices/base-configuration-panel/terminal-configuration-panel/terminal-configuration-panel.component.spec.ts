import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TerminalConfigurationPanelComponent } from './terminal-configuration-panel.component';

describe('TerminalConfigurationPanelComponent', () => {
  let component: TerminalConfigurationPanelComponent;
  let fixture: ComponentFixture<TerminalConfigurationPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TerminalConfigurationPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TerminalConfigurationPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
