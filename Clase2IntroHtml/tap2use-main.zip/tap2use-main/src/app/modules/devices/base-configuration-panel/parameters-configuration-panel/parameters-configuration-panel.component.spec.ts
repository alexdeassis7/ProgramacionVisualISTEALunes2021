import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParametersConfigurationPanelComponent } from './parameters-configuration-panel.component';

describe('ParametersConfigurationPanelComponent', () => {
  let component: ParametersConfigurationPanelComponent;
  let fixture: ComponentFixture<ParametersConfigurationPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParametersConfigurationPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParametersConfigurationPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
