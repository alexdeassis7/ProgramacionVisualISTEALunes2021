import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplicationsConfigurationPanelComponent } from './applications-configuration-panel.component';

describe('ApplicationsConfigurationPanelComponent', () => {
  let component: ApplicationsConfigurationPanelComponent;
  let fixture: ComponentFixture<ApplicationsConfigurationPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplicationsConfigurationPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplicationsConfigurationPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
