import { BaseConfigurationPanelComponent } from '../base-configuration-panel.component';
import { Terminal } from '@app/core/services/device/models/models';
import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'ap-terminal-configuration-panel',
  templateUrl: './terminal-configuration-panel.component.html',
  styleUrls: ['./../base-configuration-panel.component.css', './terminal-configuration-panel.component.css']
})
export class TerminalConfigurationPanelComponent extends BaseConfigurationPanelComponent implements OnInit {

  @Input() terminal: Terminal;

  constructor() {
    super();
  }

  ngOnInit() {}
}
