import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { BaseConfigurationPanelComponent } from '../base-configuration-panel.component';
import { Parameter } from '@app/core/services/device/models/models';


@Component({
  selector: 'ap-parameters-configuration-panel',
  templateUrl: './parameters-configuration-panel.component.html',
  styleUrls: ['../base-configuration-panel.component.css', './parameters-configuration-panel.component.css']
})
export class ParametersConfigurationPanelComponent extends BaseConfigurationPanelComponent implements OnInit {

  @Output() modifyParameters = new EventEmitter();

  _deviceModel: Parameter;
  _installationType: Parameter;
  newParameter: Parameter = {};

  get installationType(): Parameter {
    this._installationType = this.getOrInitializeSpecificParameter(this.listParameter, 'installationType');
    return this._installationType;
  }

  set installationType(installationType: Parameter) {
    this._installationType = installationType;
  }

  get deviceModel(): Parameter {
    this._deviceModel = this.getOrInitializeSpecificParameter(this.listParameter, 'deviceModel');
    return this._deviceModel;
  }

  set deviceModel(deviceModel: Parameter) {
    this._deviceModel = deviceModel;
  }

  constructor() {
    super();
  }

  ngOnInit() {}

  addParameter(): void {
    this.modifyParameters.emit({name: 'add-parameter', message: this.newParameter});
    this.editedMap.set('add-parameter', true);
    this.newParameter = {};
  }

  removeParameter(parameter): void {
    this.modifyParameters.emit({name: 'remove-parameter', message: parameter});
    this.editedMap.set('remove-parameter', true);
  }
}
