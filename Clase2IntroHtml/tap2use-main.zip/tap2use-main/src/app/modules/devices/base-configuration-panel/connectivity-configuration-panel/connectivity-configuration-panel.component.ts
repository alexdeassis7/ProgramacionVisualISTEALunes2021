import { Connectivity } from '@app/core/services/device/models/models';
import { BaseConfigurationPanelComponent } from '../base-configuration-panel.component';
import { Component, OnInit, Input } from '@angular/core';


@Component({
  selector: 'ap-connectivity-configuration-panel',
  templateUrl: './connectivity-configuration-panel.component.html',
  styleUrls: ['../base-configuration-panel.component.css', './connectivity-configuration-panel.component.css']
})
export class ConnectivityConfigurationPanelComponent extends BaseConfigurationPanelComponent implements OnInit {

  @Input() connectivity: Connectivity;

  constructor() {
    super();
   }

  ngOnInit() {
  }

}
