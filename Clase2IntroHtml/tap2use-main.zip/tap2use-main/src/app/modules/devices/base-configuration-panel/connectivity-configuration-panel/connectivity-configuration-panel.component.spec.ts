import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConnectivityConfigurationPanelComponent } from './connectivity-configuration-panel.component';

describe('ConnectivityConfigurationPanelComponent', () => {
  let component: ConnectivityConfigurationPanelComponent;
  let fixture: ComponentFixture<ConnectivityConfigurationPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConnectivityConfigurationPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConnectivityConfigurationPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
