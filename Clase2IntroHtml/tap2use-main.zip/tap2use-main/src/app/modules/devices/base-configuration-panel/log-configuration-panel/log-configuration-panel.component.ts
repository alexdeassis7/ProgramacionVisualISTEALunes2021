import { BaseConfigurationPanelComponent } from '../base-configuration-panel.component';
import { Log } from '@app/core/services/device/models/log';
import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'ap-log-configuration-panel',
  templateUrl: './log-configuration-panel.component.html',
  styleUrls: ['./../base-configuration-panel.component.css', './log-configuration-panel.component.css']
})
export class LogConfigurationPanelComponent extends BaseConfigurationPanelComponent implements OnInit {

  @Input() log: Log;

  constructor() {
    super();
  }

  ngOnInit() {}
}
