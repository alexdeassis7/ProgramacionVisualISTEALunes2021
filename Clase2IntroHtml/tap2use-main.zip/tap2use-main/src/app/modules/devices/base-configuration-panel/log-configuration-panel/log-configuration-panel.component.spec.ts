import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LogConfigurationPanelComponent } from './log-configuration-panel.component';

describe('LogConfigurationPanelComponent', () => {
  let component: LogConfigurationPanelComponent;
  let fixture: ComponentFixture<LogConfigurationPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LogConfigurationPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LogConfigurationPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
