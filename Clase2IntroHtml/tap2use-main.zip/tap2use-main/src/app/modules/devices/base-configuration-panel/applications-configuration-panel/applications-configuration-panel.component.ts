import { BaseConfigurationPanelComponent } from '../base-configuration-panel.component';
import { Component, Input, OnInit } from '@angular/core';
import { Application } from '@app/core/services/device/models/models';

@Component({
  selector: 'ap-applications-configuration-panel',
  templateUrl: './applications-configuration-panel.component.html',
  styleUrls: ['../base-configuration-panel.component.css', './applications-configuration-panel.component.css']
})
export class ApplicationsConfigurationPanelComponent extends BaseConfigurationPanelComponent implements OnInit {

  @Input() listApplication: Array<Application>;

  applications: Array<any>;

  constructor() {
    super();
  }

  ngOnInit() {
    this.applications = this.listApplication.map(() => ({ paramName: '', paramValue: '' }));
  }

  addApplication(): void {
    this.listApplication.push({
      applicationName: '',
      applicationUrl: '',
      applicationHost: '',
      parameters: []
    });
    this.applications.push({ paramName: '', paramValue: '' });
    this.changeEvent.emit('add-application');
  }

  removeApplication(index): void {
    if (index > -1) {
      this.listApplication.splice(index, 1);
      this.applications.splice(index, 1);
      this.changeEvent.emit('remove-application');
    }
  }

  addApplicationParameter(application, index): void {
    application.parameters.push(this.applications[index]);
    this.applications[index] = { paramName: '', paramValue: ''};
    this.changeEvent.emit('add-application-parameter');
  }

  removeApplicationParameter(application, index): void {
    if (index > -1) {
      application.parameters.splice(index, 1);
      this.changeEvent.emit('remove-application-parameter');
    }
  }
}
