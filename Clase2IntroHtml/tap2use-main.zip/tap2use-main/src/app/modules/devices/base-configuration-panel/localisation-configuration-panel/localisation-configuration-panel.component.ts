import { Validator } from '@app/core/services/device/models/models';
import { BaseConfigurationPanelComponent } from '../base-configuration-panel.component';
import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Lines } from '@app/core/services/fare-collection-engine/models/lines';
import { Stops } from '@app/core/services/fare-collection-engine/models/stops';
import { FareCollectionEngineService } from '@app/core/services/fare-collection-engine/fareCollectionEngine.service';
import { DirectionTypes } from '@app/core/services/fare-collection-engine/models/directionTypes';
import { environment } from '@env/environment';

@Component({
  selector: 'ap-localisation-configuration-panel',
  templateUrl: './localisation-configuration-panel.component.html',
  styleUrls: ['../base-configuration-panel.component.css', './localisation-configuration-panel.component.css']
})
export class LocalisationConfigurationPanelComponent extends BaseConfigurationPanelComponent implements OnInit {

  @Input() validator: Validator;

  lines: Lines;
  stops: Stops;
  directionTypes: DirectionTypes;
  companyReferenceValues: string[];

  constructor(private route: ActivatedRoute, private fceService: FareCollectionEngineService) {
    super();
  }

  ngOnInit() {
    this.lines = this.route.snapshot.data.lines || { data: [] };
    this.directionTypes = this.route.snapshot.data.directionTypes || [];
    this.companyReferenceValues = environment?.defaultValue?.device?.companyReference ?? [];
    this.stops = { data: [] };
    if (this.validator.lineId) {
      this.fetchStations();
    }
  }

  updateElement(elementId) {
    if (elementId === 'validator-line-id') {
      this.fetchStations();
    }
    this.changeEvent.emit(elementId);
  }

  private fetchStations(): void {
    this.stops = { data: [] };
    this.fceService.getStopsByLineReference(this.validator.lineId).subscribe(data => {
      if (data) {
        this.stops = data;
      }
    });
  }
}
