import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { environment } from '@env/environment';
import { AccessRoles } from '@app/core/services/administrator/models/accessRoles';
import { Parameter } from '@app/core/services/device/models/models';


@Component({
  selector: 'app-base-configuration-panel',
  template: '',
  styleUrls: ['./base-configuration-panel.component.css']
})
export class BaseConfigurationPanelComponent implements OnInit {

  @Input() editedMap: Map<string, boolean>;
  @Input() isTemplateConfiguration: boolean;
  @Input() isSimpleConfiguration: boolean;
  @Input() listParameter: Parameter[];
  @Output() changeEvent = new EventEmitter();

  config = environment.defaultValue.device;
  accessRoles = AccessRoles;

  _transportMode: Parameter;

  get transportMode(): Parameter {
    this._transportMode = this.getOrInitializeSpecificParameter(this.listParameter, 'transportMode');
    return this._transportMode;
  }

  set transportMode(transportMode: Parameter) {
    this._transportMode = transportMode;
  }

  constructor() {}

  ngOnInit() {}

  protected getOrInitializeSpecificParameter(listParameter: Parameter[], name: string) {
    const parameter = listParameter.find(param => param.paramName === name);
    if (parameter) {
      return parameter;
    }

    listParameter.push({paramName: name, paramValue: ''});
    return listParameter[listParameter.length - 1];
  }

  shouldShowField(name): boolean {
    // Advanced configuration: show every fields
    if (!this.isTemplateConfiguration && !this.isSimpleConfiguration) {
      return true;
    }

    // Template configuration
    if (this.isTemplateConfiguration) {
      return [
        'validator', 'validator-transport-mode', 'validator-line-id', 'validator-station-id', 'validator-place-id', 'validator-zone-id',
        'validator-corridor-id', 'validator-stage-id', 'validator-direction-type', 'validator-operator-id', 'validator-amount',
        'parameters', 'parameters-installation-type', 'parameters-table'
      ].includes(name);
    }

    // Simple configuration
    const requiredRules = [
      {
        names: ['validator', 'validator-transport-mode', 'validator-company-id']
      },
      {
        names: ['validator-line-id', 'validator-place-id', 'validator-direction-type'],
        transportModes: ['Bus', 'Tramway']
      },
      {
        names: ['validator-line-id', 'validator-station-id', 'validator-direction-type'],
        transportModes: ['Métro', 'Funiculaire', 'Train']
      },
      {
        names: ['validator-station-id'],
        transportModes: ['P+R']
      }
    ];

    return [...requiredRules, ...this.config.simpleConfRules].some(rule => {
      if (rule.transportModes && rule.transportModes.length > 0) {
        return rule.transportModes.includes(this.transportMode.paramValue) && rule.names.includes(name);
      }
      return rule.names.includes(name);
    });
  }
}
