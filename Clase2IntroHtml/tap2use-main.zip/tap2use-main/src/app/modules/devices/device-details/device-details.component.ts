import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationCancel, NavigationEnd, NavigationError, RouteConfigLoadEnd, RouterEvent } from '@angular/router';

@Component({
  selector: 'app-device-details',
  templateUrl: './device-details.component.html',
  styleUrls: ['./device-details.component.css'],
})
export class DeviceDetailsComponent implements OnInit {

  poi: string;
  device: any = {};
  loaded = false;
  redirectParams: any;

  constructor(private router: Router, private route: ActivatedRoute) {
    const { redirectParams } = window.history.state;
    this.redirectParams = redirectParams;


    router.events.subscribe((event: RouterEvent): void => {
      switch (true) {
        case event instanceof RouteConfigLoadEnd:
        case event instanceof NavigationEnd:
        case event instanceof NavigationCancel:
        case event instanceof NavigationError: {
          this.loaded = true;
          break;
        }
        default: {
          this.loaded = false;
          break;
        }
      }
    });
  }
  ngOnInit() {
    this.poi = this.route.snapshot.params.poi;
    this.loadDeviceInfoV3();
    this.loadDeviceConfigV2();
  }

  goTo (route: string): void {
    this.router.navigate([route], { relativeTo: this.route });
  }

  goDevices(): void {
    this.router.navigate(['devices'], { queryParams: this.redirectParams });
  }

  getActiveTab (tabRef: string): string {
    return tabRef === this.router.url.substring(this.router.url.lastIndexOf('/') + 1) ? 'active' : '';
  }

  loadDeviceInfoV3(): void {
    const deviceInfoV3 = this.route.snapshot.data.deviceInfoV3;

    if (deviceInfoV3) {
      this.device = Object.assign({}, this.device, {
        poi: deviceInfoV3.deviceInfo.poi,
        serialNumber: deviceInfoV3.deviceInfo.serialNumber,
        deviceReference: deviceInfoV3.deviceInfo.deviceReference,
        deviceModel: deviceInfoV3.deviceInfo.deviceModel,
        simReference: deviceInfoV3.deviceInfo.simReference,
        companyReference: deviceInfoV3.locationInfo.companyReference
      });
    }
  }

  loadDeviceConfigV2(): void {
    const deviceConfigV2 = this.route.snapshot.data.deviceConfigV2;

    if (deviceConfigV2 && deviceConfigV2.configurationFile && deviceConfigV2.configurationFile.listParameter) {
      const listParameter = deviceConfigV2.configurationFile.listParameter;
      this.device = Object.assign({}, this.device, {
        function: (listParameter.find(param => param.paramName === 'function') || {}).paramValue,
        installationType: (listParameter.find(param => param.paramName === 'installationType') || {}).paramValue
      });
    }
  }
}
