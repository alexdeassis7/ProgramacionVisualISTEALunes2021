import { Component, Input, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'ap-lists-informations',
  templateUrl: './lists-informations.component.html',
  styleUrls: ['./lists-informations.component.css']
})

export class ListsInformationsComponent implements OnInit {
  @Input() device: any;

  constructor(private translateService: TranslateService) {
  }

  ngOnInit() {
  }

  noHasTranslation(key: string): boolean {
    const translation = this.translateService.instant(key);
    return translation === key || translation === '';
  }

}
