import { UserAdmin } from '@app/core/services/administrator/models/userAdmin';
import { DeviceConfigV2History } from '@app/core/services/device/models/deviceConfigV2History';

export interface DeviceConfigV2HistoryUI extends DeviceConfigV2History {
    detailsDisplayed: boolean;
    userAdmin: UserAdmin;
}
