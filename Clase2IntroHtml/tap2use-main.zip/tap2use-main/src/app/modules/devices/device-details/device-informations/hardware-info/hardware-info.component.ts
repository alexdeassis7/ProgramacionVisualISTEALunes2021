import { Component, Input, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'ap-hardware-info',
  templateUrl: './hardware-info.component.html',
  styleUrls: ['./hardware-info.component.css']
})

export class HardwareInfoComponent implements OnInit {
  @Input() device: any;

  constructor(private translateService: TranslateService) { }

  ngOnInit() {
  }

  noHasTranslation(key: string): boolean {
    const translation = this.translateService.instant(key);
    return translation === key || translation === '';
  }

}
