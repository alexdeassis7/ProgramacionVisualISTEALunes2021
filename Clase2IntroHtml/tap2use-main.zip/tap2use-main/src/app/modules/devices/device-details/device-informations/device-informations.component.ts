import { Component, OnInit } from '@angular/core';
import { environment } from '@env/environment';
import { ActivatedRoute, NavigationCancel, NavigationEnd, NavigationError, RouteConfigLoadEnd, Router, RouterEvent } from '@angular/router';
import { GenericParameter } from '@app/core/services/device/models/list/genericParameter';

@Component({
  selector: 'ap-device-informations',
  templateUrl: './device-informations.component.html',
  styleUrls: ['./device-informations.component.css']
})

export class DeviceInformationsComponent implements OnInit {
  poi: string;
  device: any = {};
  loading: boolean;
  error: boolean;
  activateXenturionInfos: boolean;
  genericParameters: Array<GenericParameter>;

  constructor(private router: Router, private route: ActivatedRoute) {
    router.events.subscribe((event: RouterEvent): void => {
      switch (true) {
        case event instanceof RouteConfigLoadEnd:
        case event instanceof NavigationEnd:
        case event instanceof NavigationCancel:
        case event instanceof NavigationError: {
          this.loading = false;
          break;
        }
        default: {
          this.loading = true;
          break;
        }
      }
    });
  }

  ngOnInit() {
    this.activateXenturionInfos = environment.defaultValue.device.activateXenturionInfos;
    this.poi = this.route.parent.snapshot.paramMap.get('poi');
    this.error = false;
    this.loadDeviceInfoV3();
    if (this.activateXenturionInfos === true) {
      this.loadXenturionInfoV3();
    }
    this.loadDeviceConfigV2();
    this.loadGenericParameters();
  }

  private loadGenericParameters(): void {
    const deviceV3 = this.route.snapshot.data.deviceV3;
    if (deviceV3) {
      this.genericParameters = deviceV3.genericParameters ?? [];
    }
  }

  private loadDeviceInfoV3(): void {
    const deviceInfoV3 = this.route.snapshot.data.deviceInfoV3;

    const sanitizeStatus = (status) => {
              if (!status || isNaN(status)) { return ''; }
              if (Number(status) > 0) { return 'OK'; }
              return 'KO';
            };

    if (deviceInfoV3) {
      this.device = Object.assign({}, this.device, {
        infoV3: {
          poi: deviceInfoV3.deviceInfo.poi,
          // Configuration
          version: deviceInfoV3.configuration.version,
          versionDate: deviceInfoV3.configuration.versionDate,
          // Lists informations
          listInformation: deviceInfoV3.listInformation,
          // System Info
          lastConnection: deviceInfoV3.deviceInfo.date,
          upTime: (deviceInfoV3.deviceInfo.metrics.find(metric => metric.key === 'upTime') || {}).value,
          diskUsage: (deviceInfoV3.deviceInfo.metrics.find(metric => metric.key === 'diskUsage') || {}).value,
          rebootCount: (deviceInfoV3.deviceInfo.metrics.find(metric => metric.key === 'rebootCount') || {}).value,
          cpuUsage: (deviceInfoV3.deviceInfo.metrics.find(metric => metric.key === 'cpuUsage') || {}).value,
          memoryUsage: (deviceInfoV3.deviceInfo.metrics.find(metric => metric.key === 'memoryUsage') || {}).value,
          tapStored: (deviceInfoV3.deviceInfo.metrics.find(metric => metric.key === 'tapStored') || {}).value,
          lastTransmittedTap: (deviceInfoV3.deviceInfo.metrics.find(metric => metric.key === 'lastTransmittedTap') || {}).value,
          // Location Info
          serviceOperator: deviceInfoV3.deviceInfo.serviceOperator,
          firmwareVersion: deviceInfoV3.deviceInfo.firmwareVersion,
          coordinateLatitude: deviceInfoV3.locationInfo.coordinateLatitude,
          coordinateLongitude: deviceInfoV3.locationInfo.coordinateLongitude,
          // Hardware Info
          simReference: (deviceInfoV3.deviceInfo.metrics.find(metric => metric.key === 'simReference') || {}).value,
          status4G: sanitizeStatus((deviceInfoV3.deviceInfo.metrics.find(metric => metric.key === '4g') || {}).value),
          network4G: (deviceInfoV3.deviceInfo.metrics.find(metric => metric.key === 'network4G') || {}).value,
          GPSStatus: sanitizeStatus((deviceInfoV3.deviceInfo.metrics.find(metric => metric.key === 'gps') || {}).value),
          accessStatus: sanitizeStatus((deviceInfoV3.deviceInfo.metrics.find(metric => metric.key === 'gpioController') || {}).value)
        }
      });

      if (this.device.infoV3.diskUsage && !isNaN(this.device.infoV3.diskUsage)) {
        this.device.infoV3.diskUsage = this.device.infoV3.diskUsage / 100;
      }
      if (this.device.infoV3.cpuUsage && !isNaN(this.device.infoV3.cpuUsage)) {
        this.device.infoV3.cpuUsage = this.device.infoV3.cpuUsage / 100;
      }
      if (this.device.infoV3.memoryUsage && !isNaN(this.device.infoV3.memoryUsage)) {
        this.device.infoV3.memoryUsage = this.device.infoV3.memoryUsage / 100;
      }
    } else {
      this.error = true;
    }
  }

  private loadXenturionInfoV3(): void {
    const xenturionInfoV3 = this.route.snapshot.data['xenturionInfoV3'];
    if (xenturionInfoV3 && xenturionInfoV3 !== '{error}') {
      this.device = Object.assign({}, this.device, {
          xenturionInfoV3: xenturionInfoV3,
      });
    } else {
      this.error = true;
    }
  }

  private loadDeviceConfigV2(): void {
    const deviceConfigV2 = this.route.snapshot.data.deviceConfigV2;

    if (deviceConfigV2 && deviceConfigV2.configurationFile && deviceConfigV2.configurationFile.listParameter) {
      const listParameter = deviceConfigV2.configurationFile.listParameter;
      this.device = Object.assign({}, this.device, {
        configV2: {
          function: (listParameter.find(param => param.paramName === 'function') || {}).paramValue,
          installationType: (listParameter.find(param => param.paramName === 'installationType') || {}).paramValue,
          configVersion: (listParameter.find(param => param.paramName === 'configVersion') || {}).paramValue
        }
      });
    } else {
      this.error = true;
    }
  }

}
