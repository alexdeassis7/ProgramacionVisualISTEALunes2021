import { Component, Input, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import * as moment from 'moment';

@Component({
  selector: 'ap-system-info',
  templateUrl: './system-info.component.html',
  styleUrls: ['./system-info.component.css']
})

export class SystemInfoComponent implements OnInit {
  @Input() device: any;
  language: string;
  lastConnectionStatus: 'SUCCESS' | 'WARNING' | 'DANGER';
  rebootCountStatus: 'SUCCESS' | 'WARNING' | 'DANGER';

  diskUsageThreshold = {
    success : '0.8',
    danger : '0.95'
  };
  memoryUsageThreshold = {
    success : '0.8',
    danger : '0.95'
  };
  cpuUsageThreshold = {
    success : '0.8',
    danger : '0.95'
  };

  constructor(private translateService: TranslateService) {
  }

  ngOnInit() {
    this.language = this.translateService.currentLang;
    this.translateService.onLangChange.subscribe(langEvent => { this.language = langEvent.lang; });
    this.computeLastConnectionStatus();
    this.computeRebootCountStatus();
  }

  /**
   * Set status of the upTime
   * If the duration between last connection from now is greater than 24H else it's DANGER status.
   */
  private computeLastConnectionStatus() {
    if (this.device.infoV3 && this.device.infoV3.lastConnection) {
      const date = moment(this.device.infoV3.lastConnection);
      this.lastConnectionStatus = moment.duration(moment().diff(date)).asHours() > 24 ? 'DANGER' : 'SUCCESS';
    } else {
      this.lastConnectionStatus = 'WARNING';
    }
  }

  /**
   * Set status of the RebootCount
   * If the reboot count is greater than 10 times else it's DANGER status.
   */
  private computeRebootCountStatus() {
    if (this.device.infoV3 && !isNaN(+this.device.infoV3.rebootCount)) {
      if (+this.device.infoV3.rebootCount <= 5) {
        this.rebootCountStatus = 'SUCCESS';
      } else if (+this.device.infoV3.rebootCount <= 10) {
        this.rebootCountStatus = 'WARNING';
      } else {
        this.rebootCountStatus = 'DANGER';
      }
    } else {
      this.rebootCountStatus = 'WARNING';
    }
  }

  noHasTranslation(key: string): boolean {
    const translation = this.translateService.instant(key);
    return translation === key || translation === '';
  }

}
