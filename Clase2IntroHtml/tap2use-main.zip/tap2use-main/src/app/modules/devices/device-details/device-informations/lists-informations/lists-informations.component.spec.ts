import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListsInformationsComponent } from './lists-informations.component';

describe('ListsInformationsComponent', () => {
  let component: ListsInformationsComponent;
  let fixture: ComponentFixture<ListsInformationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListsInformationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListsInformationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
