import { Component, OnInit, Input } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'ap-xenturion',
  templateUrl: './xenturion.component.html',
  styleUrls: ['./xenturion.component.css']
})

export class XenturionComponent implements OnInit {
  @Input() device: any;

  constructor(private translateService: TranslateService) {
  }

  ngOnInit() {
  }

  noHasTranslation(key: string): boolean {
    const translation = this.translateService.instant(key);
    return translation === key || translation === '';
  }

}
