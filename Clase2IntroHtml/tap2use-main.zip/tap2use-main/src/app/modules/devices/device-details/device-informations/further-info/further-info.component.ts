import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { DeviceService } from '@app/core/services/device/device.service';
import { GenericParameter } from './../../../../../core/services/device/models/list/genericParameter';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { Component, Input, OnInit } from '@angular/core';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { environment } from '@env/environment';


@Component({
  selector: 'ap-further-info',
  templateUrl: './further-info.component.html',
  styleUrls: ['./further-info.component.css']
})

export class FurtherInfoComponent extends AbstractOnDestroyComponent implements OnInit {

  @Input() genericParameters: Array<GenericParameter>;
  @Input() poi: string;

  furtherInfoForm: FormGroup;
  hasTableChanged = false;
  genericParametersSaving = false;


  defaultValues: any = environment?.defaultValue?.device?.furtherInfo ?? {};
  defaultNames: string[] = Object.keys(this.defaultValues);

  constructor(
    private formBuilder: FormBuilder,
    private deviceService: DeviceService,
    private toastr: ToastrService,
    private translateService: TranslateService) {
    super();
  }

  ngOnInit() {
    this.initFormWithGenericParameters();
  }

  private initFormWithGenericParameters(): void {
    this.hasTableChanged = false;

    this.furtherInfoForm = this.formBuilder.group({
      parameters: this.formBuilder.array(this.genericParameters.map(({ name, value }) => this.formBuilder.group({ name, value }))),
      newName: '',
      newValue: ''
    });
  }

  save(): void {
    this.genericParametersSaving = true;
    this.furtherInfoForm.value.parameters.forEach((param, index) => {
      if (!this.defaultValues[param.name].includes(param.value)) {
        this.furtherInfoForm.value.parameters[index].value = this.defaultValues[param.name][0];
      }
    });
    this.deviceService.createOrUpdateGenericParameters(this.poi, this.furtherInfoForm.value.parameters)
      .subscribe((data) => {
        this.genericParameters = data.genericParameters;
        this.initFormWithGenericParameters();
        this.toastr.success(this.translateService.instant('TOAST.SUCCESS.MODIFICATION'));
        this.genericParametersSaving = false;
      },
      _err => {
        this.toastr.error(this.translateService.instant('TOAST.ERROR.FAILED'));
        this.genericParametersSaving = false;
      });
  }

  deleteRow(index: number): void {
    this.hasTableChanged = true;
    (<FormArray>this.furtherInfoForm.controls.parameters).removeAt(index);
  }

  addRow() {
    this.hasTableChanged = true;

    const newRow = this.formBuilder.group({
      name: this.furtherInfoForm.controls.newName.value,
      value: this.furtherInfoForm.controls.newValue.value
    });
    (<FormArray>this.furtherInfoForm.controls.parameters).push(newRow);

    this.furtherInfoForm.controls.newName.reset();
    this.furtherInfoForm.controls.newValue.reset();
  }
}
