import { Component, Input, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'ap-location-info',
  templateUrl: './location-info.component.html',
  styleUrls: ['./location-info.component.css']
})

export class LocationInfoComponent implements OnInit {
  @Input() device: any;

  displayLeafletMap = false;

  locationInfoInitialMapViewState: { lat?: number, lng?: number, zoom?: number } = { zoom: 14 };

  locationInfoMapMarker: { lat?: number, lng?: number, popupLabel?: string } = {};

  constructor(private translateService: TranslateService) {}

  ngOnInit() {
    if (this.device && this.device.infoV3) {
      const lat = this.device.infoV3.coordinateLatitude;
      const lng = this.device.infoV3.coordinateLongitude;

      this.displayLeafletMap = Number.isFinite(lat) && Number.isFinite(lng);

      this.locationInfoInitialMapViewState.lat = this.locationInfoMapMarker.lat = lat;
      this.locationInfoInitialMapViewState.lng = this.locationInfoMapMarker.lng = lng;

      this.locationInfoMapMarker.popupLabel = 'POI ' + this.device.infoV3.poi + '<br/>' + this.device.configV2.installationType;
    }
  }

  noHasTranslation(key: string): boolean {
    const translation = this.translateService.instant(key);
    return translation === key || translation === '';
  }

}
