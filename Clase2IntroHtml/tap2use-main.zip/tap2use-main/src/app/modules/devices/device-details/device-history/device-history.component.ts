import { animate, style, transition, trigger } from '@angular/animations';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationCancel, NavigationEnd, NavigationError, RouteConfigLoadEnd, Router, RouterEvent } from '@angular/router';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { AdministratorService } from '@app/core/services/administrator/administrator.service';
import { AccessRoles } from '@app/core/services/administrator/models/accessRoles';
import { UserAdmin } from '@app/core/services/administrator/models/userAdmin';
import { DeviceConfigV2History } from '@app/core/services/device/models/deviceConfigV2History';
import { of } from 'rxjs/internal/observable/of';
import { takeUntil, pluck, map, mergeMap, catchError } from 'rxjs/operators';
import { DeviceConfigV2HistoryUI } from './deviceConfigV2HistoryUI.model';

@Component({
  selector: 'ap-device-history',
  templateUrl: './device-history.component.html',
  styleUrls: ['./device-history.component.css'],
  animations: [
    trigger('toggleFilterAction', [
      transition(':enter', [
        style({ height: '0px', overflow: 'hidden' }),
        animate('200ms', style({ height: '*' })),
      ]),
      transition(':leave', [
        animate('200ms', style({ height: '0px', overflow: 'hidden' }))
      ])
    ])
  ]
})
export class DeviceHistoryComponent extends AbstractOnDestroyComponent implements OnInit {
  accessRoles = AccessRoles;
  configHistoryUI: DeviceConfigV2HistoryUI[];
  loading = false;
  error: boolean;

  constructor(private administratorService: AdministratorService, private router: Router, private route: ActivatedRoute) {
    super();

    router.events.subscribe((event: RouterEvent): void => {
      switch (true) {
        case event instanceof RouteConfigLoadEnd:
        case event instanceof NavigationEnd:
        case event instanceof NavigationCancel:
        case event instanceof NavigationError: {
          this.loading = false;
          break;
        }
        default: {
          this.loading = true;
          break;
        }
      }
    });
  }

  ngOnInit() {
    this.error = false;
    this.loading = true;
    // get deviceConfigV2 history data from resolver
    this.route.data
      .pipe(
        takeUntil(this.unsubscribe),
        pluck('deviceConfigV2'),
        pluck('history'),
        map((records: DeviceConfigV2History[]) => {
          return <DeviceConfigV2HistoryUI[]> records.sort((a, b) => new Date(b.updateDate).getTime() - new Date(a.updateDate).getTime());
        }),
        mergeMap((records: DeviceConfigV2HistoryUI[]) => {
          // Filter null value and remove duplicate reference
          const userReference = records
            .filter(r => r.user && r.user.reference)
            .map(r => r.user.reference)
            .filter((value, index, self) => {
              return self.indexOf(value) === index;
            });
          // Retrieve users from userRefs
          return this.administratorService.getUsersByReferences(userReference).pipe(
            // Forbidden Error (403): API can't return result => display history without user informations
            catchError((error: HttpErrorResponse) => {
              if (error.status === 403) {
                this.configHistoryUI = records;
              }
              return records;
            }),
            map((users: UserAdmin[]) => {
              records.forEach(r => {
                r.userAdmin = users.find(user => user.userCredentials.userKeycloakId === r.user.reference);
              });
              return records;
            })
          );
        })
      )
      .subscribe(
        records => {
          this.configHistoryUI = records;
          this.loading = false;
        },
        _err => {
          if (!this.configHistoryUI) {
            this.error = true;
          }
          this.loading = false;
        }
      );
  }

  toogleDisplayTable(history: DeviceConfigV2HistoryUI) {
    history.detailsDisplayed = !history.detailsDisplayed;
  }

}
