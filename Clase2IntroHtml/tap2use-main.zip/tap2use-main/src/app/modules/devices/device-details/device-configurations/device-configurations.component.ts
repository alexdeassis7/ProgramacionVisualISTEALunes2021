import { SimpleModalService } from 'ngx-simple-modal';
import { DeviceConfigurationV2 } from './../../../../core/services/device/models/deviceConfigurationV2';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, RouterEvent, RouteConfigLoadEnd, NavigationEnd, NavigationCancel, NavigationError } from '@angular/router';
import { DeviceService } from '@app/core/services/device/device.service';
import { TranslateService } from '@ngx-translate/core';
import cloneDeep from 'lodash.clonedeep';
import { ConfirmComponent } from '@app/shared/components/confirm/confirm.component';
import { ToastrService } from 'ngx-toastr';
import { environment } from '@env/environment';

@Component({
  selector: 'app-device-configurations',
  templateUrl: './device-configurations.component.html',
  styleUrls: ['./device-configurations.component.css']
})
export class DeviceConfigurationsComponent implements OnInit {
  deviceConfig: DeviceConfigurationV2;
  loaded = false;
  error = false;
  errorSavingData = false;
  extractedParametersIndex: Map<string, number>;
  stepper: any = {};
  editedMap: Map<string, boolean>;

  simpleConfiguration: any = {};

  constructor(private router: Router, private route: ActivatedRoute, private deviceService: DeviceService,
    private translateService: TranslateService, private simpleModalService: SimpleModalService, private toastr: ToastrService) {
    router.events.subscribe((event: RouterEvent): void => {
      switch (true) {
        case event instanceof RouteConfigLoadEnd:
        case event instanceof NavigationEnd:
        case event instanceof NavigationCancel:
        case event instanceof NavigationError: {
          this.loaded = true;
          break;
        }
        default: {
          this.loaded = false;
          break;
        }
      }
    });
  }

  ngOnInit() {
    this.loadDeviceConfigV2(this.route.snapshot.data.deviceConfigV2);

    const deviceFuction = this.deviceConfig.configurationFile.listParameter.find(param => param.paramName === 'function');
    const isActivated = environment.defaultValue.device.activateSimpleConfiguration &&
      (deviceFuction && deviceFuction.paramValue && deviceFuction.paramValue.toLowerCase() === 'validation');

    this.simpleConfiguration = {
      isActivated,
      isSimple: isActivated,
      buttonLabel: this.translateService.instant(`DEVICE.LABELS.CONFIGURATION.BUTTON.${isActivated ? 'ADVANCED' : 'SIMPLIFIED'}`)
    };
  }

  switchConfigurationMode(): void {
    this.simpleConfiguration.isSimple = !this.simpleConfiguration.isSimple;
    this.simpleConfiguration.buttonLabel = this.translateService.instant(
      `DEVICE.LABELS.CONFIGURATION.BUTTON.${this.simpleConfiguration.isSimple ? 'ADVANCED' : 'SIMPLIFIED'}`);
  }

  reset(): void {
    this.loadDeviceConfigV2(this.route.snapshot.data.deviceConfigV2);
  }

  confirmSave() {
    const options = {
      title: 'MENU.DEVICES.DETAILS',
      message: 'DEVICE.LABELS.CONFIGURATION.SAVE_MESSAGE',
      confirmButton: 'ACTIONS.SEND',
      closeButton: 'ACTIONS.CANCEL'
    };

    const modal = this.simpleModalService.addModal(ConfirmComponent, options).subscribe( isConfirmed => {
      if (isConfirmed) {
        this.deviceService.createOrUpdateDeviceConfigV2(this.deviceConfig)
          .subscribe((data) => {
            this.loadDeviceConfigV2(data);
            this.toastr.success(this.translateService.instant('TOAST.SUCCESS.MODIFICATION'));
          },
          err => {
            this.errorSavingData = true;
          });
      }
    });

    // Automatically close modal after 30 seconds
    setTimeout( () => modal.unsubscribe(), 30 * 1000);
  }

  update(elementId) {
    this.stepper.activeStep = 2;
    this.stepper.titleX = this.translateService.instant('DEVICE.LABELS.CONFIGURATION.STEPPER.TITLE_V_X_UPDATED');
    this.editedMap.set(elementId, true);
  }

  modifyParameters(event) {
    switch (event.name) {
      case 'add-parameter':
        this.deviceConfig.configurationFile.listParameter = this.deviceConfig.configurationFile.listParameter.concat([event.message]);
        break;
      case 'remove-parameter':
        const indexToRemove = this.deviceConfig.configurationFile.listParameter.findIndex(({ paramName }) => {
          return paramName === event.message.paramName;
        });
        this.deviceConfig.configurationFile.listParameter.splice(indexToRemove, 1);
        this.deviceConfig.configurationFile.listParameter = [...this.deviceConfig.configurationFile.listParameter];
        break;
    }
  }

  private loadDeviceConfigV2(deviceConfigV2: DeviceConfigurationV2): void {
    this.editedMap = new Map();
    this.deviceConfig = cloneDeep(deviceConfigV2);
    if (!this.deviceConfig || !this.deviceConfig.configurationFile) {
      this.error = true;
      return;
    }

    this.stepper = {
      activeStep: 1,
      x: 'v' + this.getConfigVersion(),
      xPlusOne: 'v' + (this.getConfigVersion() + 1)
    };
    this.stepper.titleX = this.translateService.instant('DEVICE.LABELS.CONFIGURATION.STEPPER.TITLE_V_X');
    this.stepper.titleXPlusOne = this.translateService.instant('DEVICE.LABELS.CONFIGURATION.STEPPER.TITLE_V_X_PLUS_ONE');
    this.error = false;
  }

  private getConfigVersion(): number {
    const listParameter = this.deviceConfig.configurationFile.listParameter || [];
    const index = listParameter.findIndex(param => param.paramName === 'configVersion');
    return parseInt(this.deviceConfig.configurationFile.listParameter[index].paramValue, 10) || 0;
  }
}
