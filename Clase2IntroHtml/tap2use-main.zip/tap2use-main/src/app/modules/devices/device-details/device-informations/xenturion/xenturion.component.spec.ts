import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { XenturionComponent } from './xenturion.component';

describe('XenturionComponent', () => {
  let component: XenturionComponent;
  let fixture: ComponentFixture<XenturionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ XenturionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(XenturionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
