import { Component, Input, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { takeUntil } from 'rxjs/operators';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { MatSortHeader } from '@angular/material/sort';

@Component({
  selector: 'ap-configuration',
  templateUrl: './configuration.component.html',
  styleUrls: ['./configuration.component.css']
})

export class ConfigurationComponent extends AbstractOnDestroyComponent implements OnInit {
  @Input() device: any;

  cssConfigVersionIndicator = {
    success: 'SUCCESS',
    warning: 'WARNING',
    danger: 'DANGER'
  };

  labelConfigVersionIndicator = {
    success: 'DEVICE.LABELS.INFO_CONFIGURATION.UP_TO_DATE',
    warning: 'DEVICE.LABELS.INFO_CONFIGURATION.PENDING',
    danger: 'DEVICE.LABELS.INFO_CONFIGURATION.OUT_OF_DATE',
  };
  labelConfigVersion: string;

  constructor(private translateService: TranslateService) {
    super();
  }

  ngOnInit() {
    this.labelConfigVersion = this.labelConfigVersionIndicator.danger;
  }

  getConfigVersionIndicator() {
    if ( !(this.device && this.device.configV2 && this.device.configV2.configVersion) ) {
      return this.cssConfigVersionIndicator.danger;
    }
    if ( !(this.device && this.device.infoV3 && this.device.infoV3.version) ) {
      return this.cssConfigVersionIndicator.danger;
    }

    const configVersionNum = Number(this.device.configV2.configVersion);
    const versionNum = Number(this.device.infoV3.version);

    if (isNaN(configVersionNum) || isNaN(versionNum) ) {
      return this.cssConfigVersionIndicator.danger;
    }
    if (Math.abs(configVersionNum - versionNum) === 0) {
      this.labelConfigVersion = this.labelConfigVersionIndicator.success;
      return this.cssConfigVersionIndicator.success;
    } else if (Math.abs(configVersionNum - versionNum) <= 1) {
      this.labelConfigVersion = this.labelConfigVersionIndicator.warning;
      return this.cssConfigVersionIndicator.warning;
    } else {
      this.labelConfigVersion = this.labelConfigVersionIndicator.danger;
      return this.cssConfigVersionIndicator.danger;
    }
  }

  noHasTranslation(key: string): boolean {
    const translation = this.translateService.instant(key);
    return translation === key || translation === '';
  }

}
