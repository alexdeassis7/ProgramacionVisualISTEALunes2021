import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '@app/shared/shared.module';
import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home-informations/home.component';
import { HomePasswordComponent } from './home-password/home-password.component';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    HomeRoutingModule
  ],
  declarations: [HomeComponent, HomePasswordComponent],
  exports: [HomeComponent]
})
export class HomeModule {}
