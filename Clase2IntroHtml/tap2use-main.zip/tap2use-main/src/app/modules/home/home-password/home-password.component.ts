import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AdministratorService } from '@app/core/services/administrator/administrator.service';
import { UserAdmin } from '@app/core/services/administrator/models/userAdmin';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { NgForm } from '@angular/forms';
import { environment } from '@env/environment';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-home-password',
  templateUrl: './home-password.component.html',
  styleUrls: ['./home-password.component.css']
})
export class HomePasswordComponent extends AbstractOnDestroyComponent implements OnInit {

  @Input()
  private admin: UserAdmin;

  @Output()
  private close: EventEmitter<any> = new EventEmitter();

  newPassword: string;
  newPasswordConfirmation: string;
  constructor(
    private adminsitratorService: AdministratorService,
    private translate: TranslateService,
    private toastr: ToastrService) {
      super();
    }

  ngOnInit() {
  }

  cancel() {
    this.close.emit(null);
  }

  updatePassword(passwordForm: NgForm) {

    if (passwordForm.valid && this.newPassword === this.newPasswordConfirmation) {
      this.admin.userCredentials.userPassword = this.newPassword;

      this.adminsitratorService.updatePassword(this.admin.userId, this.admin.userCredentials)
      .pipe( takeUntil(this.unsubscribe) )
      .subscribe(() => {
        this.translate.get('TOAST.SUCCESS.MODIFICATION').subscribe(msg => this.toastr.success(msg));
        this.newPassword = null;
        this.newPasswordConfirmation = null;
        this.close.emit(null);
      }, err =>{
          if(err.status == 403){
            this.translate.get('ERROR_PAGE.ACCESS_FORBIDDEN').subscribe(msg =>this.toastr.error(msg));
          }else{
            this.translate.get('ERROR_PAGE.INTERNAL_ERROR').subscribe(msg =>this.toastr.error(msg));
          }
      });
    } else {
      this.translate.get('ERROR.PATTERN.PASSWORD').subscribe(msg =>this.toastr.error(msg));
    }
  }

}
