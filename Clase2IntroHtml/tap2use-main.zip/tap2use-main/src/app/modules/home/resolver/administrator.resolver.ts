import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { UserAdmin } from '@app/core/services/administrator/models/userAdmin';
import { AdministratorService } from '@app/core/services/administrator/administrator.service';
import { KeycloakService } from 'keycloak-angular';

@Injectable()
export class AdministratorResolver implements Resolve<UserAdmin> {

    constructor(private administratorService: AdministratorService, private keycloakService: KeycloakService) {}

    resolve(route: ActivatedRouteSnapshot): Observable<UserAdmin> {
        const reference = this.keycloakService.getKeycloakInstance().subject;
        return this.administratorService.getUserByReference(reference);
    }
}

