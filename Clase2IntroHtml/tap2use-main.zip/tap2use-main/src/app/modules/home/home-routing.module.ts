import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home-informations/home.component';
import { AdministratorResolver } from './resolver/administrator.resolver';

const routes: Routes = [
  { path: '', component: HomeComponent, resolve: { admin: AdministratorResolver } }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
  ],
  providers: [
    AdministratorResolver
  ]
})
export class HomeRoutingModule { }
