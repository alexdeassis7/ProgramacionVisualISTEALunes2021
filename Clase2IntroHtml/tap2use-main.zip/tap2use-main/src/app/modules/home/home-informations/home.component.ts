import { Component, OnInit } from '@angular/core';
import { AdministratorService } from '@app/core/services/administrator/administrator.service';
import { ActivatedRoute } from '@angular/router';
import { KeycloakService } from 'keycloak-angular';
import { KeycloakProfile } from 'keycloak-js';
import { UserAdmin } from '@app/core/services/administrator/models/userAdmin';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { NgForm } from '@angular/forms';
import { AppService } from '@app/app.service';
import { takeUntil } from 'rxjs/operators';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent extends AbstractOnDestroyComponent implements OnInit {
  agent: KeycloakProfile;
  roles: string[];
  mainRole: UserAdmin.Role;

  showPasswordForm = false;
  keycloakId;
  adminId: number;
  administrators: UserAdmin;

  admin: UserAdmin;

  constructor(
    private keycloakService: KeycloakService,
    private route: ActivatedRoute,
    private adminsitratorService: AdministratorService,
    private translate: TranslateService,
    private toastr: ToastrService,
    private appService: AppService
  ) {
    super();
  }


  ngOnInit() {
    this.route.data.subscribe((data: { admin: UserAdmin }) => this.admin = data.admin);

    this.keycloakId = this.keycloakService.getKeycloakInstance().subject;
    this.keycloakService.loadUserProfile().then(agent => {
      this.agent = agent;
      this.adminsitratorService.getAdministratorByKCId(this.keycloakId)
        .pipe(takeUntil(this.unsubscribe))
        .subscribe(res => {
          this.administrators = res;
          this.adminId = this.administrators.userDetails.userId;
        },
        err => {
          this.toastr.error(err);
        });
      this.roles = this.keycloakService.getUserRoles();
      if (this.roles.indexOf(UserAdmin.Role.SUPER_ADMIN) > -1) {
        this.mainRole = UserAdmin.Role.SUPER_ADMIN;
      } else if (this.roles.indexOf(UserAdmin.Role.ADMIN) > -1) {
        this.mainRole = UserAdmin.Role.ADMIN;
      } else if (this.roles.indexOf(UserAdmin.Role.SAV) > -1) {
        this.mainRole = UserAdmin.Role.SAV;
      } else if (this.roles.indexOf(UserAdmin.Role.STATS) > -1) {
        this.mainRole = UserAdmin.Role.STATS;
      } else if (this.roles.indexOf(UserAdmin.Role.OPERATOR) > -1) {
        this.mainRole = UserAdmin.Role.OPERATOR;
      }  else if (this.roles.indexOf(UserAdmin.Role.SERVICE_OPERATOR) > -1) {
        this.mainRole = UserAdmin.Role.SERVICE_OPERATOR;
      } else if (this.roles.indexOf(UserAdmin.Role.AGENT) > -1) {
        this.mainRole = UserAdmin.Role.AGENT;
      }
    });
  }

  submitUserUpdateForm(userUpdateForm: NgForm) {
    if (userUpdateForm.valid) {
      delete(this.administrators.mainRole);
      delete(this.administrators.userCreationDate);
      delete(this.administrators.userModificationDate);
      delete(this.administrators.userDetails.userId);
      delete(this.administrators.userCredentials.userId);
      delete(this.administrators.userCredentials.userKeycloakId);
      delete(this.administrators.userCredentials.userRealm);

      this.adminsitratorService.updateUserBack(this.administrators, this.adminId)
      .pipe( takeUntil(this.unsubscribe) )
      .subscribe(_result => {
        this.toastr.success(this.translate.instant('TOAST.SUCCESS.MODIFICATION'));
        // To refresh sidebar menu
        this.appService.setUpdate('update');
      },
      _err => {
        this.toastr.error(this.translate.instant('TOAST.ERROR.FAILED'));
      });
    }
  }
}
