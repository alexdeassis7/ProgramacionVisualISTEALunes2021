import { AccessMediaService } from '@app/core/services/access-media/access-media.service';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve } from '@angular/router';
import { catchError } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import { Page } from '@app/core/services/commons/page';
import { AccessMedia } from '@app/core/services/access-media/models/accessMedia';

@Injectable()
export class AccessMediaResolver implements Resolve<Page<AccessMedia>> {

  constructor(private accessMediaService: AccessMediaService) {}

  resolve(route: ActivatedRouteSnapshot): Observable<Page<AccessMedia>> {
    const filterEncode = route.queryParamMap.get('filter') || '';

    const filter = { accessMediaStatuses: ['ACTIVE', 'BLOCKED'] };

    if (filterEncode) {
      filterEncode.split('|')
        .filter(s => s.match(/.*\~[0-1]\~.*/))
        .filter(s => {
          const enabled = s.split('~')[1] === '1';
          return enabled;
        })
        .forEach(s => {
          const key = s.split('~')[0];
          const value = s.split('~')[2];
          filter[key] = value;
        });
    }

    const pageNumber = +route.queryParamMap.get('pageNumber') || 0;
    const pageSize = +route.queryParamMap.get('pageSize') || 10;
    const sortOrder = <'ASC'|'DESC'>(route.queryParamMap.get('sortOrder') || 'DESC');
    const sortElement = route.queryParamMap.get('sortElement') || 'accessMediaReference';

    return this.accessMediaService
      .findAccessMedias(filter, sortOrder, sortElement, pageNumber, pageSize)
      .pipe(catchError(_err => of(null)));
  }
}
