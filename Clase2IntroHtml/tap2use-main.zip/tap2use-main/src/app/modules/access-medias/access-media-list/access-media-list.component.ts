import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccessMedia } from '@app/core/services/access-media/models/accessMedia';
import { tap, pluck, catchError } from 'rxjs/operators';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { Pagination } from '@app/shared/components/pagination/pagination.model';
import { Sort } from '@app/shared/components/table/sort/sort.model';
import { FilterData } from '@app/shared/components/filter/filterData';
import { TextFilterTemplate } from '@app/shared/components/filter/filter-template/text-filter-template/text-filter-template.model';
import { SipsFilterTemplate } from '@app/shared/components/filter/filter-template/sips-filter-template/sips-filter-template.model';
import { Observable, of } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';


@Component({
  selector: 'app-access-media-list',
  templateUrl: './access-media-list.component.html',
  styleUrls: ['./access-media-list.component.css']
})
export class AccessMediaListComponent extends AbstractOnDestroyComponent implements OnInit {

  loading = false;
  error = false;
  $accessMedias: Observable<AccessMedia[]>;
  pagination: Pagination;
  filterData: FilterData;
  sort: Sort;

  constructor(private router: Router, private route: ActivatedRoute, private readonly toastr: ToastrService,
    private translate: TranslateService) {
    super();

    // Define possible filters
    const templates = [
      new SipsFilterTemplate('referenceFilter', 'ACCESS_MEDIA.LABELS.TOKEN', 'DEFAULT', 'EQUALS'),
      new TextFilterTemplate('paymentAccountReferenceFilter', 'ACCESS_MEDIA.LABELS.BANK_ACCOUNT_REFERENCE', 'DEFAULT', 'EQUALS'),
      new TextFilterTemplate('holderEmailFilter', 'ACCESS_MEDIA.LABELS.EMAIL', 'DEFAULT', 'CONTAINS'),
      new TextFilterTemplate('holderLastNameFilter', 'ACCESS_MEDIA.LABELS.USER.LAST_NAME', 'DEFAULT', 'CONTAINS'),
      new TextFilterTemplate('holderFirstNameFilter', 'ACCESS_MEDIA.LABELS.USER.FIRST_NAME', 'DEFAULT', 'CONTAINS')
    ];

    this.filterData = new FilterData('accessMedia', templates);
  }

  ngOnInit() {

    // If encoded URL filter change after reload (navigate to same page with a diffrent filter), same thing with filter
    this.route.queryParamMap.subscribe(params => {
      // filter decode
      this.filterData.decode(params.get('filter') || '');
      // sort decode
      if (params.has('sortElement') && params.has('sortOrder')) {
        this.sort = new Sort(params.get('sortElement'), <'ASC' | 'DESC'> params.get('sortOrder'));
      } else {
        this.sort = new Sort('accessMediaReference', 'DESC');
      }
    });

    this.$accessMedias = this.route.data.pipe(
      pluck('pageAccessMedia'),
      tap((pageAccessMedia) => {
        this.loading = false;
        if (!pageAccessMedia) {
          throw new Error('Error while calling page access media API');
        }
        const { size, totalElements, number, totalPages } = pageAccessMedia;
        this.pagination = { elements: size, totalElements, page: number, totalPages };
      }),
      pluck('content'),
      catchError(_err => {
        this.toastr.error(this.translate.instant('TOAST.ERROR.FAILED'));
        return of([]);
      })
    );

    // If filterData change then reload the page (get data with resolver)
    this.filterData.onChange$.subscribe(_e => {
      this.pagination.page = 0;
      this.reloadPageAccessMediaList();
    });
  }

  filterBySort(sort: Sort) {
    this.sort = sort;
    this.pagination.page = 0;
    this.reloadPageAccessMediaList();
  }

  filterByPagination(page: number) {
    this.pagination.page = page;
    this.reloadPageAccessMediaList();
  }

  filterByPaginationSize(size: number) {
    this.pagination.elements = size;
    this.pagination.page = 0;
    this.reloadPageAccessMediaList();
  }

  /**
   * Call accessmedia-resolver when pagination and filters change for retriving device data
   */
  private reloadPageAccessMediaList(): void {
    this.loading = true;
    this.router.navigate(['accessmedias'], {
      queryParams: {
        filter: this.filterData.encode(),
        pageNumber: this.pagination.page,
        pageSize: this.pagination.elements,
        sortElement: this.sort && this.sort.field,
        sortOrder: this.sort && this.sort.order,
        refresh: (new Date()).getTime()
      }
    });
  }
}
