import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccessMediaListComponent } from './access-media-list.component';

describe('AccessMediaListComponent', () => {
  let component: AccessMediaListComponent;
  let fixture: ComponentFixture<AccessMediaListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccessMediaListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccessMediaListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
