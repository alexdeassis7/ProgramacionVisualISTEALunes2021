import { AccessMediaResolver } from './resolvers/access-media-resolver';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '@app/shared/shared.module';
import { AccessMediaListComponent } from './access-media-list/access-media-list.component';
import { AccessMediasRoutingModule } from './access-medias-routing.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    AccessMediasRoutingModule
  ],
  declarations: [
    AccessMediaListComponent
  ],
  providers: [
    AccessMediaResolver
  ],
  exports: [
    AccessMediaListComponent
  ]
})
export class AccessMediasModule { }
