import { AccessMediaResolver } from './resolvers/access-media-resolver';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppAuthGuard } from '@app/core/guards/authguard';
import { AccessRoles } from '@app/core/services/administrator/models/accessRoles';
import { AccessMediaListComponent } from './access-media-list/access-media-list.component';

const routes: Routes = [
  {
    path: '',
    component: AccessMediaListComponent,
    canActivate: [AppAuthGuard],
    data: {
      role: [
        AccessRoles.ROLE_SUPER_ADMIN,
        AccessRoles.ROLE_ADMIN,
        AccessRoles.ROLE_SAV,
        AccessRoles.ROLE_AGENT
      ]
    },
    resolve: { pageAccessMedia: AccessMediaResolver },
    runGuardsAndResolvers: 'paramsOrQueryParamsChange',
  }
];

@NgModule({
imports: [
  RouterModule.forChild(routes)
],
exports: [
  RouterModule
],
providers: []
})
export class AccessMediasRoutingModule { }
