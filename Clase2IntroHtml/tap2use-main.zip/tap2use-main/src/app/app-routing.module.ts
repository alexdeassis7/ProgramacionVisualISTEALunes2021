import { NgModule } from '@angular/core';
import { RouterModule, Routes, PreloadAllModules } from '@angular/router';

import { AppAuthGuard } from './core/guards/authguard';
import { StatisticComponent } from '@app/modules/statistic/statistic.component';
import { AccessRoles } from './core/services/administrator/models/accessRoles';
import { LegalNoticeComponent } from '@app/modules/legal-notice/legal-notice.component';
import { CguComponent } from '@app/modules/cgu/cgu.component';
import { FaqComponent } from '@app/modules/faq/faq.component';
import { AppInternalSupportGuard } from './core/guards/app-internal-support-guard';

const routes: Routes = [
  { path: 'home', loadChildren: () => import('@app/modules/home/home.module').then(m => m.HomeModule) },
  { path: 'users', loadChildren: () => import('@app/modules/users/users.module').then(m => m.UsersModule) },
  { path: 'customerrequests', canActivate: [AppInternalSupportGuard], loadChildren: () => import('@app/modules/customer-requests/customer-requests.module').then(m => m.CustomerRequestsModule) },
  { path: 'administrators', loadChildren: () => import('@app/modules/administrators/administrators.module').then(m => m.AdministratorsModule) },
  { path: 'accessmedias', loadChildren: () => import('@app/modules/access-medias/access-medias.module').then(m => m.AccessMediasModule) },
  { path: 'error/:code', loadChildren: () => import('@app/modules/errors/errors.module').then(m => m.ErrorsModule) },
  { path: 'statistic', component: StatisticComponent, canActivate: [AppAuthGuard], data: { role: [
    AccessRoles.ROLE_SUPER_ADMIN, AccessRoles.ROLE_ADMIN, AccessRoles.ROLE_STATISTIC] }  },
  { path: 'devices', loadChildren: () => import('@app/modules/devices/devices.module').then(m => m.DevicesModule) },
  { path: 'tariffication', loadChildren: () => import('@app/modules/tariffication/tariffication.module').then(m => m.TarifficationModule) },
  { path: 'cgu', component: CguComponent },
  { path: 'faq', component: FaqComponent },
  { path: 'legal-notice', component: LegalNoticeComponent },
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: '**', redirectTo: '/error/404' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })],
  exports: [RouterModule],
  providers: [AppAuthGuard]
})
export class AppRoutingModule {}
