import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChecklistEmptyComponent } from './checklist-empty.component';

describe('ChecklistEmptyComponent', () => {
  let component: ChecklistEmptyComponent;
  let fixture: ComponentFixture<ChecklistEmptyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChecklistEmptyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChecklistEmptyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
