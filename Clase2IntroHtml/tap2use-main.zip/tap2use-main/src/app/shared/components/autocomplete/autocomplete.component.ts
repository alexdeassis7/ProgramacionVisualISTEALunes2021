import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';
import { Observable, Subject } from 'rxjs';
import { debounceTime, map, switchMap, takeUntil } from 'rxjs/operators';

@Component({
  selector: 'ap-autocomplete',
  templateUrl: './autocomplete.component.html',
  styleUrls: ['./autocomplete.component.css']
})
export class AutocompleteComponent extends AbstractOnDestroyComponent implements OnInit {

  searching: string;
  state: 'INIT' | 'LOADING' | 'EMPTY' | 'DONE' = 'INIT';
  options: Entry<any, string>[];

  @Input() value: Entry<any, string>;
  @Input() minSearch: number = 3;
  @Input() placeholder: string = '';
  @Input() readonly: boolean = true;

  @Input()
  get autocomplete(): (search: string) => Observable<Map<any, string>> { return this._autocomplete; }
  set autocomplete(autocomplete: (search: string) => Observable<Map<any, string>>) {
    // Reset component when autocomplete function change
    this._autocomplete = autocomplete;
    this.searching = '';
    this.options = [];
    this.state = 'INIT';
    this.computeState();
  }
  _autocomplete: (search: string) => Observable<Map<any, string>>;

  @Output() choice = new EventEmitter<Entry<any, string>>();
  @Output() clear = new EventEmitter<void>();


  private changeEvent = new Subject<string>();
  private loading: boolean = false;

  constructor() {
    super();
  }

  ngOnInit(): void {
    this.changeEvent.pipe(
      takeUntil(this.unsubscribe),
      debounceTime(1000),
      switchMap(search => {
        return this._autocomplete(search);
      }),
      map(options => {
        return Array.from(options.entries()).map(option => {
          return new Entry<string, string>(option[0], option[1])
        });
      }),
    ).subscribe(entries => {
      this.options = entries;
      this.loading = false; 
      this.computeState();
    })
  }

  onSearch(str: string): void {
    this.searching = str;
    this.loading = true;
    this.computeState();
    if(str && str.length > (this.minSearch - 1)) {
      this.changeEvent.next(str);
    }
  }

  onClear() {
    this.value = null;
    this.clear.emit();
  }

  onSelect(entry: Entry<string, string>) {
    this.value = entry;
    this.choice.emit(entry);
  }

  private computeState() {
    if (!this.searching || (this.searching && this.searching.length < this.minSearch)) {
      return this.state = 'INIT';
    } 
    if (this.loading) {
      return this.state = 'LOADING';
    }      
    if (this.options && this.options.length > 0) {
      return this.state = 'DONE';
    }     
    this.state = 'EMPTY';
  }  
}

export class Entry<K, V> {
  key: K;
  value: V;

  constructor(key: K, value: V) {
    this.key = key;
    this.value = value;
  }

}