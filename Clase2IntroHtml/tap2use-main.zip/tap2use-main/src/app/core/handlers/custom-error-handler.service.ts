import { Injectable, ErrorHandler, Injector } from '@angular/core';
import { Router } from '@angular/router';
import { throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomErrorHandlerService implements ErrorHandler {
  constructor(private injector: Injector) {}

  handleError(error) {
    const router = this.injector.get(Router);

    // Handle Client Error (Angular Error, ReferenceError...)
    router.navigate(['/error', 500]);

    // Log the error anyway
    console.error(error.stack);
    //console.error(error.stack);

    return throwError(error);
  }
}
