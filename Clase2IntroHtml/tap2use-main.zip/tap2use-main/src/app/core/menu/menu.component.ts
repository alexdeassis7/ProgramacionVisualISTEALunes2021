import { AfterViewInit } from '@angular/core';
import { Component, ElementRef, OnInit, Renderer2, ViewChild } from '@angular/core';
import { environment } from '@env/environment';
import { KeycloakService } from 'keycloak-angular';
import { ToastrService } from 'ngx-toastr';
import { takeUntil } from 'rxjs/operators';
import { AbstractOnDestroyComponent } from '../abstract-on-destroy-component/abstract-on-destroy-component';
import { AdministratorService } from '../services/administrator/administrator.service';
import { AccessRoles } from '../services/administrator/models/accessRoles';
import { UserAdmin } from '../services/administrator/models/userAdmin';
import { CustomerRequestService } from '../services/customer-request/customer-request.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent extends AbstractOnDestroyComponent implements OnInit, AfterViewInit {
  userAdmin: UserAdmin;
  keycloakId: string;
  accessRoles = AccessRoles;
  refreshRequestsBadge = true;

  @ViewChild('t2uSupportMenu') private t2uSupportMenu: ElementRef;

  constructor(private keycloakService: KeycloakService,
    private adminsitratorService: AdministratorService,
    public customerRequestService: CustomerRequestService,
    private readonly toastr: ToastrService,
    private renderer2: Renderer2, private el: ElementRef
  ) {
    super();
  }

  ngOnInit() {
    window.onload(null);
    this.keycloakId = this.keycloakService.getKeycloakInstance().subject;
    this.adminsitratorService.getAdministratorByKCId(this.keycloakId)
        .pipe( takeUntil(this.unsubscribe) )
        .subscribe(userAdmin => {
            this.userAdmin = userAdmin;
          }, err => {
            this.toastr.error(err);
          });
  }

  ngAfterViewInit() {
    this.initBadgesMenu();
    if (!environment.defaultValue.customerRequest.t2uSupport) {
      this.renderer2.removeChild(this.el.nativeElement, this.t2uSupportMenu.nativeElement);
    }
  }

  private initBadgesMenu() {
    this.customerRequestService.refreshRequestCustomerCounter();
  }
}
