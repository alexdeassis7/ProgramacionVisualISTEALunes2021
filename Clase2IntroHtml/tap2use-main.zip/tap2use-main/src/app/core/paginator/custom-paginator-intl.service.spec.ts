import { TestBed } from '@angular/core/testing';

import { CustomPaginatorIntl } from './custom-paginator-intl.service';

describe('CustomPaginatorIntl', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CustomPaginatorIntl = TestBed.get(CustomPaginatorIntl);
    expect(service).toBeTruthy();
  });
});
