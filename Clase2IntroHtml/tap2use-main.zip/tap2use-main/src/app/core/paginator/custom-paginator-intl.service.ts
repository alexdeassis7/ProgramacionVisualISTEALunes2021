import { Injectable, OnDestroy } from '@angular/core';
import { MatPaginatorIntl } from '@angular/material/paginator';
import { TranslateService } from '@ngx-translate/core';
import { takeUntil } from 'rxjs/operators';
import { AbstractOnDestroyComponent } from '../abstract-on-destroy-component/abstract-on-destroy-component';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomPaginatorIntl extends MatPaginatorIntl implements OnDestroy {
  protected unsubscribe: Subject<any> = new Subject();
  ofElement = 'of';

  constructor(private translate: TranslateService) {
    super();
    this.translate.get('PAGINATOR.ITEMS_PER_PAGE')
      .pipe( takeUntil(this.unsubscribe) )
      .subscribe((res: string) => {
        this.itemsPerPageLabel = res;
      });
    this.translate.get('PAGINATOR.NEXT_PAGE')
      .pipe( takeUntil(this.unsubscribe) )
      .subscribe((res: string) => {
        this.nextPageLabel = res;
      });
    this.translate.get('PAGINATOR.PREVIOUS_PAGE')
      .pipe( takeUntil(this.unsubscribe) )
      .subscribe((res: string) => {
        this.previousPageLabel = res;
      });
    this.translate.get('PAGINATOR.OF_ELEMENT')
      .pipe( takeUntil(this.unsubscribe) )
      .subscribe((res: string) => {
        this.ofElement = res;
      });
  }

  getRangeLabel = (page: number, pageSize: number, length: number) => {
    const max = page * pageSize + pageSize;
    return page * pageSize + 1 + ' - ' + (length > max ? max : length) + ' ' + this.ofElement + ' ' + length;
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
