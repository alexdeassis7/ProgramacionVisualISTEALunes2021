export interface UserEvent {
    actorReference: string;
    actorType: string;
    actor:string;
    creationDate: Date;
    localDate:string;
    eventType: string;
    data: Object;
}

