

export interface ActionHistory {
    date?: Date;
    type?: string;
    author?: string;
}