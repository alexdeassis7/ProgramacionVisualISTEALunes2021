import { Injectable } from '@angular/core';
import { KeycloakService } from 'keycloak-angular';

@Injectable({
  providedIn: 'root'
})
export class UtilService {
  constructor(private keycloakService: KeycloakService) {}

  downloadFileStream(blob: any, fileName: String, fileType: string) {
    const fullName = fileName + '.' + fileType;
    const url = window.URL.createObjectURL(blob);
    if (navigator.msSaveOrOpenBlob) {
      navigator.msSaveBlob(blob, fullName);
    } else {
      const link = document.createElement('a');
      link.download = fullName;
      link.style.display = 'none';
      link.href = url;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
    window.URL.revokeObjectURL(url);
  }

  getDefaultLanguage() {
    let defaultLanguage: string = this.getVariable('language', 'session');
    if (!defaultLanguage) {
      this.keycloakService.loadUserProfile().then(
        (userProfile: CustomKeycloakProfile) => defaultLanguage = userProfile.attributes.locale[0]);
    }
    return defaultLanguage;
  }

  getVariable(variableName: string, type?: TypeStorage) {
    const typeStorage = type === 'session' ? sessionStorage : localStorage;
    return typeStorage.getItem(variableName);
  }

  persistInBrowser(key: string, value: string, type?: TypeStorage) {
    const typeStorage = type === 'session' ? sessionStorage : localStorage;
    typeStorage.setItem(key, value);
  }

}

declare interface CustomKeycloakProfile extends Keycloak.KeycloakProfile {
  attributes: {locale: string[]};
}

declare type TypeStorage = 'session' | 'local';
