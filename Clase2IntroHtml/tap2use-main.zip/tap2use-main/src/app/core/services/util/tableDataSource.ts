import { BehaviorSubject, Observable, of, Subject } from 'rxjs';
import { finalize, takeUntil } from 'rxjs/operators';
import { CollectionViewer, DataSource } from '@angular/cdk/collections';
import { AbstractOnDestroyComponent } from '@app/core/abstract-on-destroy-component/abstract-on-destroy-component';

export class TableDataSource<T> extends AbstractOnDestroyComponent implements DataSource<T> {
  private anySubject = new BehaviorSubject<T[]>([]);
  private loadingSubject = new BehaviorSubject<boolean>(false);

  public loading$ = this.loadingSubject.asObservable();

  constructor() {
    super();
  }

  connect(collectionViewer: CollectionViewer): Observable<T[]> {
    return this.anySubject.asObservable();
  }

  disconnect(collectionViewer: CollectionViewer): void {
    this.anySubject.complete();
    this.loadingSubject.complete();
  }

  loadData(dataService: Observable<any>) {
    this.loadingSubject.next(true);
    const returnSubject = new Subject<any>();
    dataService.pipe(finalize(() => this.loadingSubject.next(false)))
    .pipe( takeUntil(this.unsubscribe) )
    .subscribe(
      (resp: any) => {
        this.anySubject.next(resp.content == null ? [] : resp.content);
        returnSubject.next(resp.totalElements == null ? 0 : resp.totalElements);
      },
      err => {
        this.anySubject.next([]);
        returnSubject.next(-1);
      }
    );

    return returnSubject.asObservable();
  }

  loadDataAccessMedia(dataService: Observable<any>, token: string) {
    this.loadingSubject.next(true);
    const returnSubject = new Subject<any>();
    dataService.pipe(finalize(() => this.loadingSubject.next(false)))
    .pipe( takeUntil(this.unsubscribe) )
    .subscribe(
      (resp: any) => {
      let  data = resp.content.filter(accessMedia => accessMedia.accessMediaType==token);
        this.anySubject.next(resp.content == null ? [] : data);
        returnSubject.next(resp.totalElements == null ? 0 : data.length);
      },
      err => {
        this.anySubject.next([]);
        returnSubject.next(-1);
      }
    );

    return returnSubject.asObservable();
  }

}
