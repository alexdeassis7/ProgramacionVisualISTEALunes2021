export class Product {
  productNumber: number;
  productName: string;
}
