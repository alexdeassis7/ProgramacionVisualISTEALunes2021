import { Fare } from "./fare";
import { Product } from "./product";
import { Tap } from "./tap";

export interface Journey {
  id: string;
  journeyId: string;
  type: JourneyType;
  serviceOperator: string;
  startDate: Date;
  endDate: Date;
  product: Product;
  fare: Fare;
  taps: Tap[];
}


export enum JourneyType {
  OPENPAYMENT,
  PREPAYMENT
}
