export interface Fare {
  tripsQuantity: number;
  amountMoney: number;
  currency: string;
  tariffRule: TariffRule;
}

export enum TariffRule {
  FIXED,
  CONNECTION,
  TIMEFRAME,
  TAP_IN,
  TAP_OUT,
  ADJUSTMENT,
  FEE_CAPPING,
  ORIGIN_DESTINATION
}
