export interface Location {
  vehicleReference: string;
  station: string;
  terminusStation: string;
  line: string;
  direction: Direction;
  company: string;
  transportMode: TransportMode;
}

export enum Direction {
  GOING,
  RETURN
}

export enum TransportMode {
  TRAM = 'TRAM',
  SUBWAY = 'SUBWAY',
  RAIL = 'RAIL',
  BUS = 'BUS',
  FERRY = 'FERRY',
  CABLE_TRAM = 'CABLE_TRAM',
  AERIAL_LIFT = 'AERIAL_LIFT',
  FUNICULAE = 'FUNICULAE',
  TROLLEYBUS = 'TROLLEYBUS',
  MONORAIL = 'MONORAIL'
}
