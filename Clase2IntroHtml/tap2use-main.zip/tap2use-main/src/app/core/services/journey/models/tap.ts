import { Location } from './location';
import { Fare } from './fare';
import { Product } from './product';

export interface Tap {
  transactionId: string;
  issueDate: Date;
  type: Tap.TypeEnum;

  identificationToken: string;
  contractId: string;
  passengerCount: number;
  product: Product;
  refunded: boolean;
  location: Location;
  fare: Fare;
}

export namespace Tap {
  export type TypeEnum = 'TAP | TAP-PR | TAP-CONTROL';
  export const TypeEnum = {
    VALIDATION: 'TAP' as TypeEnum,
    PR: 'TAP-PR' as TypeEnum,
    CONTROL: 'TAP-CONTROL' as TypeEnum,
  };
}
