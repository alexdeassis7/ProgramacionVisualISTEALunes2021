import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { TranslateService } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { environment } from '@env/environment';
import { AdministratorService } from '../administrator/administrator.service';
import { Journey } from './models/journey';
import { Page } from '../commons/page';
import * as moment from 'moment';

@Injectable({
  providedIn: 'root'
})
export class JourneyService {

  private baseUrl: string;

  constructor(private httpClient: HttpClient, protected translate: TranslateService, protected administratorService: AdministratorService) {
    this.baseUrl = environment.api.financialEngine;
  }

  getJourneys(accessMediaIdentificationTokens: string[] = [], pageNumber: number = 0, pageSize : number = 10, since: Date = null, until: Date = null, sortElement: string = 'startDate', sortOrder: 'ASC' | 'DESC' = 'DESC'): Observable<Page<Journey>> {
    if (accessMediaIdentificationTokens.length === 0) {
      return of({ content: [] });
    }

    let params = new HttpParams()
      .set('sort', sortElement + ',' + sortOrder)
      .set('page', pageNumber.toString())
      .set('size', pageSize.toString());

    if (since) {
      params = params.set('fromStartDate', moment(since).startOf('day').toISOString());
    }

    if (until) {
      params = params.set('toStartDate', moment(until).endOf('day').toISOString());
    }

    accessMediaIdentificationTokens.forEach(token => {
      params = params.append('accessMediaIdentificationTokens', token);
    });

    return this.httpClient.get<Page<Journey>>(this.baseUrl + '/api/share-data-manager/v1/journeys', { params});
  }
}
