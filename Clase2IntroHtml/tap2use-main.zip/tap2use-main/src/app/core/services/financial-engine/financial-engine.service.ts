import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BaseService } from '@app/core/services/base.service';
import { environment } from '@env/environment';
import { TranslateService } from '@ngx-translate/core';
import * as moment from 'moment';
import { ToastrService } from 'ngx-toastr';
import { Observable, of } from 'rxjs';
import { map, pluck } from 'rxjs/operators';
import { Page } from '../commons/page';
import { PageSettlement } from './models/pageSettlement';
import { SettlementItem } from './models/settlementItem';
import { SettlementSummary } from './models/settlementSummary';
import { SipsRequest } from './models/sipsRequest';

@Injectable({
  providedIn: 'root'
})
export class FinancialEngineService extends BaseService {
  constructor(
    private httpClient: HttpClient,
    protected toastr: ToastrService,
    protected translate: TranslateService
  ) {
    super(toastr, translate);
  }

  /**
   * Get all access media settlements by filters
   *
   * @param accessMediaReferences tableau des références de support en string[]
   * @param since since de type Date
   * @param until until de type Date
   * @param sortOrder ordre du tri en string
   * @param sortElement element à trier en string
   * @param pageNumber numéro de la page en number
   * @param pageSize taille de la page en number
   */
  findSettlementsByAccessMedias(accessMediaReferences: string[], since: Date, until: Date,
                                sortOrder: string, sortElement: string, pageNumber = 0, pageSize = 10000): Observable<PageSettlement> {

    if (!accessMediaReferences || accessMediaReferences.length === 0) {
      return of({
        content : [],
        number: 0,
        size: 0,
        totalElements: 0,
        totalPages: 0
      });
    }

    let params = new HttpParams();

    if (accessMediaReferences) {
      accessMediaReferences.forEach((element) => {
            params = params.append('accessMediaReference', <any>element);
        });
    }
    if (since) {
      params = params.set('since', moment(since).format('YYYY-MM-DD'));
    }
    if (until) {
      params = params.set('until', moment(until).format('YYYY-MM-DD'));
    }
    if (Number.isInteger(pageNumber)) {
      params = params.set('page', pageNumber.toString());
    }
    if (Number.isInteger(pageSize)) {
      params = params.set('size', pageSize.toString());
    }
    params = params.set('sort', sortElement + ',' + sortOrder);

    return this.httpClient
      .get<PageSettlement>(environment.api.financialEngine + '/v1/settlements', {
        params,
        headers: new HttpHeaders({
          'x-apikey': environment.api.apikey
        })
      });
  }

  /**
   * Find settlements summary by transaction ids
   *
   * @param transactionId Filter by a list of transactionId
   */
  public findSettlementsSummaryByTransactionIds(transactionIds: string[]): Observable<Page<SettlementSummary>> {
    if (!transactionIds || transactionIds.length === 0) {
      return of({ content : [], number: 0, size: 0, totalElements: 0, totalPages: 0 });
    }
    let params = new HttpParams();
    transactionIds.forEach((element) => {
      params = params.append('transactionId', <any>element);
    });

    return this.httpClient
          .get<Page<SettlementSummary>>(`${environment.api.financialEngine}/api/invoicing-manager/v1/settlements`, { params });
  }

  generateSipsRequest(transportOfferOrigin: string, transportOfferReference: string, templateName: string,
                                        orderChannel: string, locale: string, merchantSiteCallback: string): Observable<SipsRequest> {
    const params = new HttpParams()
      .set('transportOfferOrigin', transportOfferOrigin)
      .set('transportOfferReference', transportOfferReference)
      .set('templateName', templateName)
      .set('orderChannel', orderChannel)
      .set('locale', locale)
      .set('merchantSiteCallback', merchantSiteCallback);

    return this.httpClient
      .get<SipsRequest>(environment.api.financialEngine + '/v1/payments/settle-debt/generate-sips-link', {
        params,
        headers: new HttpHeaders({
          'x-apikey': environment.api.apikey
        })
      });
  }


  generateSipsRequestToRefund(transactionIds: string[], mobilityAccountId: number, templateName: string, locale: string, merchantSiteCallback: string): Observable<SipsRequest> {
    let params = new HttpParams()
      .set('templateName', templateName)
      .set('locale', locale)
      .set('merchantSiteCallback', merchantSiteCallback);

    if(mobilityAccountId) {
      params = params.set('mobilityAccountId', mobilityAccountId + '');
    }

    params = transactionIds.reduce((acc: HttpParams, transactionId: string) => acc.append('transactionId', transactionId), params);

    return this.httpClient.get<SipsRequest>(environment.api.financialEngine + '/v1/payments/refund/generate-sips-link', { params });
  }

  findSettlementStatus(transactionIds: string[]): Observable<String[]> {
    let params = new HttpParams()
      .set('page', '0')
      .set('size', '500');

    params = transactionIds.reduce((acc: HttpParams, transactionId: string) => acc.append('transactionId', transactionId), params);

    return this.httpClient.get<SipsRequest>(environment.api.financialEngine + '/api/invoicing-manager/v1/settlements', { params }).pipe(
      pluck('content'),
      map((settlements: any) => {
        return settlements.map(s => s.cause);
      })
    );
  }


  findSettlement(reference: string): Observable<SettlementSummary> {
    return this.httpClient.get<SettlementSummary>(environment.api.financialEngine + '/api/invoicing-manager/v1/settlements/reference/' + reference);
  }
  

  findSettlementItems(transactionIds: string[]): Observable<SettlementItem[]> {
    let params = new HttpParams()
      .set('page', '0')
      .set('size', '500');

    transactionIds.forEach((transactionId: string) => {
      params = params.append('transactionId', transactionId);
    });

    return this.httpClient.get<SipsRequest>(environment.api.financialEngine + '/api/invoicing-manager/v1/settlements', { params }).pipe(
      pluck('content'),
      map((settlements: any) => {
        return settlements.flatMap(s => s.items).filter((i: SettlementItem) => transactionIds.includes(i.transactionId));
      })
    );
  }

  /**
   * To refund some taps to an accessMedia for an optional user.
   *
   * @param accessMediaReference
   * @param accessMediaType
   * @param transactionIds taps to refund
   * @param mobilityAccountId user (optional)
   */
  refund(accessMediaReference: string, accessMediaType: string, transactionIds: string[], mobilityAccountId: number = null): Observable<any> {
    const data = { accessMediaReference, accessMediaType, mobilityAccountId, transactionIds };
    return this.httpClient.post<any>(environment.api.financialEngine + '/v1/payments/refund', data);
  }


  /**
   * Read access media state by filters
   * Read access media state in the Access Control Manager by filters
   * @param actorReference actorReference
   * @param actorType actorType
   * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
   * @param reportProgress flag to report request and response progress.
   */
  public readSearchUsingGET( currencyCode?: string, customerLanguage?: string, normalReturnUrl?: string, orderChannel?: string, templateName?: string): Observable<Array<any>> {
      let queryParameters = new HttpParams();

      if (currencyCode !== undefined && currencyCode !== null) {
          queryParameters = queryParameters.set('currencyCode', <any>currencyCode);
      }
      if (customerLanguage !== undefined && customerLanguage !== null) {
          queryParameters = queryParameters.set('customerLanguage', <any>customerLanguage);
      }
      if (normalReturnUrl !== undefined && normalReturnUrl !== null) {
          queryParameters = queryParameters.set('normalReturnUrl', <any>normalReturnUrl);
      }
      if (orderChannel !== undefined && orderChannel !== null) {
          queryParameters = queryParameters.set('orderChannel', <any>orderChannel);
      }
      if (templateName !== undefined && templateName !== null) {
          queryParameters = queryParameters.set('templateName', <any>templateName);
      }

      return this.httpClient.get<Array<any>>(environment.api.financialEngine + '/api/payment-gateway/v1/sips/parameters/search', { params: queryParameters });
  }

}
