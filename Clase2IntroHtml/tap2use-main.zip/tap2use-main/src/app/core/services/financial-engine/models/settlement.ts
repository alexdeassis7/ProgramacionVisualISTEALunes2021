export interface Settlement {
    transportOfferId?: string;
    reference?: string;
    accessMediaReference?: string;
    accessMediaIdentificationToken?: string;
    status?: string;
    cause?: string;
    applicationIdentification?: string;
    createdAt?: Date;
    debtAmount?: number;
    paidAmount?: number;
    origin: String;
    serviceOperator: String;
    late: any;
    isLate: boolean;
    transportEvents: Array<SettlementDetail>;
}

export interface SettlementDetail {
    transactionId?: string;
    issueDate?: Date;
    amount?: number;
    description?: string;
    locationInfo?: LocationInfo;
}

export interface LocationInfo {
    transportMode?: string;
    lineDescription?: string;
    vehicleNumber?: string;
    stationDescription?: string;
}
