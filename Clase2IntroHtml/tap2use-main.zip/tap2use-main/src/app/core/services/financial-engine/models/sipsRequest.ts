export interface SipsRequest {
    url: string;
    data: string;
    interfaceVersion?: string;
    encode?: string;
    seal: string;
}