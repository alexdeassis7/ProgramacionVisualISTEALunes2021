export interface SettlementItem {
  amount: number;
  issueDate: Date;
  lineDescription?: string;
  passengerQty?: string;
  transactionId?: string;
  transportMode?: string;
  vehicleNumber?: string;
  stationDescription?: string
}