import { AccessMediaHolder } from './accessMediaHolder';

export interface AccessMedia {
  accessMediaCreationDate?: Date;
  accessMediaExpirationDate?: Date;
  accessMediaHolder?: AccessMediaHolder;
  accessMediaId: number;
  accessMediaReference: string;
  accessMediaDescription: string;
  paymentAccountReference: string;
  accessMediaStatus: AccessMedia.AccessMediaStatusEnum;
  accessMediaType: string;
  accessMediaIdentificationToken: string;
}

export namespace AccessMedia {
  export type AccessMediaStatusEnum = 'INITIALIZED' | 'ACTIVE' | 'BLOCKED' | 'REVOKED' | 'CANCELLED';
  export const AccessMediaStatusEnum = {
      INITIALIZED: 'INITIALIZED' as AccessMediaStatusEnum,
      ACTIVE: 'ACTIVE' as AccessMediaStatusEnum,
      BLOCKED: 'BLOCKED' as AccessMediaStatusEnum,
      REVOKED: 'REVOKED' as AccessMediaStatusEnum,
      CANCELLED: 'CANCELLED' as AccessMediaStatusEnum
  };
}
