import { Injectable } from '@angular/core';
import { BaseService } from '@app/core/services/base.service';
import { HttpClient, HttpParams } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { Observable } from 'rxjs';
import { environment } from '@env/environment';
import { AccessMedia } from './models/accessMedia';
import { AdministratorService } from '../administrator/administrator.service';
import { Page } from '../commons/page';

@Injectable({
  providedIn: 'root'
})
export class AccessMediaService extends BaseService {

  private baseUrl: string;

  constructor(
    private httpClient: HttpClient,
    protected toastr: ToastrService,
    protected translate: TranslateService,
    protected administratorService: AdministratorService
  ) {
    super(toastr, translate);
    this.baseUrl = environment.api.mobilityEngine + '/api/access-control-manager/v1';
  }

  findAccessMedias(
    filter,
    sortOrder: 'DESC' | 'ASC',
    sortElement: string,
    pageNumber: number,
    pageSize: number
  ): Observable<Page<AccessMedia>> {

    if (['accessMediaHolderEmailAddress', 'accessMediaHolderLastName', 'accessMediaHolderFirstName'].includes(sortElement)) {
      sortElement = 'accessMediaHolder.' + sortElement;
    }

    const sort = sortElement + ',' + sortOrder.toLowerCase();
    let params = new HttpParams()
      .set('sort', sort)
      .set('page', pageNumber.toString())
      .set('size', pageSize.toString());

    if (filter.referenceFilter) {
      params = params.set('accessMediaReference', filter.referenceFilter);
    }
    if (filter.typeFilter) {
      params = params.set('accessMediaType', filter.typeFilter);
    }
    if (filter.tokenFilter) {
      params = params.set('accessMediaToken', filter.tokenFilter);
    }
    if (filter.holderEmailFilter) {
      params = params.set('accessMediaHolderEmailAddress', filter.holderEmailFilter);
    }
    if (filter.holderLastNameFilter) {
      params = params.set('accessMediaHolderLastName', filter.holderLastNameFilter);
    }
    if (filter.holderFirstNameFilter) {
      params = params.set('accessMediaHolderFirstName', filter.holderFirstNameFilter);
    }
    if (filter.paymentAccountReferenceFilter) {
      params = params.set('paymentAccountReference', filter.paymentAccountReferenceFilter);
    }

    if (filter.accessMediaHolderAccountId) {
      params = params.set('accessMediaHolderAccountId', filter.accessMediaHolderAccountId);
    }

    if (filter.accessMediaStatuses) {
      filter.accessMediaStatuses.forEach((element) => {
        params = params.append('accessMediaStatus', <any>element);
      });
    }

    return this.httpClient.get<Page<AccessMedia>>(this.baseUrl + '/access-medias', { params: params });
  }


  getAccessMediaByByTypeAndReference(type: string, reference: string): Observable<AccessMedia> {
    return this.httpClient.get<AccessMedia>(this.baseUrl + '/types/' + type + '/references/' + reference + '/access-media');
  }

  disEnrollAccessMedia(accessMediaId: number): Observable<void> {
    return this.httpClient.delete<void>(this.baseUrl + '/access-medias/' + accessMediaId + '/holder');
  }

}
