
export interface GenericParameter {
  name: string;
  value: string;
}
