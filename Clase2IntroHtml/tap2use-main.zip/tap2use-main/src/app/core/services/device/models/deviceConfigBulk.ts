
import { DeviceBatchStatus } from './deviceBatchStatus';

export interface DeviceConfigBulk {
  information?: string;
  deviceBatchStatuses?: Array<DeviceBatchStatus>;
}
