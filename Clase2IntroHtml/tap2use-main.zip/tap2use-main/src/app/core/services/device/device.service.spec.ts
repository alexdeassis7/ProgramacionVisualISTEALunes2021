import { TestBed, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { DeviceServiceMock } from './mocks/device.service.mock';

describe('DeviceServiceMock', () => {
  let deviceServiceMock: DeviceServiceMock;
  let httpMock: HttpTestingController;
  const jsonFile = './mocks/pageDeviceMock.json';

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule ],
      providers: [DeviceServiceMock]
    });
    deviceServiceMock = TestBed.get(DeviceServiceMock);
    httpMock = TestBed.get(HttpTestingController);
  });

  it('should be created', inject([DeviceServiceMock], (service: DeviceServiceMock) => {
    expect(service).toBeTruthy();
  }));

  it('should return error if pageDevice request failed', (done) => {
    deviceServiceMock.getDevices(null, null, null, null, null).subscribe((res: any) => {
      expect(res.failure.error.type).toBe('ERROR_LOADING_DEVICES');
      done();
    });
    const pageDeviceRequest = httpMock.expectOne(jsonFile);
    pageDeviceRequest.error(new ErrorEvent('ERROR_LOADING_DEVICES'));
    httpMock.verify();
  });

  it('should successfully get all devices', (done) => {
    deviceServiceMock.getDevices(null, null, null, null, null).subscribe(res => {
      expect(res.content[0].poi).toEqual('35350001');
      expect(res.size).toEqual(20);
      done();
    });
    httpMock.verify();
  });

});
