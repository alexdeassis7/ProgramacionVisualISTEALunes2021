export interface XenturionInfoV3 {
  poiId?: string;
  terminalId?: string;
  schedLastConx?: string;
  parmLastConx?: string;
  statusTeleload?: TeleloadStatus.StateEnum;
  lastConxTeleload?: string;
}
export namespace TeleloadStatus {
  export type StateEnum = 'NOT_UP_TO_DATE' | 'UP_TO_DATE';
  export const StateEnum = {
    NOT_UP_TO_DATE: 'NOT_UP_TO_DATE' as StateEnum,
    UP_TO_DATE: 'UP_TO_DATE' as StateEnum
  };
}
