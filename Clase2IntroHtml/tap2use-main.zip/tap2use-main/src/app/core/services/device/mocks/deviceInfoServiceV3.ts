import { Injectable } from '@angular/core';
import { Observable, of, pipe } from 'rxjs';
import { HttpResponse, HttpEvent } from '@angular/common/http';
import { DeviceInfoV3 } from '../models/deviceInfoV3';
import { delay } from 'rxjs/internal/operators';

@Injectable({
  providedIn: 'root',
})

export class DeviceInfoServiceV3 {

  constructor() {}

  public getDeviceInfoServiceV3(poi: string, observe?: 'body', reportProgress?: boolean): Observable<DeviceInfoV3>;
  public getDeviceInfoServiceV3(poi: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<DeviceInfoV3>>;
  public getDeviceInfoServiceV3(poi: string, observe: any = 'body', reportProgress: boolean = false): Observable<any> {

    // TODO: unmock this once backend is up-to-date
    return of(this.mockDeviceInfoV3Response(poi));
  }

  private mockDeviceInfoV3Response(poi: string): DeviceInfoV3 {
    const deviceInfoV3 = {
      id: '1000',
      modificationDate: new Date('2020-09-10T10:57:22.000+0000'),
      configuration: {
        versionDate: '2020-09-10T10:57:22.000+0000',
        version: '3.1'   // Version of the configuration. Send in DeviceConfig "configVersion" parameter
      },
      deviceInfo: {
        date: '2020-09-10T10:57:22.000+0000',
        deviceModel: 'Yoneo',
        deviceReference: '12345',
        firmwareVersion: '1.2.3',
        metrics: [
          {
            key: 'upTime',            // Time during which the terminal is in operation
            value: '1601913600000'    // in timestamp
          },
          {
            key: 'memoryUsage',    // Usage of memory on the terminal (percentage)
            value: '0.50'
          },
          {
            key: 'diskUsage',    // Usage of disk space on the terminal (percentage)
            value: '0.96'
          },
          {
            key: 'rebootCount',    // Number of reboots on the terminal
            value: '5'
          },
          {
            key: 'cpuUsage',    // Usage of CPU on the terminal (percentage)
            value: '0.85'
          },
          {
            key: 'tapStored',    // Number of TAP stored in the buffer
            value: '16'
          },
          {
            key: 'lastTransmittedTap',    // Date of the last TAP transmission (Ex: "2019-09-04T13:02:59.000Z")
            value: '2019-09-04T13:02:59.000Z'
          },
          {
            key: 'pvId',    // Number of the last pvId used (Ex: 124)
            value: '124'
          },
          {
            key: 'simReference',    // Sim reference (Ex: 124)
            value: '124'
          },
          {
            key: 'status4G',    // 4G status (Ex: OK, KO && '')
            value: undefined
          },
          {
            key: 'network4G',
            value: 'Réseau 4G'
          },
          {
            key: 'GPSStatus',    // GPS status (Ex: OK, KO && '')
            value: 'OK'
          },
          {
            key: 'accessStatus',    // Access status (Ex: OK, KO && '')
            value: 'KO'
          }
        ],
        poi: '00000000',
        serialNumber: '0008192e838d',
        serviceOperator: 'divia',
        simReference: '123456'
      },
      listInformation: {
        lists: [
          {
            size: 1,
            type: 'denyList',             // List type. Ex: "denylist",  "authorizationList"
            version: '20200303-110500'   // Version of the list
          },
          {
            size: 100,
            type: 'authorizationList',    // List type. Ex: "denylist",  "authorizationList"
            version: '20200404-100000'   // Version of the list
          },
          {
            size: 0,
            type: 'denyList',             // List type. Ex: "denylist",  "authorizationList"
            version: '20200404-100000'   // Version of the list
          }
        ]
      },
      locationInfo: {
        amount: '0.0',
        companyReference: '1',
        coordinateLatitude: -0.09,   // 43.5261993408203 Determined by the GPS of the terminal
        coordinateLongitude: 51.505,  // 5.44469976425171 Determined by the GPS of the terminal
        corridorReference: '240',
        directionType: '1',
        lineReference: '1',
        operatorReference: '1',
        placeReference: '888',
        stageReference: '1',
        stationReference: '1',
        ticketReference: '1',
        zoneReference: '1'
      }
    };

    return deviceInfoV3;
  }

}


