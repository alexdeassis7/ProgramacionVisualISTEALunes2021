import { Device } from '../device';

export interface DeviceFilter {
    activity?: string;
    block?: string;
    causeBlock?: string;
    configuration?: string;
    dateConfigurationVersion?: Date;
    dateLastConnexion?: Date;
    dateLastTap?: Date;
    deviceModel?: string;
    deviceReference?: string;
    fonction?: string;
    hardware?: string;
    installationType?: string;
    lineReference?: string;
    placeReference?: string;
    poi?: string;
    serialNumber?: string;
    companyReference?: string;
    simReference?: string;
    sinceConfigurationVersion?: Date;
    sinceLastConnexion?: Date;
    sinceLastTap?: Date;
    stageReference?: string;
    stationReference?: string;
    system?: string;
    untilConfigurationVersion?: Date;
    untilLastConnexion?: Date;
    untilLastTap?: Date;
    version?: string;
}

export interface Paginated {
    content: Device[];
    totalElements: number;
}
