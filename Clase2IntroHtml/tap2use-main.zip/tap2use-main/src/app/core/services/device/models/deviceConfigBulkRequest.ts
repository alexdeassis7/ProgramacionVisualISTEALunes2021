
import { FieldContainer } from './fieldContainer';

export interface DeviceConfigBulkRequest {
  pois?: Array<string>;
  fieldValue?: FieldContainer;
}
