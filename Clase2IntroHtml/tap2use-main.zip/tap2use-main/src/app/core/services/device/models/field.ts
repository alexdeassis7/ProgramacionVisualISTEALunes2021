export interface Field {
  description?: string;
  field?: string;
  pathValues?: Array<string>;
}
