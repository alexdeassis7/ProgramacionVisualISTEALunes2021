
import { FieldContainer } from './fieldContainer';

export interface DeviceConfigFlatV2 {
  id?: string;
  fields?: Array<FieldContainer>;
}
