export default
[
  {
    "id": "1",
    "name": "Validation",
    "configurationFile": {
      "connectivity": {
        "bridge": "off",
        "language": "FR",
        "mode": "tap",
        "mode3g": "off"
      },
      "listApplication": [
        {
          "applicationName": "tapCollector",
          "parameters": []
        }
      ],
      "listParameter": [
        {
          "paramName": "configVersion",
          "paramValue": "0"
        }
      ],
      "listReference": [],
      "log": {
        "level": "INFO"
      },
      "terminal": {},
      "validator": {}
    }
  },
  {
    "id": "2",
    "name": "Contrôle",
    "configurationFile": {
      "connectivity": {
        "bridge": "off",
        "language": "FR",
        "mode": "control",
        "mode3g": "off"
      },
      "listApplication": [
        {
          "applicationName": "control",
          "parameters": []
        }
      ],
      "listParameter": [
        {
          "paramName": "configVersion",
          "paramValue": "0"
        }
      ],
      "listReference": [],
      "log": {
        "level": "INFO"
      },
      "terminal": {},
      "validator": {}
    }
  }
]
