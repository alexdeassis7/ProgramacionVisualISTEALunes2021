
 // TODO: Generate this with swagger-codegen once the backend is finalized.

 export interface DeviceV2 {
  poi: string;
  state: State;
  configuration: Configuration;
}

interface State {
  serialNumber: string;
  deviceModel: string;
  simReference: string;
}

interface Configuration {
  terminal: Terminal;
  parameters: Parameters;
}

interface Terminal {
  deviceReference: string;
  serviceOperator: string;
}

interface Parameters {
  function: string;
  installationType: string;
}
