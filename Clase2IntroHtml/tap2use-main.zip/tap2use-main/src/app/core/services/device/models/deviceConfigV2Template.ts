import { ConfigurationFileV2 } from './configurationFileV2';


/**
 * Data related to device config V2 template
 */
export interface DeviceConfigV2Template {
  name?: string;
  id?: string;
  configurationFile?: ConfigurationFileV2;
}
