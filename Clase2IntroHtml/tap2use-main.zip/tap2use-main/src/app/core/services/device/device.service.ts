import { UtilService } from './../util/util.service';
import { GenericParameter } from './models/list/genericParameter';
import { HttpClient, HttpEvent, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '@env/environment';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Page } from '../commons/page';
import { Configuration } from '../configuration';
import { BlockUnblockTerminalInfo } from './models/blocking/blockUnblockTerminalInfo';
import { DeviceConfigBulk } from './models/deviceConfigBulk';
import { DeviceConfigBulkRequest } from './models/deviceConfigBulkRequest';
import { DeviceConfigFlatV2 } from './models/deviceConfigFlatV2';
import { DeviceConfigurationV2 } from './models/deviceConfigurationV2';
import { DeviceConfigV2Template } from './models/deviceConfigV2Template';
import { DeviceInfoV3 } from './models/deviceInfoV3';
import { Device } from './models/list/device';
import { DeviceBatchResults } from './models/list/deviceBatchResults';
import { DeviceFilter } from './models/list/deviceFilter';
import { XenturionInfoV3 } from './models/xenturionInfoV3';

@Injectable({
  providedIn: 'root',
})
export class DeviceService {
  private configuration = new Configuration();
  private defaultHeaders = new HttpHeaders();
  private basePath = environment.api.deviceEngine;

  constructor(private httpClient: HttpClient, private utilService: UtilService) {}

  public getDeviceInfoV3(poi: string, observe?: 'body', reportProgress?: boolean): Observable<DeviceInfoV3>;
  public getDeviceInfoV3(poi: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<DeviceInfoV3>>;
  public getDeviceInfoV3(poi: string, observe: any = 'body', reportProgress: boolean = false): Observable<any> {

    return this.httpClient.get<DeviceInfoV3>(`${this.basePath}/api/device-configuration-manager/v3/devicesInfo/${poi}`, {
      withCredentials: this.configuration.withCredentials,
      headers: this.defaultHeaders,
      observe,
      reportProgress
    }).pipe(catchError(() => of(null)));
  }

  public getDeviceConfigV2(poi: string, observe?: 'body', reportProgress?: boolean): Observable<DeviceConfigurationV2>;
  public getDeviceConfigV2(poi: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<DeviceConfigurationV2>>;
  public getDeviceConfigV2(poi: string, observe: any = 'body', reportProgress: boolean = false): Observable<any> {

    return this.httpClient.get<DeviceConfigurationV2>(`${this.basePath}/api/device-configuration-manager/v2/devicesConfig/${poi}`, {
      withCredentials: this.configuration.withCredentials,
      headers: this.defaultHeaders,
      observe,
      reportProgress
    }).pipe(catchError(() => of(null)));
  }

  public getDeviceConfigFlatV2(poi: string, observe?: 'body', reportProgress?: boolean): Observable<DeviceConfigFlatV2>;
  public getDeviceConfigFlatV2(poi: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<DeviceConfigFlatV2>>;
  public getDeviceConfigFlatV2(poi: string, observe: any = 'body', reportProgress: boolean = false): Observable<any> {

    return this.httpClient.get<DeviceConfigurationV2>(`${this.basePath}/api/device-configuration-manager/v2/devicesConfig/flat/${poi}`, {
      withCredentials: this.configuration.withCredentials,
      headers: this.defaultHeaders,
      observe,
      reportProgress
    }).pipe(catchError(() => of(null)));
  }

  public patchDeviceConfigBulkV2(deviceConfigBulkRequest: DeviceConfigBulkRequest, observe?: 'body', reportProgress?: boolean): Observable<DeviceConfigBulk>;
  public patchDeviceConfigBulkV2(deviceConfigBulkRequest: DeviceConfigBulkRequest, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<DeviceConfigBulk>>;
  public patchDeviceConfigBulkV2(deviceConfigBulkRequest: DeviceConfigBulkRequest, observe: any = 'body', reportProgress: boolean = false): Observable<any> {

    if (!deviceConfigBulkRequest) {
      throw new Error('Required parameter deviceConfigBulkRequest was null or undefined when calling patchDeviceConfigBulkV2.');
    }

    let headers = this.defaultHeaders;

    const httpHeaderAcceptSelected = this.configuration.selectHeaderAccept(['application/json']);
    if (httpHeaderAcceptSelected !== undefined) {
      headers = headers.set('Accept', httpHeaderAcceptSelected);
    }

    const httpContentTypeSelected = this.configuration.selectHeaderContentType(['application/json']);
    if (httpContentTypeSelected !== undefined) {
      headers = headers.set('Content-Type', httpContentTypeSelected);
    }

    return this.httpClient.patch<DeviceConfigBulk>(`${this.basePath}/api/device-configuration-manager/v2/devicesConfig/_bulk`,
      deviceConfigBulkRequest,
      {
        withCredentials: this.configuration.withCredentials,
        headers: this.defaultHeaders,
        observe,
        reportProgress
      }
    ).pipe(catchError(() => of(null)));
  }

  public getXenturionInfoV3(poi: string, observe?: 'body', reportProgress?: boolean): Observable<XenturionInfoV3>;
  public getXenturionInfoV3(poi: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<XenturionInfoV3>>;
  public getXenturionInfoV3(poi: string, observe: any = 'body', reportProgress: boolean = false): Observable<any> {

    return this.httpClient.get<XenturionInfoV3>(`${this.basePath}/api/device-configuration-manager/v3/devicesInfo/${poi}/xenturion`, {
      withCredentials: this.configuration.withCredentials,
      headers: this.defaultHeaders,
      observe,
      reportProgress
    }).pipe(catchError(() => of(null)));
  }

  /**
   * Get All Devices by filters
   * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
   * @param reportProgress flag to report request and response progress.
   */
  public getDevices(filter: DeviceFilter, sortOrder: string, sortElement: string, pageNumber: number, pageSize: number): Observable<Page<Device>>{

    let params = new HttpParams();

    if (Number.isInteger(pageNumber) && Number.isInteger(pageSize)) {
      params = params.set('page', pageNumber.toString()).set('size', pageSize.toString());
    }

    if (filter) {
      params = this.initHttpParamsWithDeviceFilter(filter, params);
    }

    params = this.setParamsWithCompanyRef(params);
    params = params.set('sort', sortElement + ',' + sortOrder);

    let headers = this.defaultHeaders;
    // to determine the Accept header
    const httpHeaderAccepts: string[] = ['application/json'];
    const httpHeaderAcceptSelected: string | undefined = this.configuration.selectHeaderAccept(httpHeaderAccepts);

    if (httpHeaderAcceptSelected !== undefined) {
      headers = headers.set('Accept', httpHeaderAcceptSelected);
    }

    params = params.set('sort', sortElement + ',' + sortOrder);

    return this.httpClient.get<Page<Device>>(`${this.basePath}/api/device-configuration-manager/v3/devices`, {
      withCredentials: this.configuration.withCredentials,
      headers: headers,
      params
    }).pipe(catchError(() => of(null)));
  }

  /**
   * Get a device by its POI
   * @param poi string
   * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
   * @param reportProgress flag to report request and response progress.
   */
  public getDevice(poi: string, observe?: 'body', reportProgress?: boolean): Observable<Device> {

    return this.httpClient.get<DeviceInfoV3>(`${this.basePath}/api/device-configuration-manager/v3/devices/${poi}`, {
      withCredentials: this.configuration.withCredentials,
      headers: this.defaultHeaders,
      observe,
      reportProgress
    }).pipe(catchError(() => of(null)));
  }

  public createOrUpdateGenericParameters(poi: string, genericsParameters: Array<GenericParameter>, observe?: 'body', reportProgress?: boolean): Observable<Device> {
    if (!poi || !genericsParameters) {
      throw new Error('Parameters poi and genericsParameters are required for createOrUpdateGenericParameters method');
    }

    return this.httpClient.post<Device>(`${this.basePath}/api/device-configuration-manager/v3/devices/${poi}/genericparameters`,
      genericsParameters,
      {
        withCredentials: this.configuration.withCredentials,
        headers: this.defaultHeaders,
        observe,
        reportProgress
      }
    );
  }

  /**
   * Delete the device corresponding to the poi parameter
   * @param poi device's poi parameter
   */
  deleteDevice(poi: string): Observable<any> {
    return this.httpClient.delete<any>(`${this.basePath}/api/device-configuration-manager/v3/devices/${poi}`,
    {
      withCredentials: this.configuration.withCredentials,
      headers: this.defaultHeaders
    });
  }

  /**
   * Initialize a given DeviceFilter in a given HttpParams
   *
   * @param filter: DeviceFilter
   * @param params: HttpParams
   */
  private initHttpParamsWithDeviceFilter(filter: DeviceFilter, params: HttpParams): HttpParams {
    for (const [key, value] of Object.entries(filter)) {
      if (typeof value === 'string' && value.trim() !== '') {
        params = params.set(key, value.trim());
      } else if (value instanceof Date) {
        params = params.set(key, value.toISOString());
      }
    }
    return params;
  }

  public getAllDeviceConfigV2Templates(observe?: 'body', reportProgress?: boolean): Observable<DeviceConfigV2Template[]>;
  public getAllDeviceConfigV2Templates(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<DeviceConfigV2Template[]>>;
  public getAllDeviceConfigV2Templates(observe: any = 'body', reportProgress: boolean = false): Observable<any> {

    const params = this.setParamsWithCompanyRef(new HttpParams());

    return this.httpClient.get<DeviceConfigV2Template>(`${this.basePath}/api/device-configuration-manager/v2/device-config-templates`, {
      withCredentials: this.configuration.withCredentials,
      headers: this.defaultHeaders,
      params,
      observe,
      reportProgress
    }).pipe(catchError(() => of(null)));

  }

  public updateDeviceConfigV2Template(deviceConfigV2Template: DeviceConfigV2Template, observe?: 'body', reportProgress?: boolean): Observable<DeviceConfigV2Template>;
  public updateDeviceConfigV2Template(deviceConfigV2Template: DeviceConfigV2Template, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<DeviceConfigV2Template>>;
  public updateDeviceConfigV2Template(deviceConfigV2Template: DeviceConfigV2Template, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<DeviceConfigV2Template>>;
  public updateDeviceConfigV2Template(deviceConfigV2Template: DeviceConfigV2Template, observe: any = 'body', reportProgress: boolean = false ): Observable<any> {

    if (!deviceConfigV2Template || !deviceConfigV2Template.id) {
      throw new Error('Required parameter deviceConfigV2Template was null or undefined when calling updateDeviceConfigV2Template.');
    }

    let headers = this.defaultHeaders;

    const httpHeaderAcceptSelected: string | undefined = this.configuration.selectHeaderAccept(['application/json']);
    if (httpHeaderAcceptSelected !== undefined) {
        headers = headers.set('Accept', httpHeaderAcceptSelected);
    }

    const httpContentTypeSelected: string | undefined = this.configuration.selectHeaderContentType(['application/json']);
    if (httpContentTypeSelected !== undefined) {
        headers = headers.set('Content-Type', httpContentTypeSelected);
    }

    return this.httpClient.put<DeviceConfigV2Template>(`${this.basePath}/api/device-configuration-manager/v2/device-config-templates/${deviceConfigV2Template.id}`,
      deviceConfigV2Template,
      {
        withCredentials: this.configuration.withCredentials,
        headers: headers,
        observe: observe,
        reportProgress: reportProgress
      }
    );

  }

  public createOrUpdateDeviceConfigV2(deviceConfig: DeviceConfigurationV2, observe?: 'body', reportProgress?: boolean): Observable<DeviceConfigurationV2>;
  public createOrUpdateDeviceConfigV2(deviceConfig: DeviceConfigurationV2, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<DeviceConfigurationV2>>;
  public createOrUpdateDeviceConfigV2(deviceConfig: DeviceConfigurationV2, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<DeviceConfigurationV2>>;
  public createOrUpdateDeviceConfigV2(deviceConfig: DeviceConfigurationV2, observe: any = 'body', reportProgress: boolean = false ): Observable<any> {

    if (!deviceConfig) {
      throw new Error('Required parameter deviceConfig was null or undefined when calling createOrUpdateDeviceConfigV2.');
    }

    let headers = this.defaultHeaders;
    const httpHeaderAcceptSelected = this.configuration.selectHeaderAccept(['*/*']);
    if (httpHeaderAcceptSelected !== undefined) {
      headers = headers.set('Accept', httpHeaderAcceptSelected);
    }
    const httpContentTypeSelected = this.configuration.selectHeaderContentType(['application/json']);
    if (httpContentTypeSelected !== undefined) {
        headers = headers.set('Content-Type', httpContentTypeSelected);
    }

    return this.httpClient.post<DeviceConfigurationV2>(`${this.basePath}/api/device-configuration-manager/v2/devicesConfig`,
      deviceConfig,
      {
        withCredentials: this.configuration.withCredentials,
        headers,
        observe,
        reportProgress: reportProgress
      }
    );
  }

  public blockUnblockDevices(blockUnblockTerminalInfo: BlockUnblockTerminalInfo): Observable<DeviceBatchResults> {
    if (blockUnblockTerminalInfo === null || blockUnblockTerminalInfo === undefined) {
       throw new Error('Required parameter blockUnblockTerminalInfo was null or undefined when calling blockUnblockDevices.');
    }
    return this.httpClient.post<DeviceBatchResults>(`${this.basePath}/api/device-configuration-manager/v3/devices/_block`,
                                                            blockUnblockTerminalInfo);
  }

  private setParamsWithCompanyRef(params: HttpParams): HttpParams {
    const companyReference = this.utilService.getVariable('companyRef', 'session');
    if (companyReference) {
      return params.set('companyReference', companyReference);
    }

    return params;
  }

}
