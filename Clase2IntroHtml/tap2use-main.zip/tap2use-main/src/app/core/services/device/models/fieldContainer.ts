import { Field } from './field';

export interface FieldContainer {
  field?: Field;
  value?: string;
}
