export interface CustomerRequestSubject {
    label: CustomerRequestSubject.SubjectEnum;
}
export namespace CustomerRequestSubject {
    export type SubjectEnum = 'REQUEST_FOR_TRIP' | 'REQUEST_FOR_PURCHASE' | 'REQUEST_FOR_PERSONAL_DATA' | 'REQUEST_FOR_ACCOUNT_REVOKE'| 'REQUEST_FOR_INFO'| 'OTHER';
    export const SubjectEnum = {
        REQUEST_FOR_TRIP: 'REQUEST_FOR_TRIP' as SubjectEnum,
        REQUEST_FOR_PURCHASE: 'REQUEST_FOR_PURCHASE' as SubjectEnum,
        REQUEST_FOR_PERSONAL_DATA: 'REQUEST_FOR_PERSONAL_DATA' as SubjectEnum,
        REQUEST_FOR_ACCOUNT_REVOKE: 'REQUEST_FOR_ACCOUNT_REVOKE' as SubjectEnum,
        REQUEST_FOR_INFO: 'REQUEST_FOR_INFO' as SubjectEnum,
        OTHER: 'OTHER' as SubjectEnum
    };
}
