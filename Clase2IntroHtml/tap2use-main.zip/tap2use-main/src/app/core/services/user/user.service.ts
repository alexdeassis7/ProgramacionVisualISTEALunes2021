import { Injectable } from '@angular/core';
import { BaseService } from '@app/core/services/base.service';
import { Observable, Subject, from } from 'rxjs';
import { map, tap, mergeMap } from 'rxjs/operators';
import { HttpClient, HttpParams, HttpResponse, HttpHeaders, HttpEvent } from '@angular/common/http';
import { TranslateService } from '@ngx-translate/core';
import { environment } from '@env/environment';

import { MobilityAccount } from '@modelUser/mobilityAccount';
import { MobilityAccountIdentityDTO } from '@modelUser/mobilityAccountIdentityDTO';
import { AddressDTO } from '@modelUser/addressDTO';
import { MobilityAccountContactDetailsDTO } from './models/mobilityAccountContactDetailsDTO';
import { MobilityAccountPhotoDTO } from './models/mobilityAccountPhotoDTO';
import { CustomHttpUrlEncodingCodec } from '../encoder';
import { Configuration } from '../configuration';
import { ToastrService } from 'ngx-toastr';
import { AdministratorService } from '../administrator/administrator.service';
import { KeycloakService } from 'keycloak-angular';

@Injectable({
  providedIn: 'root'
})
export class UserService extends BaseService {

  private userSource = new Subject<MobilityAccount>();
  // Observable string streams
  user$: Observable<MobilityAccount> = this.userSource.asObservable();


  constructor(private httpClient: HttpClient,
    protected toastr: ToastrService,
    protected administratorService: AdministratorService,
    private keycloakService: KeycloakService,
    protected translate: TranslateService) {
    super(toastr, translate);
  }



  findUsersFromMobilityEngine(
    filter,
    sortOrder = 'asc',
    sortElement = '',
    pageNumber = 0,
    pageSize = 10
  ): Observable<any> {
    const orderAsc = sortOrder === 'desc' ? false : true;

    switch (sortElement.toUpperCase()) {
      case 'EMAIL':
        sortElement = 'mobilityAccountContactDetails.mobilityAccountEmailAddress';
        break;
      case 'LAST_NAME':
        sortElement = 'mobilityAccountIdentity.mobilityAccountLastName';
        break;
      case 'FIRST_NAME':
        sortElement = 'mobilityAccountIdentity.mobilityAccountFirstName';
        break;
    }
    const sort = sortElement + ',' + sortOrder;

    let params = new HttpParams()
      .set('sort', sort)
      .set('page', pageNumber.toString())
      .set('size', pageSize.toString());


    if (filter.lastName != null && filter.lastName !== '') {
      params = params.set('fuzzyLastName', filter.lastName);
    }
    if (filter.firstName != null && filter.firstName !== '') {
      params = params.set('fuzzyFirstName', filter.firstName);
    }
    if (filter.email != null && filter.email !== '') {
      params = params.set('email', filter.email);
    }
    if (filter.status != null && filter.status !== '') {
      params = params.set('status', filter.status);
    }
    if ((filter.lastName || filter.firstName || filter.email) && (filter.status == null || filter.status === '')) {
      params = params.set('status', MobilityAccount.MobilityAccountStatusEnum.INITIALIZED +
      ',' + MobilityAccount.MobilityAccountStatusEnum.ACTIVE +
      ',' + MobilityAccount.MobilityAccountStatusEnum.CANCELLED);
    }

    return this.httpClient
      .get(environment.api.mobilityEngine + '/v1/mobilityaccounts', {
        params,
        headers: new HttpHeaders({
          'x-apikey': environment.api.apikey
        })
      });
  }

  public getReceiptData(orderReference: string, serviceEmiter: string): Observable<any> {
    const params = new HttpParams()
    .set('orderReference', orderReference)
    .set('serviceEmiter', serviceEmiter);
    return this.httpClient.get<any>(environment.api.financialEngine + '/api/invoicing-manager/v1/receipts', {
      params,
      headers: new HttpHeaders({
        'x-apikey': environment.api.apikey
      })
    });

  }

  /**
   * Get The mobilityAccount for the given UserID
   * @param userId
   */
  public getMobilityAccount(userId: number): Observable<MobilityAccount> {

    if (userId === null || userId === undefined) {
      throw new Error('Required parameter userId was null or undefined when calling getMobilityAccount.');
    }

    return this.httpClient
      .get<MobilityAccount>(environment.api.mobilityEngine + '/v1/mobilityaccounts/' + userId, {
        headers: new HttpHeaders({
          'x-apikey': environment.api.apikey
        })
      })
      .pipe(tap((user) => this.userSource.next(user)));
  }

  updateUserPhoto(mobilityAccountId: number, mobilityAccountPhotoDTO: MobilityAccountPhotoDTO): Observable<any> {
    return this.httpClient
      .put<any>(environment.api.mobilityEngine + '/v1/mobilityaccounts/' + mobilityAccountId + '/photo', mobilityAccountPhotoDTO, {
        headers: new HttpHeaders({
          'x-apikey': environment.api.apikey
        })
      });
  }

  deleteUserPhoto(mobilityAccountId: number): Observable<any> {
    return this.httpClient
      .delete<any>(environment.api.mobilityEngine + '/v1/mobilityaccounts/' + mobilityAccountId + '/photo', {
        headers: new HttpHeaders({
          'x-apikey': environment.api.apikey
        })
      });
  }

  /**
   * Update the identity of a User
   * 
   * @param mobilityAccountId 
   * @param identity 
   */
  updateIdentity(mobilityAccountId: number, identity: MobilityAccountIdentityDTO): Observable<void> {
    return from(this.keycloakService.loadUserProfile()).pipe(
      mergeMap(admin => {
        return this.httpClient.put<void>(environment.api.mobilityEngine + '/v1/mobilityaccounts/' + mobilityAccountId + '/identity', identity, {
          headers: new HttpHeaders({
            actorReference: admin.username,
            actorType: 'AGENT'
          })
        });
      })
    );
  }

/**
 * Delete the identy of user
 * 
 * @param mobilityAccountId 
 */
  deleteIdentity(mobilityAccountId: number): Observable<void> {
    return from(this.keycloakService.loadUserProfile()).pipe(
      mergeMap(admin => {
        return this.httpClient.delete<void>(environment.api.mobilityEngine + '/v1/mobilityaccounts/' + mobilityAccountId + '/identity', {
          headers: new HttpHeaders({
            actorReference: admin.username,
            actorType: 'AGENT'
          })
        });
      })
    );
  }

  /*
                              IDENTITY STATUSES
  */
  cancelUserAccount(userId: number): Observable<any> {
    return this.httpClient.get(
      environment.api.mobilityEngine + '/v1/mobilityaccounts/' + userId + '/cancel', {
        headers: new HttpHeaders({
          'x-apikey': environment.api.apikey
        })
      }
    );
  }

  terminateUserAccount(userId: number): Observable<any> {
    return this.httpClient.get(
      environment.api.mobilityEngine + '/v1/mobilityaccounts/' + userId + '/terminate', {
        headers: new HttpHeaders({
          'x-apikey': environment.api.apikey
        })
      }
    );
  }


  getPaymentPdf(receiptReference: string, serviceEmitter: string): Observable<Blob> {
    return this.httpClient.
    get(`${environment.api.financialEngine}/api/invoicing-manager/v1/services/${encodeURIComponent(String(serviceEmitter))}/receipts/${encodeURIComponent(String(receiptReference))}/_download`, {

        headers: new HttpHeaders({ accept: '*/*' }),
        responseType: 'blob'})
        .pipe(
            map(res => {return new Blob([res], { type: 'application/pdf' });})
        );

  }

  getUserEvents(userId: number, page = 0, size = 10): Observable<any> {
    const sort = 'creationDate,DESC';
    const params = new HttpParams()
      .set('userId', userId.toString())
      .set('page', page.toString())
      .set('size', size.toString())
      .set('sort', sort);
    return this.httpClient.get(
      environment.api.mobilityEngine + '/v1/admin/event', {
        params,
        headers: new HttpHeaders({
          'x-apikey': environment.api.apikey
        })
      });

  }


  /**
   * Update the contact details of a User
   * @param mobilityAccountId 
   * @param contactDetails 
   */
  updateContactDetails(mobilityAccountId: number, contactDetails: MobilityAccountContactDetailsDTO): Observable<void> {
    return this.httpClient.put<void>(environment.api.mobilityEngine + '/v1/mobilityaccounts/' + mobilityAccountId + '/contactdetails', contactDetails);
  }

  updateAddress(userId: number, address: AddressDTO): Observable<any> {
    return this.httpClient.put(environment.api.mobilityEngine + '/v1/mobilityaccounts/' + userId + '/addresses/' + address.addressId, address);
  }

  removeAddress(userId: number, addressId: number): Observable<any> {
    return this.httpClient.delete(
      environment.api.mobilityEngine + '/v1/mobilityaccounts/' + userId + '/addresses/' + addressId, {
        headers: new HttpHeaders({
          'x-apikey': environment.api.apikey
        })
      });
  }

      /**
     * check if retry is allowed for Debt Recovery
     * check if retry is allowed for Debt Recovery
     * @param cardIdentificationToken cardIdentificationToken
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    public checkIfRetryIsAllowedUsingGET(cardIdentificationToken: string, orderSource: string, observe?: 'body', reportProgress?: boolean, responseType?: string): Observable<any>;
    public checkIfRetryIsAllowedUsingGET(cardIdentificationToken: string, orderSource: string, observe?: 'response', reportProgress?: boolean, responseType?: string): Observable<HttpResponse<any>>;
    public checkIfRetryIsAllowedUsingGET(cardIdentificationToken: string, orderSource: string, observe?: 'events', reportProgress?: boolean, responseType?: string): Observable<HttpEvent<any>>;
    public checkIfRetryIsAllowedUsingGET(cardIdentificationToken: string, orderSource: string, observe: any = 'body', reportProgress: boolean = false, responseType?: string): Observable<any> {

        if (cardIdentificationToken === null || cardIdentificationToken === undefined) {
            throw new Error('Required parameter cardIdentificationToken was null or undefined when calling checkIfRetryIsAllowedUsingGET.');
        }

        let queryParameters = new HttpParams({encoder: new CustomHttpUrlEncodingCodec()});
        if (cardIdentificationToken !== undefined && cardIdentificationToken !== null) {
            queryParameters = queryParameters.set('cardIdentificationToken', <any>cardIdentificationToken);
        }
        if (orderSource !== undefined && orderSource !== null) {
            queryParameters = queryParameters.set('orderSource', <any>orderSource);
        }

        let headers = new HttpHeaders({
          'x-apikey': environment.api.apikey
        });

        let configuration = new Configuration();

        // to determine the Accept header
        let httpHeaderAccepts: string[] = [
            '*/*'
        ];
        const httpHeaderAcceptSelected: string | undefined = configuration.selectHeaderAccept(httpHeaderAccepts);
        if (httpHeaderAcceptSelected != undefined) {
            headers = headers.set('Accept', httpHeaderAcceptSelected);
        }

        const requestOptions: Object = {
            params: queryParameters,
            withCredentials: configuration.withCredentials,
            headers: headers,
            observe: observe,
            reportProgress: reportProgress,
            responseType: 'text'
        }

        return this.httpClient.get<any>(environment.api.financialEngine + `/api/risk-manager/v1/debtRecovery/debtrecoveryinfo/retryallowed`,
            requestOptions
        );
    }

}
