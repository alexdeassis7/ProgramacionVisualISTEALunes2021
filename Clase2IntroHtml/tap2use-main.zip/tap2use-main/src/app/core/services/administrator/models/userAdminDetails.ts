export interface UserAdminDetails {
    userFirstName?: string;
    userLastName?: string;
    userEmailAddress?: string;
    userId?: number;
    userLocale?: string;
    companyReference?: string;
}
