import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { TranslateService } from '@ngx-translate/core';
import { BaseService } from '../base.service';
import { Observable, forkJoin } from 'rxjs';

import { environment } from '@env/environment';
import { Administrator } from './models/administrator';
import { UserAdmin } from './models/userAdmin';
import { ToastrService } from 'ngx-toastr';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AdministratorService extends BaseService {

  constructor(private httpClient: HttpClient, protected toastr: ToastrService, protected translate: TranslateService) {
    super(toastr, translate);
  }

  public createUserBack(administrator: UserAdmin): Observable<any> {
    return this.httpClient
      .post<Administrator>(environment.api.mobilityEngine + '/v1/realms/' +
        environment.keycloak.realm + '/clients/' + environment.keycloak.clientId + '/users', administrator, {
        headers: new HttpHeaders({
          'x-apikey': environment.api.apikey
        })
      });

  }

  public updateUserBack(administrator: UserAdmin, adminId: number): Observable<any> {
    return this.httpClient
      .put<UserAdmin>(environment.api.mobilityEngine + '/v1/users/' + adminId, administrator, {
        headers: new HttpHeaders({
          'x-apikey': environment.api.apikey
        })
      });

  }

  public getUserByReference(reference: string): Observable<UserAdmin> {
    return this.httpClient
      .get<any>(environment.api.mobilityEngine + '/v1/realms/' + environment.keycloak.realm + '/reference/' + reference + '/user', {
        headers: new HttpHeaders({ 'x-apikey': environment.api.apikey })
      });
  }

  public getUsersByReferences(references: string[]): Observable<UserAdmin[]> {
    const promises = references.map(ref => this.getUserByReference(ref));
    return forkJoin(promises).pipe(
      map((s: UserAdmin[]) => s.reduce((acc: UserAdmin[], val) => acc.concat(val), [])));
  }

  public getAdministratorByKCId(kcId: string): Observable<UserAdmin> {
      return this.httpClient
      .get<any>(environment.api.mobilityEngine + '/v1/realms/' + environment.keycloak.realm + '/reference/' + kcId + '/user', {
        headers: new HttpHeaders({
          'x-apikey': environment.api.apikey
        })
      });
  }

  public getAdministrators(filter, sortOrder = 'asc', sortElement = '', pageNumber = 0, pageSize = 10): Observable<any> {

    switch (sortElement.toUpperCase()) {
      case 'EMAIL':
        sortElement = 'userDetails.userEmailAddress';
        break;
      case 'LAST_NAME':
        sortElement = 'userDetails.userLastName';
        break;
      case 'FIRST_NAME':
        sortElement = 'userDetails.userFirstName';
        break;
      case 'COMPANY_REFERENCE':
        sortElement = 'userDetails.companyReference';
        break;
    }
    const sort = sortElement + ',' + sortOrder.toLowerCase();
    let params = new HttpParams()
      .set('sort', sort)
      .set('page', pageNumber.toString())
      .set('size', pageSize.toString());

    if (filter.lastName != null && filter.lastName !== '') {
      params = params.set('lastName', filter.lastName);
    }
    if (filter.firstName != null && filter.firstName !== '') {
      params = params.set('firstName', filter.firstName);
    }
    if (filter.email != null && filter.email !== '') {
      params = params.set('email', filter.email);
    }
    if (filter.companyReference != null && filter.companyReference !== '') {
      params = params.set('companyReference', filter.companyReference);
    }
    if (filter.role != null && filter.role !== '') {
      params = params.set('role', filter.role);
    }
    // filtering: to not show agents without email
    params.set('onlyUsersWithEmail', 'true');

    return this.httpClient
      .get<UserAdmin[]>(environment.api.mobilityEngine + '/v1/realms/' + environment.keycloak.realm + '/users', {
        params,
        headers: new HttpHeaders({
          'x-apikey': environment.api.apikey
        })
      });
  }

  public getAdministrator(adminId: number): Observable<UserAdmin> {
    return this.httpClient
      .get<UserAdmin>(environment.api.mobilityEngine + '/v1/users/' + adminId, {
        headers: new HttpHeaders({
          'x-apikey': environment.api.apikey
        })
      });

  }

  getAdminWithMainRole(admin: UserAdmin): UserAdmin {
    // Get the value type
    const role = this.getMainRole(admin.roles);
    admin.mainRole = role;
    return admin;

  }

  deleteAdministrator(adminId: number): Observable<any> {
    return this.httpClient
    .delete(environment.api.mobilityEngine + '/v1/users/' + adminId, {
      headers: new HttpHeaders({
        'x-apikey': environment.api.apikey
      })
    });
  }

  updatePassword(userId: number, credentials) {
    return this.httpClient
      .put(environment.api.mobilityEngine + '/v1/users/' + userId + '/credentials', credentials, {
        headers: new HttpHeaders({
          'x-apikey': environment.api.apikey
        })
      });
  }

  getMainRole(roles: Array<UserAdmin.Role>): UserAdmin.Role {
    const length = roles.length;
    if (length === 1) {
      return roles[0];
    }

    for (let index = 0; index < Object.values(UserAdmin.Role).length; index++) {
      const element = Object.values(UserAdmin.Role)[index];
      if (this.contains(element, roles)) {
          return element;
      }
    }
  }

  contains(s: string, values: Array<UserAdmin.Role>) {
    for (let i = 0; i < values.length ; i++) {
      if (s === values[i]) {
        return true;
      }
    }
    return false;
  }

}
