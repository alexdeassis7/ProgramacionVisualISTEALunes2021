export interface UserAdminCredentials {
    userId?: number;
    userRealm?: string;
    userKeycloakId?: string;
    username?: string;
    userPassword?:string;
}