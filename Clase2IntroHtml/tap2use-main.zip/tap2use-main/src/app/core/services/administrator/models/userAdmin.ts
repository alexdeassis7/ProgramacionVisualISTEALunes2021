import { UserAdminDetails } from './userAdminDetails';
import { UserAdminCredentials } from './userAdminCredentials';

export interface UserAdmin {
    userId?: number;
    userCreationDate?: Date;
    userModificationDate?: Date;
    userDetails?: UserAdminDetails;
    userCredentials?: UserAdminCredentials;
    roles?: Array<UserAdmin.Role>;
    mainRole?: UserAdmin.Role;
}


export namespace UserAdmin {
  export type Role = 'SUPER_ADMIN' | 'ADMIN' | 'SAV' | 'OPERATOR' | 'SERVICE_OPERATOR' | 'AGENT' | 'STATS' | 'CONTROL';
  export const Role = {
    SUPER_ADMIN: 'SUPER_ADMIN' as Role,
    ADMIN: 'ADMIN' as Role,
    SAV: 'SAV' as Role,
    OPERATOR: 'OPERATOR' as Role,
    SERVICE_OPERATOR: 'SERVICE_OPERATOR' as Role,
    AGENT: 'AGENT' as Role,
    STATS: 'STATS' as Role,
    CONTROL: 'CONTROL' as Role
  };
}
