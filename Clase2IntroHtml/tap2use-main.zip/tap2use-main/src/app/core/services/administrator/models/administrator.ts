export interface Administrator {
    id?:number;
    email?: string;
    firstName?: string;
    lastName?: string;
    roles?: Array<Administrator.Role>;
  }


  export namespace Administrator {
    export type Role = 'SUPER_ADMIN' | 'ADMIN' | 'AFTER_SALE_SERVICE' | 'STATS' | 'CONTROL';
    export const Role = {
        SUPER_ADMIN: 'SUPER_ADMIN' as Role,
        ADMIN: 'ADMIN' as Role,
        AFTER_SALE_SERVICE: 'AFTER_SALE_SERVICE' as Role,
        STATS: 'STATS' as Role,
        CONTROL: 'CONTROL' as Role
    };

    
}