import { TestBed, inject } from '@angular/core/testing';

import { FareCollectionEngineService } from './fareCollectionEngine.service';

describe('FareCollectionEngineService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FareCollectionEngineService]
    });
  });

  it('should be created', inject([FareCollectionEngineService], (service: FareCollectionEngineService) => {
    expect(service).toBeTruthy();
  }));
});
