//ALex  , necesito saber cual de estos parametros son opcionales para agregar el signo de pregunta 
//sebas lo va a chequear en el back end y me cuenta que campos son obligatorio y cuales opcionales 

//de momento dejamos todas las interfaces aca y vemos a futuro !


    export interface ProductRate {
        rateId: string;
        rateNumber: number;
        rateAmount: number;
    }

    export interface ProductFutureRate {
        rateId: string;
        rateNumber: number;
        rateAmount: number;
    }

    export interface ProductType {
        productTypeId: string;
        productTypeNumber: number;
        productTypeName: string;
        minPriority: number;
        maxPriority: number;
    }

    export interface ServiceOperator {
        serviceOperatorId: string;
        serviceOperatorName: string;
        serviceOperatorVat: number;
        serviceOperatorCurrency: string;
    }

    export interface ProductValidityType {
        validityTypeId: string;
        validityTypeNumber: number;
        validityTypeName: string;
    }

    export interface TimeFrameMatrixRate {
        rateId: string;
        rateNumber: number;
        rateAmount: number;
    }

    export interface TimeFrameMatrixCollectionType {
        collectionTypeId: string;
        collectionTypeNumber: number;
        collectionTypeName: string;
    }

    export interface TimeFrameMatrixList {
        timeFrameMatrixId: string;
        tripZoneReference: string;
        firstTripTariffRule: number;
        timeFrame: number;
        maxTripQTY: number;
        timeFrameMatrixRate: TimeFrameMatrixRate;
        timeFrameMatrixCollectionType: TimeFrameMatrixCollectionType;
    }

    export interface SpecialDays {
        specialDayId: string;
        specialDayNumber: number;
        specialDayDate: string;
        specialDayName: string;
        isHoliday: number;
    }

    export interface SpecialDaysRestrictionsList {
        specialDayRestrictionId: string;
        specialDayRestrictionNumber: number;
        specialDays: SpecialDays;
        enableProduct: number;
        enableTimeBands: number;
    }

    export interface SpecialServicePeriodType {
        periodTypeId: string;
        periodTypeNumber: number;
        periodTypeDescription: string;
        periodTypeName: string;
    }

    export interface SpecialServicesList {
        specialServiceId: string;
        specialServiceName: string;
        specialServicePeriodType: SpecialServicePeriodType;
        operationType: string;
        rateAmount: number;
        applicationsNumber: number;
        dueTime: string;
        dueDayWeek: number;
        dueDayMonth: number;
    }

    export interface FeeCappingDiscountList {
        id: string;
        productNumber: number;
        periodTypeNumber: number;
        maxAmount: number;
        dueTime: string;
        dueDayWeek: number;
        dueDayMonth: number;
        passengerQty: number;
        serviceOperator: string;
    }

    export interface PartialCappingDiscountList {
        id: string;
        productNumber: number;
        passengerQty: number;
        weekDays: number;
        maxAmount: number;
        startTime: string;
        endTime: string;
        serviceOperator: string;
        startDate: string;
        endDate: string;
    }

    export interface Product {
        productId: string;
        productNumber: number;
        productName: string;
        productMaxNegativeBalance?: any;
        productRate: ProductRate;
        productFutureRateDate: number;
        productFutureRate: ProductFutureRate;
        productPercentageDiscount?: any;
        productPassbackTime?: any;
        productCompanionsCount: number;
        productPrintingName: string;
        productMaximumBalance?: any;
        productType: ProductType;
        serviceOperator: ServiceOperator;
        productValidityDate: number;
        productValidityDays: number;
        productValidityType: ProductValidityType;
        productMaxtrips?: any;
        productEnable: number;
        productEnableSince: number;
        productEnableUntil: number;
        originDestinations: any[];
        zoneMatrixCombinatios: any[];
        timeFrameMatrixList: TimeFrameMatrixList[];
        specialDaysRestrictionsList: SpecialDaysRestrictionsList[];
        productAssignPriority: number;
        dayBeforeSwitch?: any;
        specialServicesList: SpecialServicesList[];
        feeCappingDiscountList: FeeCappingDiscountList[];
        partialCappingDiscountList: PartialCappingDiscountList[];
    }


    export interface addPartialCapping {
        endDate: string;
        endTime: string;
        maxAmount: number;
        passengerQty: number;
        productNumber: number;
        serviceOperator: string;
        startDate: string;
        startTime: string;
        validityDateFrom: Date;
        validityDateTo: Date;
        weekDays: number;
    }



