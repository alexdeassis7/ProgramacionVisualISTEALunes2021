export interface Route {
  routeReference?: string;
  routeAgencyReference?: string;
  routeName?: string;
  routeDescription?: string;
  routeTypeNumber?: number;
  routeDirectionTypeNumber?: number;
}
