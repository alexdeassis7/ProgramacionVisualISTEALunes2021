export interface ProductWithValidityInfo {
	productNumber?: number;
	productName?: string;
	assignPriority?: string;
	startValidtyDate?: string;
	endValidityDate?: string;
	validityStatus?: Number;
	serviceOperator?: string;
}
