import { CompoundStop } from './compoundStop';

export interface Stops {
  lastControlInfoChangeDate?: Date;
  data?: CompoundStop[];
}
