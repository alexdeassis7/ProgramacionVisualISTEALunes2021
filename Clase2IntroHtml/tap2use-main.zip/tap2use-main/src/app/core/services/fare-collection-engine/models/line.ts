import { Route } from './route';

export interface Line {
  lineReference?: string;
  lineName?: string;
  lineShortName?: string;
  routes: Route[];
}
