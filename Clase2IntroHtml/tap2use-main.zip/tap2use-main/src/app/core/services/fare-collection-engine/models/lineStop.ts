export interface LineStop {
  lineReference?: string;
  routeReference?: string;
  stopSequence?: number;
}
