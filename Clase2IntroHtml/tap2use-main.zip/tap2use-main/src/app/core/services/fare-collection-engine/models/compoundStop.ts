import { LineStop } from './lineStop';

export interface CompoundStop {
  stopReference?: string;
  stopCode?: string;
  stopDescription?: string;
  stopCityName?: string;
  stopLevelNumber?: number;
  stopLatitude?: number;
  stopLongitude?: number;
  stopZoneReference?: string;
  stopLocationTypeNumber?: number;
  stopParentStation?: any;
  lineStop?: LineStop[];
}
