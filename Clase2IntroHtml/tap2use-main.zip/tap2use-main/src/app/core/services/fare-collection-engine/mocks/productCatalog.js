export default

    [
        {
            "productId": "349f47d8-df8a-4885-b4e3-24dd4317c517",
            "productNumber": 1,
            "productName": "NOMINAL",
            "productMaxNegativeBalance": null,
            "productRate": {
                "rateId": "2e272a42-ef7c-46b1-ad79-c098e0f1eb43",
                "rateNumber": 1,
                "rateAmount": 2
            },
            "productFutureRateDate": 1672444800000,
            "productFutureRate": {
                "rateId": "322a5b26-4b96-4464-b08c-eda4898a6871",
                "rateNumber": 3,
                "rateAmount": 2.5
            },
            "productPercentageDiscount": null,
            "productPassbackTime": null,
            "productCompanionsCount": 3,
            "productPrintingName": "NOMINAL",
            "productMaximumBalance": null,
            "productType": {
                "productTypeId": "ef2d9573-2b70-40e6-86f6-ee74d5ab0ea6",
                "productTypeNumber": 1,
                "productTypeName": "Postpaid",
                "minPriority": 2001,
                "maxPriority": 3000
            },
            "serviceOperator": {
                "serviceOperatorId": "26a7dbd8-afc2-4739-aa6f-6cd5c0a4d905",
                "serviceOperatorName": "SYTRAL",
                "serviceOperatorVat": 0,
                "serviceOperatorCurrency": "EUR"
            },
            "productValidityDate": 1606780800000,
            "productValidityDays": 365,
            "productValidityType": {
                "validityTypeId": "da9c6879-23e2-4c35-a75c-a0710a94cfce",
                "validityTypeNumber": 2,
                "validityTypeName": "Fixed date"
            },
            "productMaxtrips": null,
            "productEnable": 1,
            "productEnableSince": 1609286400000,
            "productEnableUntil": 1640822400000,
            "originDestinations": [],
            "zoneMatrixCombinatios": [],
            "timeFrameMatrixList": [
                {
                    "timeFrameMatrixId": "e279e7d8-7b87-45ce-866b-a20abdf624d9",
                    "tripZoneReference": "0",
                    "firstTripTariffRule": 1,
                    "timeFrame": 60,
                    "maxTripQTY": 1,
                    "timeFrameMatrixRate": {
                        "rateId": "322a5b26-4b96-4464-b08c-eda4898a6871",
                        "rateNumber": 3,
                        "rateAmount": 2.5
                    },
                    "timeFrameMatrixCollectionType": {
                        "collectionTypeId": "f8822bd5-ece7-44a3-a06f-0adb4fcabad8",
                        "collectionTypeNumber": 1,
                        "collectionTypeName": "Combination Rate"
                    }
                }
            ],
            "specialDaysRestrictionsList": [
                {
                    "specialDayRestrictionId": "be85a343-b7fe-456c-b90d-8fdc6166d2df",
                    "specialDayRestrictionNumber": 1,
                    "specialDays": {
                        "specialDayId": "8c345c14-f7c1-4822-9b9c-35628ddd9c99",
                        "specialDayNumber": 1,
                        "specialDayDate": "2021-07-26",
                        "specialDayName": "SPD1",
                        "isHoliday": 1
                    },
                    "enableProduct": 1,
                    "enableTimeBands": 1
                },
                {
                    "specialDayRestrictionId": "bd8088b1-9fb5-41b1-aa11-ae6e282268c3",
                    "specialDayRestrictionNumber": 2,
                    "specialDays": {
                        "specialDayId": "07c36255-d0ef-46a8-b8e7-eb8d2b5fb8a7",
                        "specialDayNumber": 2,
                        "specialDayDate": "2021-07-29",
                        "specialDayName": "SPD2",
                        "isHoliday": 1
                    },
                    "enableProduct": 0,
                    "enableTimeBands": 0
                }
            ],
            "productAssignPriority": 2002,
            "dayBeforeSwitch": null,
            "specialServicesList": [
                {
                    "specialServiceId": "7fc62e85-316f-4125-a214-b13068232004",
                    "specialServiceName": "TAP-PR",
                    "specialServicePeriodType": {
                        "periodTypeId": "b3c03faa-4393-4abe-876c-695839dced0f",
                        "periodTypeNumber": 1,
                        "periodTypeDescription": "Day",
                        "periodTypeName": "Day"
                    },
                    "operationType": "TAP-PR",
                    "rateAmount": 1.1,
                    "applicationsNumber": 3,
                    "dueTime": "23:50",
                    "dueDayWeek": 5,
                    "dueDayMonth": 5
                }
            ],
            "feeCappingDiscountList": [
                {
                    "id": "968afc9f-c6a3-4d84-b585-08d4ca1b8846",
                    "productNumber": 1,
                    "periodTypeNumber": 1,
                    "maxAmount": 10,
                    "dueTime": "10:00",
                    "dueDayWeek": 0,
                    "dueDayMonth": 0,
                    "passengerQty": 1,
                    "serviceOperator": "SYTRAL"
                },
                {
                    "id": "59dfd140-4e3f-4a1f-941e-f1367d33ffcb",
                    "productNumber": 1,
                    "periodTypeNumber": 1,
                    "maxAmount": 10,
                    "dueTime": "10:00",
                    "dueDayWeek": 0,
                    "dueDayMonth": 0,
                    "passengerQty": 2,
                    "serviceOperator": "SYTRAL"
                }
            ],
            "partialCappingDiscountList": [
                {
                    "id": "889560fe-9e23-4a2d-a00f-e3468ac0f907",
                    "productNumber": 1,
                    "passengerQty": 1,
                    "weekDays": 1,
                    "maxAmount": 1,
                    "startTime": "10:00",
                    "endTime": "10:30",
                    "serviceOperator": "SYTRAL",
                    "startDate": "2016-12-30",
                    "endDate": "2023-12-30"
                },
                {
                    "id": "8eec0d90-7d4b-4039-92cf-c69ba7040375",
                    "productNumber": 1,
                    "passengerQty": 2,
                    "weekDays": 135,
                    "maxAmount": 2,
                    "startTime": "07:00",
                    "endTime": "01:30",
                    "serviceOperator": "SYTRAL",
                    "startDate": "2016-12-30",
                    "endDate": "2026-12-30"
                }
            ]
        }
    ]

