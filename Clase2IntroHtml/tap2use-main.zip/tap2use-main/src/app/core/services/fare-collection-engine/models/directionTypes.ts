import { DirectionType } from './directionType';

export interface DirectionTypes {
  lastControlInfoChangeDate?: Date;
  data?: DirectionType[];
}
