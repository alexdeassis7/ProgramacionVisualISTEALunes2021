import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '@env/environment';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { Page } from '../commons/page';
import { Configuration } from '../configuration';
import { ContractDefault } from './models/contractDefault';
import { DirectionTypes } from './models/directionTypes';
import { Line } from './models/line';
import { Lines } from './models/lines';
import { Product } from './models/productCatalog';
import { ProductWithValidityInfo } from './models/ProductWithValidityInfo';
import { Stop } from './models/stop';
import { Stops } from './models/stops';


@Injectable({
  providedIn: 'root'
})
export class FareCollectionEngineService {

  private configuration = new Configuration();
  private defaultHeaders = new HttpHeaders();
  private basePath = `${environment.api.fareCollectionEngine}/fce`;
  private basePathZuul = `${environment.api.fareCollectionEngine}`;

  constructor(private httpClient: HttpClient) { }

  public getLines(observe?: 'body', reportProgress?: boolean): Observable<Lines>;
  public getLines(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Lines>>;
  public getLines(observe: any = 'body', reportProgress: boolean = false): Observable<any> {

    return this.httpClient.get<any>(`${this.basePathZuul}/api/location-catalog/api/v1/lines/{lastUpdateDate}`, {
      withCredentials: this.configuration.withCredentials,
      headers: this.defaultHeaders,
      observe,
      reportProgress
    }).pipe(catchError(() => of(null)));

  }

  public getStopsByLineReference(lineReference?: string, observe?: 'body', reportProgress?: boolean): Observable<Stops>;
  public getStopsByLineReference(lineReference?: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Stops>>;
  public getStopsByLineReference(lineReference?: string, observe: any = 'body', reportProgress: boolean = false): Observable<any> {

    if (!lineReference || !lineReference.trim()) {
      return of(null);
    }

    return this.httpClient.get<any>(`${this.basePathZuul}/api/location-catalog/api/v1/lines/stops/${lineReference}/{lastUpdateDate}`, {
      withCredentials: this.configuration.withCredentials,
      headers: this.defaultHeaders,
      observe,
      reportProgress
    }).pipe(catchError(() => of(null)));

  }

  public getDirectionTypes(observe?: 'body', reportProgress?: boolean): Observable<DirectionTypes>;
  public getDirectionTypes(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<DirectionTypes>>;
  public getDirectionTypes(observe: any = 'body', reportProgress: boolean = false): Observable<any> {

    return this.httpClient.get<any>(`${this.basePath}/location-catalog/directionTypes`, {
      withCredentials: this.configuration.withCredentials,
      headers: this.defaultHeaders,
      observe,
      reportProgress
    }).pipe(catchError(() => of(null)));

  }

  public getStopsFromIds(ids: string[]): Observable<Stop[]> {
    if (!ids || ids.length === 0) {
      return of([]);
    }

    const params = ids.reduce((acc, id) => {
      return acc.append('stopReference', id);
    }, new HttpParams());

    return this.httpClient.get<Stop[]>(`${this.basePath}/location-catalog/search/stops`, { params: params });
  }

  public getLinesFromIds(ids: string[]): Observable<Line[]> {
    if (!ids || ids.length === 0) {
      return of([]);
    }

    const params = ids.reduce((acc, id) => {
      return acc.append('lineReference', id);
    }, new HttpParams());

    return this.httpClient.get<Line[]>(`${this.basePath}/location-catalog/search/lines`, { params: params });
  }

  public searchStops(search: string = ''): Observable<Stop[]> {
    const params = new HttpParams()
      .set('stopName', search);

    return this.httpClient.get<Stop[]>(`${this.basePath}/location-catalog/search/stops/_autocomplete`, { params: params });
  }

  public searchLines(search: string): Observable<Line[]> {
    return this.httpClient.get<Lines>(`${this.basePathZuul}/api/location-catalog/api/v1/lines/{lastUpdateDate}`)
      .pipe(map(lines => {
        if (Array.isArray(lines.data) && lines.data.length) {
          return lines.data.filter(line => line.lineName && line.lineName.toLowerCase().includes(search.toLowerCase()));
        } else {
          return [];
        }
      }))
  }

  public searchProducts(
    filter,
    sortOrder: 'DESC' | 'ASC',
    sortElement: string,
    pageNumber: number,
    pageSize: number
  ): Observable<Page<ProductWithValidityInfo>> {

    const sort = sortElement + ',' + sortOrder.toLowerCase();
    let params = new HttpParams()
      .set('sort', sort)
      .set('page', pageNumber.toString())
      .set('size', pageSize.toString());

    params = this.initHttpParamsWithFilter(filter, params);

    return this.httpClient.get<Page<ProductWithValidityInfo>>(`${this.basePath}/productsCatalog/find`,
      {
        params: params,
        withCredentials: this.configuration.withCredentials,
        headers: this.defaultHeaders
      }
    );

  }

  /**
   * Initialize a given filter in a given HttpParams
   *
   * @param filter: any
   * @param params: HttpParams
   */
  private initHttpParamsWithFilter(filter: any, params: HttpParams): HttpParams {
    console.log(filter);
    for (const [key, value] of Object.entries(filter)) {
      if (typeof value === 'string' && value.trim() !== '') {
        params = params.set(key, value.trim());
      }
    }
    console.log(params);
    return params;
  }

  /**Intervencion ALEX  */
  product: Product;

  public getProducts(serviceOperator: String, productNumber: number) {//testeado y funcionando 

    return this.httpClient.get<Product>(`${this.basePath}/productsCatalog/${serviceOperator}/${productNumber}`,
      {
        withCredentials: this.configuration.withCredentials,
        headers: this.defaultHeaders
      }
    );
    /*
    para usar mock descomentar esta dos lineas 
    this.product = productCatalogMoked
    return of(this.product);
*/
  }

  //boton add event  127.0.0.1:8600/api/product-catalog/api/v1/PartialCappingDiscount
  /*
    {
      "endDate": "20210524",
      "endTime": "01:30",
      "maxAmount": 2,
      "passengerQty": 2,
      "productNumber": 1,
      "serviceOperator": "SYTRAL",
      "startDate": "20210323",
      "startTime": "07:00",
      "validityDateFrom": "2021-03-23T16:12:12.000Z",
      "validityDateTo": "2021-05-24T16:12:12.000Z",
      "weekDays": 135
    }
    */

  public insertEventPartialCapping() {//testeado y funcionando 
    // let body = JSON.stringify(acaCombiertoElObjeto);
    //cuando se abre el modal , del addEvente ingresamos los sig datos : 
    /** maxAmount,*/
    let body = JSON.stringify({
      //"endDate": "20310524",
      //"endTime": "01:30",
      // "maxAmount": 2,
      "passengerQty": 2,// este campo no sabemos de donde sale , asumimos que pondremos nosotro por defecto seran 3 
      // "productNumber": 1,
      //"serviceOperator": "SYTRAL",
      //"startDate": "20210323",
      // "startTime": "07:00",
      "validityDateFrom": "2021-03-23T16:12:12.000Z", //este campo creemos que es startDate 
      "validityDateTo": "2021-05-24T16:12:12.000Z",   //este campo creemos que es endDate 
      //"weekDays": 135
    });
    // api/product-catalog/api/v1/PartialCappingDiscount
    //aca le envio la data sin id , el id viene creado del back end , NO ENVIAR ID!
    return this.httpClient.post(`${this.basePathZuul}/api/product-catalog/api/v1/PartialCappingDiscount`, body,
      {
        withCredentials: this.configuration.withCredentials,
        headers: this.defaultHeaders
      }
    );
  }

  //boton delete event
  // 127.0.0.1:8600/api/product-catalog/api/v1/PartialCappingDiscount/8eec0d90-7d4b-4039-92cf-c69ba7040375
  public deleteEventPartialCapping(idPartialCapping: string) {//testeado y funcionando 
    return this.httpClient.delete(`${this.basePathZuul}/api/product-catalog/api/v1/PartialCappingDiscount/${idPartialCapping}`,
      // return this.httpClient.post<Product>(`${ this.basePath } / productsCatalog / ${ serviceOperator } / ${ productNumber }`,
      {
        withCredentials: this.configuration.withCredentials,
        headers: this.defaultHeaders
      }
    );
  }

  /**Special Days!  127.0.0.1:8600/api/product-catalog/api/v1/SpecialDays 
   * al crear me retorna un objeto con el id !
   * {
          "isHoliday": 1,
          "name": "SPD$",
          "serviceOperator": "SYTRAL",
          "specialDayDate": "2020-04-04",
          "specialDayNumber": 4,
          "validityDateFrom": "2021-12-30T16:12:12.000Z",
          "validityDateTo": "2021-12-30T16:12:12.000Z"
        
      }
  */
  public deleteSpecialday(idSpecialday: string) {
    console.log(`URL DELETE ${this.basePathZuul}/api/product-catalog/api/v1/SpecialDays/${idSpecialday}`);
    return this.httpClient.delete(`${this.basePathZuul}/api/product-catalog/api/v1/SpecialDays/${idSpecialday}`,
      {
        withCredentials: this.configuration.withCredentials,
        headers: this.defaultHeaders
      }
    );
  }
  /** insert special days
  127.0.0.1:8600/api/product-catalog/api/v1/SpecialDays
  {
          "isHoliday": 1,
          "name": "SPD$",
          "serviceOperator": "SYTRAL",
          "specialDayDate": "2020-04-04",
          "specialDayNumber": 5,
          "validityDateFrom": "2021-12-30T16:12:12.000Z",
          "validityDateTo": "2021-12-30T16:12:12.000Z"
        
      }
     */
  public insertSpecialday(newSpecialDay: any) {
    // let body = JSON.stringify({
    //   "isHoliday": 1,
    //   "name": "SPD$",
    //   "serviceOperator": "SYTRAL",
    //   "specialDayDate": "2020-04-04",
    //   "specialDayNumber": 4,
    //   "validityDateFrom": "2021-12-30T16:12:12.000Z",
    //   "validityDateTo": "2021-12-30T16:12:12.000Z"

    // });

    let body = JSON.stringify(newSpecialDay);

    return this.httpClient.post(`${this.basePathZuul}/api/product-catalog/api/v1/SpecialDays`, body,
      // return this.httpClient.post<Product>(`${ this.basePath } / productsCatalog / ${ serviceOperator } / ${ productNumber }`,
      {
        withCredentials: this.configuration.withCredentials,
        headers: this.defaultHeaders
      }
    );
  }/** Fin   Intervencion ALEX */

}

