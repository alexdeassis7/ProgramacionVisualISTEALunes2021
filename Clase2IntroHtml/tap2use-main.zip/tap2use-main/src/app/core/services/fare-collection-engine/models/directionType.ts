export interface DirectionType {
  id?: string;
  directionTypeNumber?: number;
  name?: string;
  serviceOperator?: string;
  validityDateFrom?: string;
  validityDateTo?: string;
}
