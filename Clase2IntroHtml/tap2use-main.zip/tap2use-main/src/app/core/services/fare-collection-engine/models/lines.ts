import { Line } from './line';

export interface Lines {
  lastControlInfoChangeDate?: Date;
  data?: Line[];
}
