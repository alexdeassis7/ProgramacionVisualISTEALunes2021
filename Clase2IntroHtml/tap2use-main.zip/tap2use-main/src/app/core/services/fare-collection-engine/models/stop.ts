import { LineStop } from './lineStop';

export interface Stop {
	id?: string;
	levelNumber?: number;
	code?: string;
	name?: string;
	description?: string;
	cityName?: string;
	latitude?: number;
	longitude?: number;
	zoneReference?: string;
	locationTypeNumber?: number;
	serviceOperator?: string;
	stopReference?: string;
	parentStation?: string;
	validityDateFrom?: Date;
	validityDateTo?: Date;

}
