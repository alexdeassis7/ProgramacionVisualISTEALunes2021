export interface ContractDefault {
	productNumber?: Number;
	startValidtyDate?: string;
	endValidityDate?: string;
	validityStatus?: Number;
	validityStatusValue?: string;
	serviceOperator?: string;
}