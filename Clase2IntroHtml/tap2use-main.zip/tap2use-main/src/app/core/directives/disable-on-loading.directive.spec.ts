import { DisableOnLoadingDirective } from './disable-on-loading.directive';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

describe('DisableOnLoadingDirective', () => {
  let component: DisableOnLoadingDirective;
  let fixture: ComponentFixture<DisableOnLoadingDirective>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisableOnLoadingDirective ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisableOnLoadingDirective);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
