import {
  AfterViewInit,
  Directive,
  ElementRef,
  HostListener
} from '@angular/core';

@Directive({
  selector: 'textarea[autoresize]',
  host: {
    'style': 'overflow: hidden;resize: none;'
  }
})
export class AutoresizeDirective implements AfterViewInit {

  constructor(
    private elem: ElementRef
  ) { }

  public ngAfterViewInit() {
    this.resize();
  }

  @HostListener('input')
  private resize() {
    const textarea = this.elem.nativeElement as HTMLTextAreaElement;
    // Reset textarea height to auto that correctly calculate the new height
    textarea.style.height = 'auto';
    // Set new height
    textarea.style.height = `${textarea.scrollHeight}px`;
  }
}
