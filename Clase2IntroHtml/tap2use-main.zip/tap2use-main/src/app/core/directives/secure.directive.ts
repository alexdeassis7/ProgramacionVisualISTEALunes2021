import { Directive, ElementRef, Input, ViewContainerRef, OnInit, Output, EventEmitter } from '@angular/core';
import { KeycloakService } from 'keycloak-angular';
import { Observable, of } from 'rxjs';
import { AbstractOnDestroyComponent } from '../abstract-on-destroy-component/abstract-on-destroy-component';
import { takeUntil } from 'rxjs/operators';

@Directive({
  selector: '[secure]'
})
export class SecureDirective extends AbstractOnDestroyComponent implements OnInit {
  permissions: string[];
  forceBehaviour: boolean;

  // used to ignore roles and apply behaviour
  @Input()
  set behaviourOverride(val) {
    this.forceBehaviour = val;
    this.updateView();
  }

  @Input()
  set hasPermission(val) {
    this.permissions = val;
    this.updateView();
  }

  @Input() behaviour: string;

  @Output()
  behaviourActivated: EventEmitter<boolean> = new EventEmitter<boolean>();

  oldvalueDisplay: string;

  constructor(private elementRef: ElementRef, private keycloakService: KeycloakService, private viewContainer: ViewContainerRef) { super(); }

  ngOnInit() {
    this.updateView();
  }

  private updateView() {
    if (this.forceBehaviour) {
      this.applyBehaviour();
    } else if (this.permissions) {
      this.checkPermission()
        .pipe( takeUntil(this.unsubscribe) )   
        .subscribe(authorized => {
          if (!authorized) {
            this.applyBehaviour();
          } else {
            this.resetToNormalBehavior();
          }
        });
    }
  }

  private applyBehaviour() {
    if (this.behaviour === 'disabled') {
      this.elementRef.nativeElement.disabled = true;
    } else if (this.behaviour === 'hidden') {
      this.oldvalueDisplay = this.elementRef.nativeElement.style.display;
      this.elementRef.nativeElement.style.display = 'none';
    }
    this.behaviourActivated.emit(true);
  }

  private resetToNormalBehavior() {
    if (this.behaviour === 'disabled') {
      this.elementRef.nativeElement.disabled = false;
    } else if (this.behaviour === 'hidden') {
      this.elementRef.nativeElement.style.display = this.oldvalueDisplay;
    }
    this.behaviourActivated.emit(false);
  }

  private checkPermission(): Observable<boolean> {
    let authorized = false;
    if (this.permissions.length !== 0) {
      this.permissions.forEach(function(role) {
        if (this.keycloakService.getKeycloakInstance().hasRealmRole(role)) {
          authorized = true;
          return of(authorized);
        }
      }, this);
    }
    return of(authorized);
  }
}
