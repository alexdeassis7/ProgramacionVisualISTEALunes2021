import { AutoresizeDirective } from './autoresize.directive';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

describe('AutoresizeDirective', () => {
  let component: AutoresizeDirective;
  let fixture: ComponentFixture<AutoresizeDirective>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AutoresizeDirective ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoresizeDirective);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
