import { SecureDirective } from './secure.directive';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

describe('SecureDirective', () => {
  let component: SecureDirective;
  let fixture: ComponentFixture<SecureDirective>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SecureDirective ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SecureDirective);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
