import { Directive, OnInit, HostBinding } from '@angular/core';

import { NgProgress, NgProgressRef } from '@ngx-progressbar/core';
import { takeUntil } from 'rxjs/operators';
import { AbstractOnDestroyComponent } from '../abstract-on-destroy-component/abstract-on-destroy-component';

@Directive({
  selector: '[appDisableOnLoading]'
})
export class DisableOnLoadingDirective extends AbstractOnDestroyComponent implements OnInit {
  progressRef: NgProgressRef;

  @HostBinding('disabled')
  loaderState = false;

  constructor(private ngProgress: NgProgress) {
    super();
    this.progressRef = this.ngProgress.ref('root');
  }

  ngOnInit() {
    this.progressRef.state
      .pipe( takeUntil(this.unsubscribe) )
      .subscribe(state => {
        if (state.active) {
          this.loaderState = true;
        } else {
          this.loaderState = false;
        }
      });
  }
}
