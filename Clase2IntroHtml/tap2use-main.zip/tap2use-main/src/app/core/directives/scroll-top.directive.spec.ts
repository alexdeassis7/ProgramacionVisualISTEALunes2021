import { ScrollTopDirective } from './scroll-top.directive';

describe('ScrollTopDirective', () => {
  it('should create an instance', () => {
    const directive = new ScrollTopDirective();
    expect(directive).toBeTruthy();
  });
});
