# Admin Portal

## Installation

### Requirements

This project is based on Angular 9 which requires:

- a [current, active LTS, or maintenance LTS](https://nodejs.org/en/about/releases/) version of Node.js;
- a [npm client](https://docs.npmjs.com/cli/install) to download and install npm dependencies.

### Recommended NPX

```
npm install -g npx
```

Executes <command> either from a local node_modules/.bin, or from a central cache, installing any packages needed in order for <command> to run.
Usefull to avoid to install cli command like `ng`.

### Package installation


Use npm to install the application dependencies:

```bash
npm install
```

### Launch

To start the application in local, run:

```
npx ng serve
```

The application will be accessible on [http://localhost:4200](http://localhost:4200/). By default, the application uses data from the qualification product environment. You can use this account to login: `superadmin / Azerty123?`.

### Default API

By default, this project call API from the nightly-build platform ([Nightly OpenShift](https://admin.caas-qlf.svc.meshcore.net/console/project/t2u-dev-nightly/overview))

## Documentation

- Angular 9 documentation: [https://v9.angular.io/docs](https://v9.angular.io/docs)
- Technical documentation about shared composants, directives, pipes... ([Technical documentation](https://gitlab.kazan.priv.atos.fr/open-payment/tap2use-adminportal/-/blob/develop/documentation/index.adoc))
- Fonctional Specification: [Sharepoint - Tap2Use - Portals](https://sp2013.myatos.net/organization/gbu/wl/gbl/mts/jm/GLOBAL%20PROJECTS/Forms/AllItems.aspx?RootFolder=%2Forganization%2Fgbu%2Fwl%2Fgbl%2Fmts%2Fjm%2FGLOBAL%20PROJECTS%2FOpen%20payment%2FSolution%2F03%2E%20Specification%2FTap2Use%2Fportals&FolderCTID=0x012000A7A2C0BD0576674FB233FA79F41F3DC6&View=%7BC8AA50BB%2D7CD9%2D4391%2D97C8%2DD506F11E21E4%7D)
- Admin template theme: [Gentelella](https://github.com/ColorlibHQ/gentelella)
